<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

if (!has_role('admin')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Admin only']);
  exit;
}

try {
  $hasKey = (tvdb_get_apikey() !== '');
  $hasPin = (tvdb_get_pin() !== '');
  $token  = tvdb_get_token();
  $hasToken = ($token !== '');
  $exp = tvdb_get_token_expires_utc();
  $valid = tvdb_token_is_valid();

  echo json_encode([
    'ok' => true,
    'configured' => $hasKey,
    'has_pin' => $hasPin,
    'has_token' => $hasToken,
    'token_valid' => $valid,
    'token_expires_utc' => $exp,
  ], JSON_PRETTY_PRINT);
} catch (Throwable $e) {
  $debug = (getenv('WNX_DEBUG') === '1');
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $debug ? $e->getMessage() : 'Internal server error']);
}
