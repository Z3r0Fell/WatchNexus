<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/import_chain.php';

header('Content-Type: application/json; charset=utf-8');

if (!has_role('mod')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Mod or admin access required']);
  exit;
}

$importers = [
  ['name' => 'tvmaze', 'label' => 'TVMaze'],
  ['name' => 'sonarr', 'label' => 'Sonarr'],
];

$now = time();

foreach ($importers as $imp) {
  $name = $imp['name'];
  $info = wnx_import_chain_info($name);
  if (!$info) continue;

  $progress = wnx_import_progress_read($name) ?? [];
  $updatedAt = (int)($progress['updated_at'] ?? 0);

  // If we have a lock but no progress update in a long time, still show it, but mark as stale.
  $stale = ($updatedAt > 0) ? (($now - $updatedAt) > 120) : true;

  echo json_encode([
    'ok' => true,
    'in_progress' => true,
    'name' => $name,
    'type' => $progress['type'] ?? $imp['label'],
    'status' => $progress['status'] ?? 'Preparing...',
    'progress' => (int)($progress['progress'] ?? 0),
    'current' => (int)($progress['current'] ?? 0),
    'total' => (int)($progress['total'] ?? 0),
    'date_range' => $progress['date_range'] ?? null,
    'chunk_range' => $progress['chunk_range'] ?? null,
    'next_start' => $progress['next_start'] ?? null,
    'done' => (bool)($progress['done'] ?? false),
    'stale' => $stale,
    'owner_user_id' => (int)($info['user_id'] ?? 0),
    'expires_at' => (int)($info['expires_at'] ?? 0),
  ], JSON_PRETTY_PRINT);
  exit;
}

echo json_encode([
  'ok' => true,
  'in_progress' => false
], JSON_PRETTY_PRINT);
