<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/import_chain.php';

header('Content-Type: application/json; charset=utf-8');

// Mod/Admin only
if (!has_role('mod')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Moderator or admin access required']);
  exit;
}

function is_ymd(string $s): bool {
  return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $s);
}

function ymd_add_days(string $ymd, int $days): string {
  $dt = DateTimeImmutable::createFromFormat('Y-m-d', $ymd);
  if (!$dt) return $ymd;
  return $dt->modify(($days >= 0 ? '+' : '') . $days . ' days')->format('Y-m-d');
}

function ymd_diff_days(string $a, string $b): int {
  $da = DateTimeImmutable::createFromFormat('Y-m-d', $a);
  $db = DateTimeImmutable::createFromFormat('Y-m-d', $b);
  if (!$da || !$db) return 0;
  return (int)$da->diff($db)->days;
}

function wnx_parse_utc_datetime(string $value): ?DateTimeImmutable {
  $value = trim($value);
  if ($value === '') return null;

  // Already MySQL datetime?
  if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value)) {
    try { return new DateTimeImmutable($value, new DateTimeZone('UTC')); } catch (Throwable $e) { return null; }
  }

  // ISO8601 (TVMaze airstamp includes timezone offset)
  try {
    $dt = new DateTimeImmutable($value);
    return $dt->setTimezone(new DateTimeZone('UTC'));
  } catch (Throwable $e) {
    return null;
  }
}

function wnx_dt_mysql(?DateTimeImmutable $dt): string {
  return $dt ? $dt->format('Y-m-d H:i:s') : '';
}


$startDate = $_GET['start'] ?? date('Y-m-d');
$endDate   = $_GET['end'] ?? date('Y-m-d', strtotime('+30 days'));
$country   = strtoupper((string)($_GET['country'] ?? 'US'));

$chunkDays = (int)($_GET['chunk_days'] ?? 7);
if ($chunkDays < 1) $chunkDays = 1;
if ($chunkDays > 14) $chunkDays = 14;

if (!is_ymd($startDate) || !is_ymd($endDate)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid date format. Use YYYY-MM-DD.']);
  exit;
}
if (strtotime($startDate) > strtotime($endDate)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Start date must be before end date.']);
  exit;
}
if (!preg_match('/^[A-Z]{2}$/', $country)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid country. Use 2-letter code (e.g., US, CA).']);
  exit;
}

// Acquire (or resume) chain lock for this session
$acq = wnx_import_chain_acquire('tvmaze', 'TVMaze', 900);
if (!$acq['ok']) {
  http_response_code(409);
  echo json_encode(['ok' => false, 'error' => $acq['error'] ?? 'Import already running', 'owner' => $acq['owner'] ?? null]);
  exit;
}
$ctx = $acq['ctx'];

$startTime = time();
@set_time_limit(0);

$pdo = db();
$imported = 0;
$skipped = 0;
$errors = [];
$shows_created = 0;
$events_created = 0;

try {
  // Determine base range for overall progress (persisted across chunks)
  $prev = wnx_import_progress_read('tvmaze') ?? [];
  $baseStart = (string)($prev['base_start'] ?? $startDate);
  $baseEnd   = (string)($prev['base_end'] ?? $endDate);
  if (!is_ymd($baseStart)) $baseStart = $startDate;
  if (!is_ymd($baseEnd)) $baseEnd = $endDate;

  // If caller changed end date mid-chain, accept it but keep baseStart
  if ($baseEnd !== $endDate) $baseEnd = $endDate;

  $overallTotal = ymd_diff_days($baseStart, $baseEnd) + 1;
  if ($overallTotal < 1) $overallTotal = 1;

  // Chunk range
  $chunkStart = $startDate;
  $chunkEnd = ymd_add_days($chunkStart, $chunkDays - 1);
  if (strtotime($chunkEnd) > strtotime($baseEnd)) $chunkEnd = $baseEnd;

  $chunkTotal = ymd_diff_days($chunkStart, $chunkEnd) + 1;
  if ($chunkTotal < 1) $chunkTotal = 1;

  // Initial progress snapshot
  wnx_import_progress_write($ctx, [
    'status' => "Starting chunk $chunkStart → $chunkEnd",
    'progress' => (int)($prev['progress'] ?? 0),
    'current' => (int)($prev['current'] ?? 0),
    'total' => $overallTotal,
    'base_start' => $baseStart,
    'base_end' => $baseEnd,
    'date_range' => $baseStart . ' to ' . $baseEnd,
    'chunk_range' => $chunkStart . ' to ' . $chunkEnd,
    'next_start' => null,
    'done' => false,
  ]);
  wnx_import_chain_touch($ctx, 900);

  // Loop days in chunk
  $current = DateTimeImmutable::createFromFormat('Y-m-d', $chunkStart);
  $end = DateTimeImmutable::createFromFormat('Y-m-d', $chunkEnd);
  if (!$current || !$end) throw new Exception('Invalid date range');

  $pdo->beginTransaction();

  while ($current <= $end) {
    $date = $current->format('Y-m-d');
    $doneDays = ymd_diff_days($baseStart, $date) + 1;
    if ($doneDays < 0) $doneDays = 0;
    $pct = (int)round(min(100, max(0, ($doneDays / $overallTotal) * 100)));

    wnx_import_progress_write($ctx, [
      'status' => "Importing $date ($doneDays/$overallTotal)",
      'progress' => $pct,
      'current' => $doneDays,
      'total' => $overallTotal,
      'base_start' => $baseStart,
      'base_end' => $baseEnd,
      'date_range' => $baseStart . ' to ' . $baseEnd,
      'chunk_range' => $chunkStart . ' to ' . $chunkEnd,
      'done' => false,
    ]);
    wnx_import_chain_touch($ctx, 900);

    // TVMaze schedule endpoint
    $url = 'https://api.tvmaze.com/schedule?date=' . $date . '&country=' . urlencode($country);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 12);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
    curl_setopt($ch, CURLOPT_USERAGENT, 'WatchNexus/3.0');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($code !== 200) {
      $errors[] = "TVMaze API failed for $date (HTTP $code" . ($err ? ": $err" : "") . ")";
      $current = $current->modify('+1 day');
      usleep(200000);
      continue;
    }

    $schedule = json_decode((string)$resp, true);
    if (!is_array($schedule)) {
      $errors[] = "Invalid JSON from TVMaze for $date";
      $current = $current->modify('+1 day');
      usleep(200000);
      continue;
    }

    foreach ($schedule as $item) {
      $showData = $item['show'] ?? null;
      $episodeData = $item;

      if (!$showData || !isset($showData['id'])) continue;

      $tvmazeId = (string)$showData['id'];
      $showTitle = (string)($showData['name'] ?? 'Unknown');
      $posterUrl = $showData['image']['medium'] ?? $showData['image']['original'] ?? null;
      $showStatus = strtolower((string)($showData['status'] ?? 'unknown'));

      $statusMap = [
        'running' => 'running',
        'ended' => 'ended',
        'to be determined' => 'hiatus',
        'in development' => 'hiatus',
      ];
      $ourStatus = $statusMap[$showStatus] ?? 'unknown';

      // Find show by TVMaze external ID
      $st = $pdo->prepare("SELECT s.id FROM shows s
        JOIN show_external_ids sei ON sei.show_id = s.id
        WHERE sei.provider = 'tvmaze' AND sei.external_id = ?
        LIMIT 1");
      $st->execute([$tvmazeId]);
      $showId = $st->fetchColumn();

      if (!$showId) {
        $ins = $pdo->prepare("INSERT INTO shows (title, show_type, status, poster_url) VALUES (?, 'tv', ?, ?)");
        $ins->execute([$showTitle, $ourStatus, $posterUrl]);
        $showId = (int)$pdo->lastInsertId();
        $shows_created++;

        $ins = $pdo->prepare("INSERT INTO show_external_ids (show_id, provider, external_id) VALUES (?, 'tvmaze', ?)");
        $ins->execute([$showId, $tvmazeId]);
        // Capture additional externals when available (helps later TVDB enrichment)
        $thetvdbId = $showData['externals']['thetvdb'] ?? null;
        if ($thetvdbId) {
          $ins2 = $pdo->prepare("INSERT IGNORE INTO show_external_ids (show_id, provider, external_id) VALUES (?, 'thetvdb', ?)");
          $ins2->execute([$showId, (string)$thetvdbId]);
        }

      } else {
        $upd = $pdo->prepare("UPDATE shows SET title = ?, status = ?, poster_url = COALESCE(?, poster_url) WHERE id = ?");
        $upd->execute([$showTitle, $ourStatus, $posterUrl, $showId]);
        // Try to backfill TVDB external ID when schedule payload includes it
        $thetvdbId = $showData['externals']['thetvdb'] ?? null;
        if ($thetvdbId) {
          $ins2 = $pdo->prepare("INSERT IGNORE INTO show_external_ids (show_id, provider, external_id) VALUES (?, 'thetvdb', ?)");
          $ins2->execute([(int)$showId, (string)$thetvdbId]);
        }

      }

      // Event timing
      $airstamp = $episodeData['airstamp'] ?? null;
      if (!$airstamp) {
        $airdate = $episodeData['airdate'] ?? null;
        $airtime = $episodeData['airtime'] ?? '00:00';
        if ($airdate) $airstamp = $airdate . ' ' . $airtime . ':00';
        else continue;
      }
      $dt = wnx_parse_utc_datetime((string)$airstamp);
      if (!$dt) { $skipped++; continue; }
      $airstamp = wnx_dt_mysql($dt);
      $season = $episodeData['season'] ?? null;
      $episode = $episodeData['number'] ?? null;
      $episodeTitle = $episodeData['name'] ?? null;

      $network = null;
      if (isset($showData['network']['name'])) $network = $showData['network']['name'];
      else if (isset($showData['webChannel']['name'])) $network = $showData['webChannel']['name'];

      // Prevent duplicates
      $st = $pdo->prepare("SELECT id FROM events
        WHERE show_id = ? AND start_utc = ? AND season = ? AND episode = ?
        LIMIT 1");
      $st->execute([$showId, $airstamp, $season, $episode]);
      if ($st->fetchColumn()) {
        $skipped++;
        continue;
      }

      $ins = $pdo->prepare("INSERT INTO events (show_id, event_type, start_utc, season, episode, episode_title, platform)
        VALUES (?, 'airing', ?, ?, ?, ?, ?)");
      $ins->execute([$showId, $airstamp, $season, $episode, $episodeTitle, $network]);
      $events_created++;
      $imported++;
    }

    // Commit per day to reduce long transaction risk on shared hosts
    $pdo->commit();
    $pdo->beginTransaction();

    $current = $current->modify('+1 day');
    usleep(250000); // be nice to TVMaze

    // If max_execution_time is close, bail early and let the client resume.
    $maxExec = (int)ini_get('max_execution_time');
    if ($maxExec > 0 && (time() - $startTime) > max(5, $maxExec - 5)) {
      break;
    }
  }

  // Finalize open tx
  if ($pdo->inTransaction()) $pdo->commit();

  // Determine next chunk start
  $done = (strtotime($chunkEnd) >= strtotime($baseEnd));
  $nextStart = null;
  if (!$done) {
    $nextStart = ymd_add_days($chunkEnd, 1);
  }

  $finalCurrent = $done ? $overallTotal : (ymd_diff_days($baseStart, $chunkEnd) + 1);
  $finalPct = (int)round(min(100, max(0, ($finalCurrent / $overallTotal) * 100)));

  wnx_import_progress_write($ctx, [
    'status' => $done ? 'Completed!' : ('Chunk complete. Continuing…'),
    'progress' => $finalPct,
    'current' => $finalCurrent,
    'total' => $overallTotal,
    'base_start' => $baseStart,
    'base_end' => $baseEnd,
    'date_range' => $baseStart . ' to ' . $baseEnd,
    'chunk_range' => $chunkStart . ' to ' . $chunkEnd,
    'next_start' => $nextStart,
    'done' => $done,
  ]);
  wnx_import_chain_touch($ctx, 900);

  if ($done) {
    wnx_import_chain_release('tvmaze');
  }

  echo json_encode([
    'ok' => true,
    'done' => $done,
    'next_start' => $nextStart,
    'chunk_range' => $chunkStart . ' to ' . $chunkEnd,
    'date_range' => $baseStart . ' to ' . $baseEnd,
    'imported' => $imported,
    'skipped' => $skipped,
    'shows_created' => $shows_created,
    'events_created' => $events_created,
    'errors' => $errors,
  ], JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  if (isset($pdo) && $pdo->inTransaction()) {
    $pdo->rollBack();
  }

  wnx_import_progress_write($ctx, [
    'status' => 'Failed: ' . ((defined('WNX_DEBUG') && WNX_DEBUG) ? $e->getMessage() : 'Internal error'),
    'done' => true,
    'progress' => 0,
  ]);

  // Release chain so it doesn't get stuck
  wnx_import_chain_release('tvmaze');

  http_response_code(500);
  echo json_encode([
    'ok' => false,
    'error' => (defined('WNX_DEBUG') && WNX_DEBUG) ? $e->getMessage() : 'Internal server error',
    ...((defined('WNX_DEBUG') && WNX_DEBUG) ? ['file' => $e->getFile(), 'line' => $e->getLine()] : [])
  ]);
}
