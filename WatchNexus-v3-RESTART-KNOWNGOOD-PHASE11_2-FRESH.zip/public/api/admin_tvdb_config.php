<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'POST required']);
  exit;
}

if (!has_role('admin')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Admin only']);
  exit;
}

$raw = file_get_contents('php://input') ?: '';
$data = json_decode($raw, true);
if (!is_array($data)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
  exit;
}

$apikey = trim((string)($data['apikey'] ?? ''));
$pin    = trim((string)($data['pin'] ?? ''));

if ($apikey === '') {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'API key is required']);
  exit;
}

try {
  // store encrypted
  tvdb_set_system_config('tvdb_apikey', null, encrypt_secret($apikey));
  tvdb_set_system_config('tvdb_pin', null, $pin === '' ? null : encrypt_secret($pin));

  // wipe old token to force re-login next call
  tvdb_set_system_config('tvdb_token', null, null);
  tvdb_set_system_config('tvdb_token_expires_utc', null, null);

  echo json_encode(['ok' => true, 'message' => 'TVDB configuration saved'], JSON_PRETTY_PRINT);
} catch (Throwable $e) {
  $debug = (getenv('WNX_DEBUG') === '1');
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $debug ? $e->getMessage() : 'Internal server error']);
}
