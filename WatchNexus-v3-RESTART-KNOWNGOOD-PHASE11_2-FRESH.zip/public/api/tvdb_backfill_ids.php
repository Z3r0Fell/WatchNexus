<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

if (!has_role('mod')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Mod only']);
  exit;
}

$limit = (int)($_GET['limit'] ?? 50);
if ($limit < 1) $limit = 1;
if ($limit > 200) $limit = 200;

function tvmaze_http_get(string $url): array {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 12);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
  $body = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return [$code, $body === false ? '' : (string)$body, (string)$err];
}

$pdo = db();

try {
  $st = $pdo->prepare("
    SELECT s.id AS show_id, s.title, tvm.external_id AS tvmaze_id
    FROM shows s
    JOIN show_external_ids tvm ON tvm.show_id = s.id AND tvm.provider = 'tvmaze'
    LEFT JOIN show_external_ids tvdb ON tvdb.show_id = s.id AND tvdb.provider = 'thetvdb'
    WHERE tvdb.id IS NULL
    ORDER BY s.id ASC
    LIMIT ?
  ");
  $st->execute([$limit]);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC);

  $updated = 0;
  $skipped = 0;
  $errors = [];

  $ins = $pdo->prepare("INSERT IGNORE INTO show_external_ids (show_id, provider, external_id) VALUES (?, 'thetvdb', ?)");

  foreach ($rows as $r) {
    $showId = (int)$r['show_id'];
    $tvmazeId = (int)$r['tvmaze_id'];

    if ($tvmazeId <= 0) { $skipped++; continue; }

    [$code, $raw, $err] = tvmaze_http_get('https://api.tvmaze.com/shows/' . $tvmazeId);
    if ($code !== 200) {
      $errors[] = "TVMaze $tvmazeId HTTP $code" . ($err ? " ($err)" : "");
      continue;
    }

    $j = json_decode($raw, true);
    if (!is_array($j)) { $errors[] = "TVMaze $tvmazeId invalid JSON"; continue; }

    $tvdbId = $j['externals']['thetvdb'] ?? null;
    if (!$tvdbId) { $skipped++; continue; }

    $ins->execute([$showId, (string)$tvdbId]);
    $updated++;

    // be nice to TVMaze
    usleep(120000);
  }

  echo json_encode([
    'ok' => true,
    'checked' => count($rows),
    'updated' => $updated,
    'skipped' => $skipped,
    'errors' => $errors,
  ], JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  $debug = (getenv('WNX_DEBUG') === '1');
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $debug ? $e->getMessage() : 'Internal server error']);
}
