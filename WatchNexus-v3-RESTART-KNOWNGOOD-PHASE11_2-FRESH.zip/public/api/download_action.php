<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$u = current_user();
if (!$u) {
  http_response_code(401);
  echo json_encode(['ok' => false, 'error' => 'Login required']);
  exit;
}

$uid = (int)($u['id'] ?? 0);

$raw = file_get_contents('php://input') ?: '';
$data = json_decode($raw, true);
if (!is_array($data)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
  exit;
}

$action = (string)($data['action'] ?? '');
$query  = trim((string)($data['query'] ?? ''));

if (!in_array($action, ['seedr', 'jackett', 'prowlarr'], true) || $query === '') {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid request']);
  exit;
}

if (!function_exists('curl_init')) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'cURL is not available on this host. Enable the PHP curl extension.']);
  exit;
}

$pdo = db();

function load_integration(PDO $pdo, int $uid, string $type): ?array {
  $st = $pdo->prepare("
    SELECT base_url, api_variant, api_key_enc, username_enc, password_enc, access_token_enc, enabled
    FROM user_integrations
    WHERE user_id = ? AND integration_type = ?
    LIMIT 1
  ");
  $st->execute([$uid, $type]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  return $row ?: null;
}

function curl_req(string $method, string $url, array $headers = [], ?string $userpwd = null, $postFields = null, int $timeout = 15): array {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

  if ($userpwd) curl_setopt($ch, CURLOPT_USERPWD, $userpwd);
  if ($headers) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

  $method = strtoupper($method);
  if ($method === 'POST') {
    curl_setopt($ch, CURLOPT_POST, true);
    if ($postFields !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
  } elseif ($method !== 'GET') {
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($postFields !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
  }

  $body = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  return [$code, $body === false ? '' : (string)$body, (string)$err];
}

function jackett_search(string $baseUrl, string $apiKey, string $query): array {
  $url = rtrim($baseUrl, '/') . '/api/v2.0/indexers/all/results?apikey=' . urlencode($apiKey) . '&Query=' . urlencode($query);
  [$code, $resp, $err] = curl_req('GET', $url, [], null, null, 18);
  if ($code !== 200) return ['ok'=>false,'error'=>'Jackett search failed (HTTP '.$code.')'.($err?': '.$err:'')];

  $results = json_decode($resp, true);
  if (!isset($results['Results']) || !is_array($results['Results'])) return ['ok'=>false,'error'=>'Invalid response from Jackett'];

  $torrents = $results['Results'];
  usort($torrents, fn($a,$b) => ((int)($b['Seeders']??0)) - ((int)($a['Seeders']??0)));
  $torrents = array_slice($torrents, 0, 25);

  $out = [];
  foreach ($torrents as $t) {
    $out[] = [
      'title' => $t['Title'] ?? 'Unknown',
      'size' => $t['Size'] ?? 0,
      'seeders' => (int)($t['Seeders'] ?? 0),
      'peers' => (int)($t['Peers'] ?? 0),
      'magnet' => $t['MagnetUri'] ?? null,
      'download' => $t['Link'] ?? null,
      'indexer' => $t['Tracker'] ?? 'Jackett',
    ];
  }
  return ['ok'=>true,'results'=>$out];
}

function prowlarr_search(string $baseUrl, string $apiKey, string $query): array {
  $url = rtrim($baseUrl, '/') . '/api/v1/search?query=' . urlencode($query) . '&type=search';
  [$code, $resp, $err] = curl_req('GET', $url, ['X-Api-Key: '.$apiKey], null, null, 18);
  if ($code !== 200) return ['ok'=>false,'error'=>'Prowlarr search failed (HTTP '.$code.')'.($err?': '.$err:'')];

  $results = json_decode($resp, true);
  if (!is_array($results)) return ['ok'=>false,'error'=>'Invalid response from Prowlarr'];

  usort($results, fn($a,$b) => ((int)($b['seeders']??0)) - ((int)($a['seeders']??0)));
  $results = array_slice($results, 0, 25);

  $out = [];
  foreach ($results as $t) {
    $out[] = [
      'title' => $t['title'] ?? 'Unknown',
      'size' => $t['size'] ?? 0,
      'seeders' => (int)($t['seeders'] ?? 0),
      'peers' => (int)($t['leechers'] ?? 0),
      'magnet' => $t['magnetUrl'] ?? null,
      'download' => $t['downloadUrl'] ?? null,
      'indexer' => $t['indexer'] ?? 'Prowlarr',
    ];
  }
  return ['ok'=>true,'results'=>$out];
}

function seedr_add(string $baseUrl, string $username, string $password, string $item): array {
  $baseUrl = trim($baseUrl);
  if ($baseUrl === '') $baseUrl = 'https://www.seedr.cc';
  $baseUrl = rtrim($baseUrl, '/');

  $isMagnet = (stripos($item, 'magnet:') === 0);
  $endpoint = $isMagnet ? '/rest/transfer/magnet' : '/rest/transfer/url';
  $field    = $isMagnet ? 'magnet' : 'url';

  $url = $baseUrl . $endpoint;
  $body = http_build_query([$field => $item], '', '&');

  [$code, $resp, $err] = curl_req('POST', $url, ['Content-Type: application/x-www-form-urlencoded'], $username.':'.$password, $body, 20);

  if ($code < 200 || $code >= 300) {
    return ['ok'=>false,'error'=>'Seedr add failed (HTTP '.$code.')'.($err?': '.$err:'')];
  }

  $json = json_decode($resp, true);
  if (is_array($json)) {
    return ['ok'=>true,'response'=>$json];
  }
  return ['ok'=>true,'response_raw'=>$resp];
}

try {
  // Direct search requests
  if ($action === 'jackett') {
    $row = load_integration($pdo, $uid, 'jackett');
    if (!$row || (int)($row['enabled'] ?? 0) !== 1) {
      http_response_code(400);
      echo json_encode(['ok'=>false,'error'=>'Jackett is not configured or disabled. Enable it in Settings → Integrations.']);
      exit;
    }

    $baseUrl = trim((string)($row['base_url'] ?? ''));
    $apiKey  = decrypt_secret((string)($row['api_key_enc'] ?? ''));

    if ($baseUrl === '' || $apiKey === '') {
      http_response_code(400);
      echo json_encode(['ok'=>false,'error'=>'Jackett not fully configured. Add base URL and API key in Settings.']);
      exit;
    }

    $res = jackett_search($baseUrl, $apiKey, $query);
    if (!$res['ok']) { http_response_code(502); echo json_encode(['ok'=>false,'error'=>$res['error']]); exit; }
    echo json_encode(['ok'=>true,'results'=>$res['results']]);
    exit;
  }

  if ($action === 'prowlarr') {
    $row = load_integration($pdo, $uid, 'prowlarr');
    if (!$row || (int)($row['enabled'] ?? 0) !== 1) {
      http_response_code(400);
      echo json_encode(['ok'=>false,'error'=>'Prowlarr is not configured or disabled. Enable it in Settings → Integrations.']);
      exit;
    }

    $baseUrl = trim((string)($row['base_url'] ?? ''));
    $apiKey  = decrypt_secret((string)($row['api_key_enc'] ?? ''));

    if ($baseUrl === '' || $apiKey === '') {
      http_response_code(400);
      echo json_encode(['ok'=>false,'error'=>'Prowlarr not fully configured. Add base URL and API key in Settings.']);
      exit;
    }

    $res = prowlarr_search($baseUrl, $apiKey, $query);
    if (!$res['ok']) { http_response_code(502); echo json_encode(['ok'=>false,'error'=>$res['error']]); exit; }
    echo json_encode(['ok'=>true,'results'=>$res['results']]);
    exit;
  }

  // Seedr: search (Prowlarr preferred, else Jackett), then push best magnet/url to Seedr
  $seedr = load_integration($pdo, $uid, 'seedr');
  if (!$seedr || (int)($seedr['enabled'] ?? 0) !== 1) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Seedr is not configured or disabled. Enable it in Settings → Integrations.']);
    exit;
  }

  $seedrBase = trim((string)($seedr['base_url'] ?? ''));
  $seedrUser = decrypt_secret((string)($seedr['username_enc'] ?? ''));
  $seedrPass = decrypt_secret((string)($seedr['password_enc'] ?? ''));

  if ($seedrUser === '' || $seedrPass === '') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Seedr username/password missing. Set them in Settings → Integrations.']);
    exit;
  }

  // Prefer Prowlarr if enabled, else Jackett
  $searchUsed = '';
  $results = [];

  $prow = load_integration($pdo, $uid, 'prowlarr');
  if ($prow && (int)($prow['enabled'] ?? 0) === 1) {
    $pBase = trim((string)($prow['base_url'] ?? ''));
    $pKey  = decrypt_secret((string)($prow['api_key_enc'] ?? ''));
    if ($pBase !== '' && $pKey !== '') {
      $r = prowlarr_search($pBase, $pKey, $query);
      if ($r['ok']) { $searchUsed = 'prowlarr'; $results = $r['results']; }
    }
  }

  if (!$results) {
    $jack = load_integration($pdo, $uid, 'jackett');
    if ($jack && (int)($jack['enabled'] ?? 0) === 1) {
      $jBase = trim((string)($jack['base_url'] ?? ''));
      $jKey  = decrypt_secret((string)($jack['api_key_enc'] ?? ''));
      if ($jBase !== '' && $jKey !== '') {
        $r = jackett_search($jBase, $jKey, $query);
        if ($r['ok']) { $searchUsed = 'jackett'; $results = $r['results']; }
      }
    }
  }

  if (!$results) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'To use Seedr, configure Prowlarr or Jackett (for search) in Settings → Integrations.']);
    exit;
  }

  // Pick the best item: prefer magnet, else download URL
  $picked = null;
  foreach ($results as $r) { if (!empty($r['magnet'])) { $picked = $r; break; } }
  if (!$picked) { foreach ($results as $r) { if (!empty($r['download'])) { $picked = $r; break; } } }
  if (!$picked) {
    http_response_code(502);
    echo json_encode(['ok'=>false,'error'=>'Search returned results but no magnet/download link was available to send to Seedr.']);
    exit;
  }

  $item = !empty($picked['magnet']) ? (string)$picked['magnet'] : (string)$picked['download'];
  $add = seedr_add($seedrBase, $seedrUser, $seedrPass, $item);

  if (!$add['ok']) {
    http_response_code(502);
    echo json_encode(['ok'=>false,'error'=>$add['error'], 'picked'=>$picked, 'search_used'=>$searchUsed]);
    exit;
  }

  echo json_encode([
    'ok' => true,
    'message' => 'Queued on Seedr: ' . (string)($picked['title'] ?? 'item'),
    'picked' => $picked,
    'search_used' => $searchUsed,
    'seedr' => $add['response'] ?? null,
  ], JSON_PRETTY_PRINT);
  exit;

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
