<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/import_chain.php';

header('Content-Type: application/json; charset=utf-8');

// Admin only (this is a blunt instrument)
if (!has_role('admin')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Admin access required']);
  exit;
}

$name = strtolower((string)($_GET['name'] ?? ''));
$allowed = ['tvmaze', 'sonarr', 'all'];

if (!in_array($name, $allowed, true)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid name. Use tvmaze, sonarr, or all.']);
  exit;
}

$targets = ($name === 'all') ? ['tvmaze', 'sonarr'] : [$name];

$cleared = [];
foreach ($targets as $t) {
  $paths = wnx_import_paths($t);
  @unlink($paths['lock']);
  @unlink($paths['progress']);
  $cleared[] = $t;
}

echo json_encode(['ok' => true, 'cleared' => $cleared], JSON_PRETTY_PRINT);
