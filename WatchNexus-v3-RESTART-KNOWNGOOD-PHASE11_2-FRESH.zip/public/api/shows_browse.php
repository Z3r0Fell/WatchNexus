<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$pdo = db();

// Inputs
$q = trim((string)($_GET['q'] ?? ''));
$status = trim((string)($_GET['status'] ?? ''));
$tracked = (string)($_GET['tracked'] ?? ''); // "1" to show only tracked (requires login)
$sort = trim((string)($_GET['sort'] ?? 'title_asc'));

$page = (int)($_GET['page'] ?? 1);
$perPage = (int)($_GET['per_page'] ?? 24);

$page = max(1, $page);
$perPage = max(12, min(100, $perPage));
$offset = ($page - 1) * $perPage;

// Current user (optional)
$u = function_exists('current_user') ? current_user() : null;
$uid = $u ? (int)($u['id'] ?? 0) : 0;

// Column availability (avoid hard 500s on older schemas)
$hasDesc = function_exists('wnx_db_has_column') && wnx_db_has_column('shows', 'description');
$hasPremiered = function_exists('wnx_db_has_column') && wnx_db_has_column('shows', 'premiered');

// SELECT list
$selectCols = [
  's.id',
  's.title',
  $hasDesc ? 's.description' : 'NULL AS description',
  's.poster_url',
  's.status',
  's.show_type',
  $hasPremiered ? 's.premiered' : 'NULL AS premiered',
];

// Join tracked (optional)
$joinSql = '';
$joinParams = [];
if ($uid > 0) {
  $joinSql = ' LEFT JOIN user_tracked_shows uts ON uts.user_id = ? AND uts.show_id = s.id ';
  $joinParams[] = $uid;
  $selectCols[] = 'CASE WHEN uts.user_id IS NULL THEN 0 ELSE 1 END AS is_tracked';
} else {
  $selectCols[] = '0 AS is_tracked';
}

// WHERE clauses
$where = [];
$params = [];

if ($q !== '') {
  // Search in title and (if present) description
  if ($hasDesc) {
    $where[] = '(s.title LIKE ? OR s.description LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
  } else {
    $where[] = '(s.title LIKE ?)';
    $params[] = '%' . $q . '%';
  }
}

if ($status !== '') {
  $allowed = ['running','ended','development','unknown'];
  if (!in_array(strtolower($status), $allowed, true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid status filter']);
    exit;
  }
  $where[] = 'LOWER(s.status) = ?';
  $params[] = strtolower($status);
}

if ($tracked === '1') {
  if ($uid <= 0) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Login required for tracked filter']);
    exit;
  }
  $where[] = 'uts.user_id IS NOT NULL';
}

// ORDER BY whitelist
$sortMap = [
  'title_asc' => 's.title ASC',
  'title_desc' => 's.title DESC',
  'premiered_desc' => $hasPremiered ? 's.premiered DESC, s.title ASC' : 's.title ASC',
  'premiered_asc' => $hasPremiered ? 's.premiered ASC, s.title ASC' : 's.title ASC',
  'status' => 's.status ASC, s.title ASC',
];
$orderBy = $sortMap[$sort] ?? $sortMap['title_asc'];

$whereSql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';

try {
  // Count
  $countSql = 'SELECT COUNT(*) AS c FROM shows s ' . $joinSql . $whereSql;
  $stCount = $pdo->prepare($countSql);
  $stCount->execute(array_merge($joinParams, $params));
  $total = (int)($stCount->fetchColumn() ?: 0);

  $pages = max(1, (int)ceil($total / $perPage));
  if ($page > $pages) { $page = $pages; $offset = ($page - 1) * $perPage; }

  // Data
  $dataSql =
    'SELECT ' . implode(",\n  ", $selectCols) . "\n" .
    'FROM shows s ' . $joinSql . "\n" .
    $whereSql . "\n" .
    'ORDER BY ' . $orderBy . "\n" .
    'LIMIT ' . (int)$perPage . ' OFFSET ' . (int)$offset;

  $st = $pdo->prepare($dataSql);
  $st->execute(array_merge($joinParams, $params));
  $shows = $st->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode([
    'ok' => true,
    'shows' => $shows,
    'page' => $page,
    'per_page' => $perPage,
    'total' => $total,
    'pages' => $pages,
    'filters' => [
      'q' => $q,
      'status' => $status,
      'tracked' => $tracked,
      'sort' => $sort,
    ],
  ], JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {
  http_response_code(500);
  $debug = false;
  if (defined('WNX_DEBUG')) { $debug = (bool)WNX_DEBUG; }
  if (getenv('WNX_DEBUG') === '1') { $debug = true; }

  $payload = [
    'ok' => false,
    'error' => $debug ? $e->getMessage() : 'Internal server error',
  ];
  if ($debug) {
    $payload['file'] = $e->getFile();
    $payload['line'] = $e->getLine();
  }
  echo json_encode($payload, JSON_UNESCAPED_SLASHES);
}
