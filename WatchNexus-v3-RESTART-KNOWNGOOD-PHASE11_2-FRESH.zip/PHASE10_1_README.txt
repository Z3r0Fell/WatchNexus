WatchNexus v3 - Phase 10.1 Overlay (Schema Alignment)

Files included:
- migrations/001_init.sql (new installs only)
- migrations/004_schema_fixes.sql (updated)
- migrations/004_schema_fixes_SIMPLE.sql (updated)
- public/api/shows_browse.php (now schema-tolerant)
- public/test_apis.php (adds Shows Browse test)

What this phase fixes:
1) Adds missing columns used by Browse UI:
   - shows.description (TEXT)
   - shows.premiered (DATE)

2) Ensures index exists on events.start_utc for older DBs.

3) Migrates legacy global_module_policy rows into module_policy (INSERT IGNORE only).

How to apply:
A) Upload these files over top of your existing install (same paths).
B) Run ONE of these migrations:
   - Preferred: migrations/004_schema_fixes.sql
   - If your host blocks prepared statements: migrations/004_schema_fixes_SIMPLE.sql

Verification:
- Visit /test_apis.php and confirm "Shows Browse" is PASS.
- Visit /api/shows_browse.php and confirm it returns ok:true.
