<?php
declare(strict_types=1);

/**
 * Import chain + progress helpers for shared hosting (IONOS).
 *
 * Goals:
 * - One import chain per importer at a time.
 * - Stable progress files (no uniqid/glob roulette).
 * - Chunked imports can span multiple HTTP requests while staying exclusive.
 */

function wnx_tmpdir(): string {
  $d = sys_get_temp_dir();
  return ($d && is_dir($d)) ? $d : '/tmp';
}

function wnx_import_sanitize(string $name): string {
  $name = strtolower($name);
  return preg_replace('/[^a-z0-9_\-]/', '_', $name) ?: 'import';
}

function wnx_import_paths(string $name): array {
  $safe = wnx_import_sanitize($name);
  $base = rtrim(wnx_tmpdir(), "/\\") . DIRECTORY_SEPARATOR . 'wnx_import_' . $safe;
  return [
    'lock' => $base . '.lock.json',
    'progress' => $base . '.progress.json',
  ];
}

function wnx_import_session_key(string $name): string {
  return 'wnx_import_token_' . wnx_import_sanitize($name);
}

function wnx_import_new_token(): string {
  // 32 hex chars is plenty; don't need crypto-grade, but we have it anyway.
  try {
    return bin2hex(random_bytes(16));
  } catch (Throwable $e) {
    return bin2hex(openssl_random_pseudo_bytes(16) ?: random_bytes(16));
  }
}

/**
 * Acquire (or resume) an import chain lock for this session.
 *
 * Returns: ['ok'=>bool, 'error'?:string, 'ctx'?:array, 'owner'?:array]
 */
function wnx_import_chain_acquire(string $name, string $typeLabel, int $ttlSeconds = 900): array {
  if (session_status() !== PHP_SESSION_ACTIVE) {
    // bootstrap should have started session, but be defensive
    @session_start();
  }

  $paths = wnx_import_paths($name);
  $lockFile = $paths['lock'];
  $now = time();

  $tokenKey = wnx_import_session_key($name);
  $token = $_SESSION[$tokenKey] ?? null;
  if (!is_string($token) || strlen($token) < 16) {
    $token = wnx_import_new_token();
    $_SESSION[$tokenKey] = $token;
  }

  $fh = @fopen($lockFile, 'c+');
  if (!$fh) {
    return ['ok' => false, 'error' => 'Unable to open lock file (permissions).'];
  }

  try {
    if (!flock($fh, LOCK_EX)) {
      return ['ok' => false, 'error' => 'Unable to lock lock-file.'];
    }

    // Read existing
    $raw = '';
    $size = filesize($lockFile);
    if ($size && $size > 0) {
      rewind($fh);
      $raw = (string)stream_get_contents($fh);
    }
    $data = $raw ? json_decode($raw, true) : null;
    if (!is_array($data)) $data = [];

    $expiresAt = (int)($data['expires_at'] ?? 0);
    $lockedToken = (string)($data['token'] ?? '');
    $lockedUserId = isset($data['user_id']) ? (int)$data['user_id'] : 0;

    $isActive = ($expiresAt > $now) && ($lockedToken !== '');

    if ($isActive && $lockedToken !== $token) {
      // Somebody else owns this chain
      return [
        'ok' => false,
        'error' => 'Import already running',
        'owner' => [
          'user_id' => $lockedUserId,
          'type' => (string)($data['type'] ?? $typeLabel),
          'expires_at' => $expiresAt,
        ],
      ];
    }

    // Claim / refresh lock
    $user = function_exists('current_user') ? current_user() : null;
    $uid = is_array($user) ? (int)($user['id'] ?? 0) : 0;

    $new = [
      'token' => $token,
      'type' => $typeLabel,
      'user_id' => $uid,
      'created_at' => (int)($data['created_at'] ?? $now),
      'updated_at' => $now,
      'expires_at' => $now + max(60, $ttlSeconds),
    ];

    // Write lock file
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($new, JSON_PRETTY_PRINT));
    fflush($fh);

    return [
      'ok' => true,
      'ctx' => [
        'name' => $name,
        'type' => $typeLabel,
        'token' => $token,
        'paths' => $paths,
      ],
    ];
  } finally {
    // release OS lock, but keep persistent lock file contents
    @flock($fh, LOCK_UN);
    @fclose($fh);
  }
}

function wnx_import_chain_touch(array $ctx, int $ttlSeconds = 900): void {
  $paths = $ctx['paths'] ?? null;
  if (!is_array($paths)) return;
  $lockFile = (string)($paths['lock'] ?? '');
  if ($lockFile === '') return;

  $fh = @fopen($lockFile, 'c+');
  if (!$fh) return;

  $now = time();
  try {
    if (!flock($fh, LOCK_EX)) return;

    $raw = '';
    $size = filesize($lockFile);
    if ($size && $size > 0) {
      rewind($fh);
      $raw = (string)stream_get_contents($fh);
    }
    $data = $raw ? json_decode($raw, true) : [];
    if (!is_array($data)) $data = [];

    $data['updated_at'] = $now;
    $data['expires_at'] = $now + max(60, $ttlSeconds);

    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($data, JSON_PRETTY_PRINT));
    fflush($fh);
  } finally {
    @flock($fh, LOCK_UN);
    @fclose($fh);
  }
}

function wnx_import_progress_write(array $ctx, array $progress): void {
  $paths = $ctx['paths'] ?? null;
  if (!is_array($paths)) return;
  $file = (string)($paths['progress'] ?? '');
  if ($file === '') return;

  $progress['type'] = $ctx['type'] ?? ($progress['type'] ?? 'Import');
  $progress['name'] = $ctx['name'] ?? ($progress['name'] ?? 'import');
  $progress['updated_at'] = time();

  $r = null;
  try { $r = bin2hex(random_bytes(4)); } catch (Throwable $e) { $r = uniqid(); }
  $tmp = $file . '.tmp.' . $r;
  @file_put_contents($tmp, json_encode($progress, JSON_PRETTY_PRINT));
  @rename($tmp, $file);
}

function wnx_import_progress_read(string $name): ?array {
  $paths = wnx_import_paths($name);
  $file = $paths['progress'];
  if (!is_file($file)) return null;
  $raw = @file_get_contents($file);
  if (!$raw) return null;
  $data = json_decode($raw, true);
  return is_array($data) ? $data : null;
}

function wnx_import_chain_info(string $name): ?array {
  $paths = wnx_import_paths($name);
  $lockFile = $paths['lock'];
  if (!is_file($lockFile)) return null;
  $raw = @file_get_contents($lockFile);
  if (!$raw) return null;
  $data = json_decode($raw, true);
  if (!is_array($data)) return null;
  if (((int)($data['expires_at'] ?? 0)) <= time()) return null;
  return $data;
}

function wnx_import_chain_release(string $name): void {
  $paths = wnx_import_paths($name);
  @unlink($paths['lock']);
  // keep progress for post-mortem if desired; endpoint can delete on success
  $tokenKey = wnx_import_session_key($name);
  unset($_SESSION[$tokenKey]);
}

