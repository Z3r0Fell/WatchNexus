<?php
declare(strict_types=1);

function current_roles(): array {
  $u = current_user();
  if (!$u) return [];

  // Cache per-request (prevents repeated queries from helpers like is_admin/is_mod)
  static $cache = [];
  $uid = (int)$u['id'];
  if (isset($cache[$uid])) return $cache[$uid];

  try {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT r.name
      FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = ?
    ");
    $st->execute([$uid]);
    $roles = $st->fetchAll(PDO::FETCH_COLUMN) ?: [];
  } catch (Throwable $e) {
    // On partial installs (missing tables), fail closed.
    $roles = [];
  }

  // Normalize to lowercase strings
  $roles = array_values(array_filter(array_map(static function($r) {
    return strtolower(trim((string)$r));
  }, $roles), static function($r) {
    return $r !== '';
  }));

  return $cache[$uid] = $roles;
}

/** Convenience helpers (used by diagnostics + UI) */
function is_admin(): bool {
  return in_array('admin', current_roles(), true);
}

function is_mod(): bool {
  $roles = current_roles();
  return in_array('admin', $roles, true) || in_array('mod', $roles, true);
}

function current_role_label(): string {
  $roles = current_roles();
  if (in_array('admin', $roles, true)) return 'Admin';
  if (in_array('mod', $roles, true)) return 'Mod';
  if (!empty($roles)) return ucfirst((string)$roles[0]);
  return current_user() ? 'User' : 'Public';
}

function has_role(string $role): bool {
  $roles = current_roles();

  // Admin is supreme
  if (in_array('admin', $roles, true)) return true;

  if ($role === 'admin') return false;
  if ($role === 'mod') return in_array('mod', $roles, true);
  if ($role === 'user') return in_array('user', $roles, true) || in_array('mod', $roles, true);

  return false;
}

function require_role_html(string $role): void {
  if (!has_role($role)) {
    $roleName = ucfirst($role);
    echo '<div class="banner"><div class="badge">Access Denied</div><div><p>' . $roleName . ' access required.</p></div></div>';
    exit;
  }
}
