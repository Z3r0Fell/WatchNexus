/* WatchNexus v3 - appearance.js
 * Interface Packs (merged Theme + UI + Graphics)
 *
 * Storage:
 *   wnx.interface.v4 = { pack, scheme, fx, advanced, theme, uiMode }
 *
 * Back-compat:
 *   wnx.appearance.v3 / wnx.theme.v3 / wnx_ui_mode
 */

(() => {
  const byId = (id) => document.getElementById(id);

  const KEY = 'wnx.interface.v4';
  const LEGACY_KEY = 'wnx.appearance.v3';
  const OLD_THEME_KEY = 'wnx.theme.v3';
  const OLD_UI_MODE_KEY = 'wnx_ui_mode';

  const DEFAULT_THEME = (window.WNX && window.WNX.publicThemeId) ? window.WNX.publicThemeId : 'paper_ink';
  const DEFAULTS = {
    pack: 'classic_dark',
    scheme: 'system',
    fx: false,
    advanced: false,
    theme: DEFAULT_THEME,
    uiMode: 'command'
  };

  const THEMES = [
    { id: 'paper_ink', name: 'Paper & Ink (Default)' },
    { id: 'grid_noir', name: 'Grid Noir' },
    { id: 'lcars', name: 'LCARS-ish' },
    { id: 'tron_legacy', name: 'TRON-ish (Legacy)' },
    { id: 'tardis_blue', name: 'Doctor-ish (TARDIS Blue)' }
  ];

  const UI_MODES = [
    { id: 'command', label: '⚡ Command', bodyClass: 'mode-command' },
    { id: 'overview', label: '📊 Overview', bodyClass: 'mode-overview' },
    { id: 'signal',  label: '📡 Signal',  bodyClass: 'mode-signal' },
    { id: 'nebula',  label: '🌌 Nebula',  bodyClass: 'mode-nebula' }
  ];

  // Packs correspond to CSS definitions in /assets/css/packs.css
  const PACKS = [
    {
      id: 'classic_dark',
      name: 'Classic Dark',
      desc: 'Clean noir with neon accents.',
      palette: { a: '#56c2ff', b: '#00ffd5', c: '#a78bfa' },
      uiMode: 'command'
    },
    {
      id: 'chrono_vortex',
      name: 'Chrono Vortex',
      desc: 'Vortex glass + timey-wimey glow.',
      palette: { a: '#00e5ff', b: '#ffb000', c: '#7c3aed' },
      uiMode: 'nebula'
    },
    {
      id: 'scanner_dash',
      name: 'Scanner Dash',
      desc: 'Alert-forward, fast, surgical.',
      palette: { a: '#ff2d55', b: '#ffb000', c: '#00e5ff' },
      uiMode: 'signal'
    },
    {
      id: 'arc_panels',
      name: 'Arc Panels',
      desc: 'Panel UI with warm arcs + blocks.',
      palette: { a: '#ff9b32', b: '#ffd166', c: '#7c3aed' },
      uiMode: 'overview'
    },
    {
      id: 'coalition_hud',
      name: 'Coalition HUD',
      desc: 'HUD chrome with teal-violet pop.',
      palette: { a: '#00ffd5', b: '#7c3aed', c: '#56c2ff' },
      uiMode: 'command'
    },
    {
      id: 'frontier_terminal',
      name: 'Frontier Terminal',
      desc: 'Rugged terminal vibe with ember edges.',
      palette: { a: '#ffb000', b: '#56c2ff', c: '#22c55e' },
      uiMode: 'command'
    },
    {
      id: 'neon_grid',
      name: 'Neon Grid',
      desc: 'Electric gridlines + chromed glass.',
      palette: { a: '#00d9ff', b: '#00ffd5', c: '#a78bfa' },
      uiMode: 'nebula'
    },
    {
      id: 'neon_sunrise',
      name: 'Neon Sunrise',
      desc: 'Warm sunrise with neon trims.',
      palette: { a: '#00d9ff', b: '#ffb000', c: '#ff2d55' },
      uiMode: 'overview'
    },
    {
      id: 'crimson_override',
      name: 'Crimson Override',
      desc: 'Redline intensity. Everything feels urgent.',
      palette: { a: '#ff2d55', b: '#ff0038', c: '#00d9ff' },
      uiMode: 'signal'
    }
  ];

  function safeParse(raw) {
    try { return JSON.parse(raw); } catch { return null; }
  }

  // --- Color helpers (for logo harmonies) ---
  function clamp(n, a, b) { return Math.min(b, Math.max(a, n)); }

  function hexToRgb(hex) {
    const h = String(hex || '').replace('#','').trim();
    if (h.length === 3) {
      const r = parseInt(h[0] + h[0], 16);
      const g = parseInt(h[1] + h[1], 16);
      const b = parseInt(h[2] + h[2], 16);
      return { r, g, b };
    }
    if (h.length !== 6) return { r: 0, g: 0, b: 0 };
    return {
      r: parseInt(h.slice(0,2), 16),
      g: parseInt(h.slice(2,4), 16),
      b: parseInt(h.slice(4,6), 16)
    };
  }

  function rgbToHex(r,g,b) {
    const toHex = (v) => clamp(Math.round(v), 0, 255).toString(16).padStart(2,'0');
    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return { h: h * 360, s: s * 100, l: l * 100 };
  }

  function hslToRgb(h, s, l) {
    h = (h % 360 + 360) % 360;
    s = clamp(s, 0, 100) / 100;
    l = clamp(l, 0, 100) / 100;

    if (s === 0) {
      const v = l * 255;
      return { r: v, g: v, b: v };
    }

    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1/6) return p + (q - p) * 6 * t;
      if (t < 1/2) return q;
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    const hk = h / 360;
    const r = hue2rgb(p, q, hk + 1/3);
    const g = hue2rgb(p, q, hk);
    const b = hue2rgb(p, q, hk - 1/3);
    return { r: r * 255, g: g * 255, b: b * 255 };
  }

  function shiftHex(hex, { dh = 0, ds = 0, dl = 0 } = {}) {
    const { r, g, b } = hexToRgb(hex);
    const hsl = rgbToHsl(r, g, b);
    const rgb = hslToRgb(hsl.h + dh, hsl.s + ds, hsl.l + dl);
    return rgbToHex(rgb.r, rgb.g, rgb.b);
  }

  function computeLogoHarmonies(p) {
    // Goal: same logo design, harmonized per pack.
    // A = vivid primary, B = energetic secondary, C = bright core.
    const a = p.a;
    const b = p.b || shiftHex(p.a, { dh: 40, dl: 6 });
    const c = p.c || shiftHex(p.a, { dl: 14 });

    // Punch up for legibility on dark backgrounds
    const a2 = shiftHex(a, { dl: 6, ds: 4 });
    const b2 = shiftHex(b, { dl: 6, ds: 4 });
    const c2 = shiftHex(c, { dl: 10, ds: 2 });

    return { a: a2, b: b2, c: c2 };
  }

  function setRootVar(name, value) {
    try { document.documentElement.style.setProperty(name, value); } catch {}
  }

  function applyScheme(scheme) {
    document.documentElement.setAttribute('data-mode', scheme || 'system');
  }

  function applyFxScanlines(on) {
    if (on) document.documentElement.setAttribute('data-fx-scanlines', '');
    else document.documentElement.removeAttribute('data-fx-scanlines');

    if (on) document.body.classList.add('fx-scanlines');
    else document.body.classList.remove('fx-scanlines');
  }

  function applyUIMode(uiMode) {
    const m = UI_MODES.find(x => x.id === uiMode) || UI_MODES[0];
    Array.from(document.body.classList).forEach(c => {
      if (c.startsWith('mode-')) document.body.classList.remove(c);
    });
    document.body.classList.add(m.bodyClass);
    document.documentElement.setAttribute('data-ui', m.id);
  }

  function applyLegacyTheme(themeId) {
    document.documentElement.setAttribute('data-theme', themeId || DEFAULT_THEME);
  }

  function applyPack(packId) {
    const p = PACKS.find(x => x.id === packId) || PACKS[0];
    document.documentElement.setAttribute('data-pack', p.id);

    // Inject palette into root variables (CSS packs.css binds these tokens)
    setRootVar('--pack-a', p.palette.a);
    setRootVar('--pack-b', p.palette.b);
    setRootVar('--pack-c', p.palette.c);

    const h = computeLogoHarmonies(p.palette);
    setRootVar('--logo-a', h.a);
    setRootVar('--logo-b', h.b);
    setRootVar('--logo-c', h.c);

    // Hero badge label
    const heroName = byId('packHeroName');
    if (heroName) heroName.textContent = p.name;

    return p;
  }

  function clearPack() {
    document.documentElement.removeAttribute('data-pack');
    // keep vars as-is; legacy theme will drive visuals
    const heroName = byId('packHeroName');
    if (heroName) heroName.textContent = 'Custom';
  }

  function loadPref() {
    // New key
    const raw = localStorage.getItem(KEY);
    const obj = raw ? safeParse(raw) : null;
    if (obj && typeof obj === 'object') {
      return {
        pack: obj.pack || DEFAULTS.pack,
        scheme: obj.scheme || 'system',
        fx: !!obj.fx,
        advanced: !!obj.advanced,
        theme: obj.theme || DEFAULTS.theme,
        uiMode: obj.uiMode || DEFAULTS.uiMode
      };
    }

    // Back-compat (wnx.appearance.v3)
    const legacyRaw = localStorage.getItem(LEGACY_KEY);
    const legacy = legacyRaw ? safeParse(legacyRaw) : null;
    if (legacy && typeof legacy === 'object') {
      const theme = legacy.theme || DEFAULTS.theme;
      const uiMode = legacy.uiMode || DEFAULTS.uiMode;
      const scheme = legacy.scheme || legacy.mode || DEFAULTS.scheme;
      const fx = !!legacy.fx;
      const pack = mapThemeToPack(theme);
      const migrated = { ...DEFAULTS, pack, scheme, fx, advanced: false, theme, uiMode };
      try { localStorage.setItem(KEY, JSON.stringify(migrated)); } catch {}
      return migrated;
    }

    // Older keys
    const oldThemeRaw = localStorage.getItem(OLD_THEME_KEY);
    const oldThemeObj = oldThemeRaw ? safeParse(oldThemeRaw) : null;
    const oldUiMode = localStorage.getItem(OLD_UI_MODE_KEY);

    const theme = (oldThemeObj && oldThemeObj.theme) ? oldThemeObj.theme : DEFAULTS.theme;
    const scheme = (oldThemeObj && oldThemeObj.mode) ? oldThemeObj.mode : DEFAULTS.scheme;
    const fx = !!(oldThemeObj && oldThemeObj.fx);
    const uiMode = oldUiMode || DEFAULTS.uiMode;

    const migrated = { ...DEFAULTS, pack: mapThemeToPack(theme), scheme, fx, advanced: false, theme, uiMode };
    try { localStorage.setItem(KEY, JSON.stringify(migrated)); } catch {}
    return migrated;
  }

  function savePref(pref) {
    try { localStorage.setItem(KEY, JSON.stringify(pref)); } catch {}
  }

  function mapThemeToPack(themeId) {
    switch (themeId) {
      case 'tron_legacy': return 'neon_grid';
      case 'lcars': return 'arc_panels';
      case 'tardis_blue': return 'chrono_vortex';
      case 'paper_ink': return 'frontier_terminal';
      case 'grid_noir':
      default: return 'classic_dark';
    }
  }

  function applyAll(pref) {
    applyScheme(pref.scheme);
    applyFxScanlines(!!pref.fx);

    if (pref.advanced) {
      clearPack();
      applyLegacyTheme(pref.theme);
      applyUIMode(pref.uiMode);
      return;
    }

    const pack = applyPack(pref.pack);
    // Keep a stable base theme for any components that still rely on data-theme
    applyLegacyTheme('grid_noir');
    applyUIMode(pack.uiMode || pref.uiMode || DEFAULTS.uiMode);
  }

  // --- Modal UI ---
  function openModal() {
    const m = byId('themeModal');
    if (!m) return;
    m.classList.add('open');
    m.removeAttribute('aria-hidden');
  }

  function closeModal() {
    const m = byId('themeModal');
    if (!m) return;
    m.classList.remove('open');
    m.setAttribute('aria-hidden', 'true');
  }

  function getDocState() {
    return {
      pack: document.documentElement.getAttribute('data-pack') || DEFAULTS.pack,
      scheme: document.documentElement.getAttribute('data-mode') || 'system',
      fx: document.documentElement.hasAttribute('data-fx-scanlines') || document.body.classList.contains('fx-scanlines'),
      advanced: !!byId('advancedToggle')?.checked,
      theme: document.documentElement.getAttribute('data-theme') || DEFAULTS.theme,
      uiMode: document.documentElement.getAttribute('data-ui') || DEFAULTS.uiMode
    };
  }

  function populateThemeSelect(themeId) {
    const themeSelect = byId('themeSelect');
    if (!themeSelect) return;
    themeSelect.innerHTML = THEMES.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
    themeSelect.value = themeId || DEFAULTS.theme;
  }

  function populatePackGrid(selectedId) {
    const grid = byId('packGrid');
    if (!grid) return;

    grid.innerHTML = PACKS.map(p => {
      const sel = (p.id === selectedId) ? 'selected' : '';
      return `
        <div class="pack-card ${sel}" data-pack="${p.id}" role="button" tabindex="0"
             style="--p-a:${p.palette.a};--p-b:${p.palette.b};--p-c:${p.palette.c};">
          <div class="pack-name">${p.name}</div>
          <div class="pack-desc">${p.desc}</div>
          <div class="sw" aria-hidden="true">
            <span class="dot a"></span><span class="dot b"></span><span class="dot c"></span>
          </div>
        </div>
      `;
    }).join('');
  }

  function setAdvancedUI(on) {
    const adv = byId('advancedSection');
    if (adv) adv.hidden = !on;
  }

  function readForm() {
    const selectedCard = byId('packGrid')?.querySelector('.pack-card.selected');
    const pack = selectedCard ? selectedCard.getAttribute('data-pack') : DEFAULTS.pack;
    const scheme = byId('modeSelect')?.value || 'system';
    const fx = !!byId('fxScanlines')?.checked;
    const advanced = !!byId('advancedToggle')?.checked;
    const theme = byId('themeSelect')?.value || DEFAULTS.theme;
    const uiMode = byId('uiModeSelect')?.value || DEFAULTS.uiMode;
    return { pack, scheme, fx, advanced, theme, uiMode };
  }

  function populate(pref) {
    populatePackGrid(pref.pack || DEFAULTS.pack);
    const modeSelect = byId('modeSelect');
    if (modeSelect) modeSelect.value = pref.scheme || 'system';
    const fx = byId('fxScanlines');
    if (fx) fx.checked = !!pref.fx;

    const advToggle = byId('advancedToggle');
    if (advToggle) advToggle.checked = !!pref.advanced;
    setAdvancedUI(!!pref.advanced);
    populateThemeSelect(pref.theme || DEFAULTS.theme);
    const uiModeSelect = byId('uiModeSelect');
    if (uiModeSelect) uiModeSelect.value = pref.uiMode || DEFAULTS.uiMode;
  }

  function wirePackClicks(snapshotRef) {
    const grid = byId('packGrid');
    if (!grid) return;

    const selectPack = (id) => {
      grid.querySelectorAll('.pack-card').forEach(el => el.classList.remove('selected'));
      const card = grid.querySelector(`.pack-card[data-pack="${CSS.escape(id)}"]`);
      if (card) card.classList.add('selected');

      // Disable advanced overrides when picking a pack (single unified control)
      const advToggle = byId('advancedToggle');
      if (advToggle) {
        advToggle.checked = false;
        setAdvancedUI(false);
      }

      const pack = PACKS.find(p => p.id === id) || PACKS[0];
      const scheme = byId('modeSelect')?.value || 'system';
      const fx = !!byId('fxScanlines')?.checked;
      applyAll({ ...DEFAULTS, pack: pack.id, scheme, fx, advanced: false, theme: DEFAULTS.theme, uiMode: pack.uiMode });
    };

    grid.addEventListener('click', (e) => {
      const card = e.target?.closest ? e.target.closest('.pack-card') : null;
      if (!card) return;
      const id = card.getAttribute('data-pack');
      if (!id) return;
      selectPack(id);
    });

    grid.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const card = e.target?.closest ? e.target.closest('.pack-card') : null;
      if (!card) return;
      e.preventDefault();
      const id = card.getAttribute('data-pack');
      if (!id) return;
      selectPack(id);
    });
  }

  function wire() {
    const btn = byId('themeBtn');
    const modal = byId('themeModal');
    const closeBtn = byId('themeClose');

    // Apply saved pref immediately on load (even if modal is hidden)
    const saved = loadPref();
    applyAll(saved);

    // If the layout doesn't show the modal/btn on this page, stop after applying.
    if (!btn || !modal) return;

    let snapshot = null;
    populate(saved);

    const livePreview = () => {
      const pref = readForm();
      applyAll(pref);
    };

    btn.addEventListener('click', () => {
      snapshot = getDocState();
      const cur = loadPref();
      populate(cur);
      openModal();
      livePreview();
    });

    closeBtn?.addEventListener('click', () => {
      if (snapshot) applyAll(snapshot);
      closeModal();
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        if (snapshot) applyAll(snapshot);
        closeModal();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.classList.contains('open')) {
        if (snapshot) applyAll(snapshot);
        closeModal();
      }
    });

    // Live preview hooks
    byId('modeSelect')?.addEventListener('change', livePreview);
    byId('fxScanlines')?.addEventListener('change', livePreview);

    byId('advancedToggle')?.addEventListener('change', () => {
      const on = !!byId('advancedToggle')?.checked;
      setAdvancedUI(on);
      livePreview();
    });

    byId('themeSelect')?.addEventListener('change', livePreview);
    byId('uiModeSelect')?.addEventListener('change', livePreview);

    wirePackClicks(() => snapshot);

    byId('applyTheme')?.addEventListener('click', () => {
      const next = readForm();
      savePref(next);
      applyAll(next);
      snapshot = null;
      closeModal();
    });

    byId('resetTheme')?.addEventListener('click', () => {
      savePref(DEFAULTS);
      populate(DEFAULTS);
      applyAll(DEFAULTS);
    });

    window.addEventListener('wnx:page', () => {
      const cur = loadPref();
      applyAll(cur);
    });
  }

  document.addEventListener('DOMContentLoaded', wire);
})();
