<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
require_once __DIR__ . '/../../app/lib/import_chain.php';

header('Content-Type: application/json; charset=utf-8');

// Mod/Admin only
if (!has_role('mod')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Moderator or admin access required']);
  exit;
}

$acq = wnx_import_chain_acquire('sonarr', 'Sonarr', 900);
if (!$acq['ok']) {
  http_response_code(409);
  echo json_encode(['ok' => false, 'error' => $acq['error'] ?? 'Import already running', 'owner' => $acq['owner'] ?? null]);
  exit;
}
$ctx = $acq['ctx'];
wnx_import_chain_touch($ctx, 900);

$u = current_user();
$uid = (int)($u['id'] ?? 0);


// Environment capability checks (shared hosting safe-fail)
if (!class_exists('ZipArchive')) {
  wnx_import_progress_write($ctx, ['status' => 'ZipArchive missing on host', 'progress' => 0, 'done' => true]);
  wnx_import_chain_release('sonarr');
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'PHP ZipArchive extension is not available on this host. Enable php-zip to import Sonarr backups.']);
  exit;
}
if (!in_array('sqlite', PDO::getAvailableDrivers(), true)) {
  wnx_import_progress_write($ctx, ['status' => 'PDO SQLite missing on host', 'progress' => 0, 'done' => true]);
  wnx_import_chain_release('sonarr');
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'PDO SQLite driver is not available on this host. Enable pdo_sqlite to import Sonarr backup databases.']);
  exit;
}

// Check if file was uploaded
if (!isset($_FILES['sonarr_backup']) || ($_FILES['sonarr_backup']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
  wnx_import_progress_write($ctx, ['status' => 'No file uploaded or upload failed', 'progress' => 0, 'done' => true]);
  wnx_import_chain_release('sonarr');
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'No file uploaded or upload failed']);
  exit;
}

$uploadedFile = $_FILES['sonarr_backup']['tmp_name'];
$fileName = (string)($_FILES['sonarr_backup']['name'] ?? 'backup.zip');

// Verify it's a ZIP
if (!str_ends_with(strtolower($fileName), '.zip')) {
  wnx_import_progress_write($ctx, ['status' => 'Invalid file type (must be .zip)', 'progress' => 0, 'done' => true]);
  wnx_import_chain_release('sonarr');
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'File must be a ZIP archive']);
  exit;
}

$pdo = db();
$tempDir = sys_get_temp_dir() . '/sonarr_import_' . uniqid();

try {
  wnx_import_progress_write($ctx, ['status' => 'Extracting backup...', 'progress' => 5, 'current' => 0, 'total' => 100, 'done' => false]);
  wnx_import_chain_touch($ctx, 900);

  if (!mkdir($tempDir, 0700, true)) {
    throw new Exception('Failed to create temporary directory');
  }

  $zip = new ZipArchive();
  if ($zip->open($uploadedFile) !== true) {
    throw new Exception('Failed to open ZIP file');
  }
  $zip->extractTo($tempDir);
  $zip->close();

  wnx_import_progress_write($ctx, ['status' => 'Finding sonarr.db...', 'progress' => 15, 'done' => false]);
  wnx_import_chain_touch($ctx, 900);

  $dbPath = null;
  $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tempDir, RecursiveDirectoryIterator::SKIP_DOTS));
  foreach ($iterator as $file) {
    if ($file->isFile() && $file->getFilename() === 'sonarr.db') {
      $dbPath = $file->getPathname();
      break;
    }
  }
  if (!$dbPath) {
    throw new Exception('sonarr.db not found in backup archive');
  }

  $sonarrDb = new PDO('sqlite:' . $dbPath);
  $sonarrDb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  wnx_import_progress_write($ctx, ['status' => 'Reading Sonarr database...', 'progress' => 25, 'done' => false]);
  wnx_import_chain_touch($ctx, 900);

  $stmt = $sonarrDb->query("SELECT TvdbId, Title, Monitored FROM Series WHERE Monitored = 1");
  $monitoredShows = $stmt->fetchAll(PDO::FETCH_ASSOC);
  $totalMonitored = count($monitoredShows);

  if ($totalMonitored === 0) {
    wnx_import_progress_write($ctx, ['status' => 'No monitored shows found', 'progress' => 100, 'done' => true]);
    wnx_import_chain_release('sonarr');
    echo json_encode([
      'ok' => true,
      'tracked' => 0,
      'matched' => 0,
      'total_monitored' => 0,
      'unmatched' => [],
      'message' => 'No monitored shows found in Sonarr backup'
    ], JSON_PRETTY_PRINT);
    exit;
  }

  wnx_import_progress_write($ctx, ['status' => "Matching $totalMonitored shows...", 'progress' => 35, 'current' => 0, 'total' => $totalMonitored, 'done' => false]);
  wnx_import_chain_touch($ctx, 900);

  $pdo->beginTransaction();

  $tracked = 0;
  $matched = 0;
  $unmatched = [];

  foreach ($monitoredShows as $index => $show) {
    $tvdbId = (string)($show['TvdbId'] ?? '');
    $title = (string)($show['Title'] ?? '');

    if ($index % 10 === 0) {
      $pct = 35 + (int)(($index / max(1, $totalMonitored)) * 60);
      wnx_import_progress_write($ctx, [
        'status' => "Matching shows... ($index/$totalMonitored)",
        'progress' => $pct,
        'current' => $index,
        'total' => $totalMonitored,
        'done' => false
      ]);
      wnx_import_chain_touch($ctx, 900);
    }

    // Match by TVDb ID
    $st = $pdo->prepare("SELECT s.id FROM shows s
      JOIN show_external_ids sei ON sei.show_id = s.id
      WHERE sei.provider IN ('thetvdb','tvdb') AND sei.external_id = ?
      LIMIT 1");
    $st->execute([$tvdbId]);
    $showId = $st->fetchColumn();

    // Fallback: exact title match
    if (!$showId && $title !== '') {
      $st = $pdo->prepare("SELECT id FROM shows WHERE LOWER(title) = LOWER(?) LIMIT 1");
      $st->execute([$title]);
      $showId = $st->fetchColumn();
    }

    if (!$showId) {
      if ($title !== '') $unmatched[] = $title;
      continue;
    }

    $matched++;

    $st = $pdo->prepare("SELECT 1 FROM user_tracked_shows WHERE user_id = ? AND show_id = ?");
    $st->execute([$uid, $showId]);
    if ($st->fetchColumn()) continue;

    $ins = $pdo->prepare("INSERT INTO user_tracked_shows (user_id, show_id) VALUES (?, ?)");
    $ins->execute([$uid, $showId]);
    $tracked++;
  }

  $pdo->commit();

  wnx_import_progress_write($ctx, ['status' => 'Completed!', 'progress' => 100, 'done' => true, 'current' => $totalMonitored, 'total' => $totalMonitored]);
  wnx_import_chain_release('sonarr');

  echo json_encode([
    'ok' => true,
    'tracked' => $tracked,
    'matched' => $matched,
    'total_monitored' => $totalMonitored,
    'unmatched' => $unmatched
  ], JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  if (isset($pdo) && $pdo->inTransaction()) {
    $pdo->rollBack();
  }

  wnx_import_progress_write($ctx, [
    'status' => 'Failed: ' . ((defined('WNX_DEBUG') && WNX_DEBUG) ? $e->getMessage() : 'Internal error'),
    'progress' => 0,
    'done' => true
  ]);

  wnx_import_chain_release('sonarr');

  http_response_code(500);
  echo json_encode([
    'ok' => false,
    'error' => (defined('WNX_DEBUG') && WNX_DEBUG) ? $e->getMessage() : 'Internal server error',
    ...((defined('WNX_DEBUG') && WNX_DEBUG) ? ['file' => $e->getFile(), 'line' => $e->getLine()] : [])
  ]);
} finally {
  // Clean up temp directory
  if (isset($tempDir) && is_dir($tempDir)) {
    $files = new RecursiveIteratorIterator(
      new RecursiveDirectoryIterator($tempDir, RecursiveDirectoryIterator::SKIP_DOTS),
      RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($files as $file) {
      if ($file->isDir()) @rmdir($file->getRealPath());
      else @unlink($file->getRealPath());
    }

    @rmdir($tempDir);
  }
}
