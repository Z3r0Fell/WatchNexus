<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

if (!has_role('mod')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Mod only']);
  exit;
}

$limit = (int)($_GET['limit'] ?? 25);
if ($limit < 1) $limit = 1;
if ($limit > 100) $limit = 100;

$overwrite = (int)($_GET['overwrite'] ?? 0) === 1;

$pdo = db();

try {
  $sql = "
    SELECT s.id, s.title, s.description, s.premiered, s.poster_url, tv.external_id AS tvdb_id
    FROM shows s
    JOIN show_external_ids tv ON tv.show_id = s.id AND tv.provider = 'thetvdb'
  ";
  if (!$overwrite) {
    $sql .= " WHERE (s.description IS NULL OR s.description = '' OR s.premiered IS NULL OR s.poster_url IS NULL OR s.poster_url = '') ";
  }
  $sql .= " ORDER BY s.id ASC LIMIT ?";

  $st = $pdo->prepare($sql);
  $st->execute([$limit]);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC);

  $updated = 0;
  $skipped = 0;
  $errors = [];

  $upd = $pdo->prepare("
    UPDATE shows
    SET
      description = CASE WHEN ? THEN ? ELSE COALESCE(NULLIF(description,''), ?) END,
      premiered   = CASE WHEN ? THEN ? ELSE COALESCE(premiered, ?) END,
      poster_url  = CASE WHEN ? THEN ? ELSE COALESCE(NULLIF(poster_url,''), ?) END
    WHERE id = ?
  ");

  foreach ($rows as $r) {
    $showId = (int)$r['id'];
    $tvdbId = (int)($r['tvdb_id'] ?? 0);
    if ($tvdbId <= 0) { $skipped++; continue; }

    try {
      $resp = tvdb_get_series_base($tvdbId);
      $d = $resp['data'] ?? null;
      if (!is_array($d)) { $skipped++; continue; }

      $overview = trim((string)($d['overview'] ?? ''));
      $overview = trim(strip_tags($overview));
      $firstAired = trim((string)($d['firstAired'] ?? ''));
      $image = trim((string)($d['image'] ?? ''));

      $prem = null;
      if ($firstAired !== '') {
        $ts = strtotime($firstAired);
        if ($ts !== false) $prem = gmdate('Y-m-d', $ts);
      }

      $descNew = $overview !== '' ? $overview : null;
      $posterNew = $image !== '' ? $image : null;

      // Overwrite flags
      $w = $overwrite;

      $upd->execute([
        $w, $descNew, $descNew,
        $w, $prem, $prem,
        $w, $posterNew, $posterNew,
        $showId
      ]);

      $updated++;
      usleep(120000);
    } catch (Throwable $inner) {
      $errors[] = "Show#$showId TVDB#$tvdbId: " . $inner->getMessage();
      continue;
    }
  }

  echo json_encode([
    'ok' => true,
    'checked' => count($rows),
    'updated' => $updated,
    'skipped' => $skipped,
    'errors' => $errors,
  ], JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  $debug = (getenv('WNX_DEBUG') === '1');
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $debug ? $e->getMessage() : 'Internal server error']);
}
