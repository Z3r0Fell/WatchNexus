<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';

ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok'=>false,'error'=>'POST required']);
  exit;
}

$u = current_user();
if (!$u) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Login required']);
  exit;
}

$uid = (int)($u['id'] ?? 0);
if ($uid <= 0) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Invalid session user']);
  exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw ?: '[]', true);
if (!is_array($data)) $data = [];

$theme_id = (string)($data['theme_id'] ?? '');
$theme_mode = (string)($data['theme_mode'] ?? '');
$fx_scanlines = !empty($data['fx_scanlines']) ? 1 : 0;

$modules = $data['modules'] ?? [];
if (!is_array($modules)) $modules = [];

$allowedModes = ['system','light','dark'];

$pdo = db();

try {
  // Ensure settings row exists
  $pdo->prepare("INSERT IGNORE INTO user_settings (user_id) VALUES (?)")->execute([$uid]);

  // Update appearance fields if provided
  $fields = [];
  $vals = [];

  if ($theme_id !== '') {
    $fields[] = "theme_id = ?";
    $vals[] = $theme_id;
  }
  if ($theme_mode !== '' && in_array($theme_mode, $allowedModes, true)) {
    $fields[] = "theme_mode = ?";
    $vals[] = $theme_mode;
  }
  $fields[] = "fx_scanlines = ?";
  $vals[] = $fx_scanlines;

  if ($fields) {
    $vals[] = $uid;
    $pdo->prepare("UPDATE user_settings SET " . implode(', ', $fields) . " WHERE user_id = ?")->execute($vals);
  }

  // Save module overrides
  // Note: forced/disabled modules still exist in UI as disabled; we don't enforce here.
  $stIns = $pdo->prepare("
    INSERT INTO user_module_overrides (user_id, module_id, enabled)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE enabled = VALUES(enabled)
  ");

  foreach ($modules as $mid => $enabled) {
    $mid = trim((string)$mid);
    if ($mid === '' || strlen($mid) > 64) continue;
    $stIns->execute([$uid, $mid, ($enabled ? 1 : 0)]);
  }

  echo json_encode(['ok'=>true], JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode([
    'ok'=>false,
    'error'=>'Internal server error'
  ], JSON_PRETTY_PRINT);
}
