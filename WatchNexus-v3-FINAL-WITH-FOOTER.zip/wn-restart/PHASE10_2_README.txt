Phase 10.2 Overlay (Config Hardening)

1) Upload the overlay files, preserving paths.
2) On the server, COPY:
   app/config/config.local.example.php  ->  app/config/config.local.php
3) Edit app/config/config.local.php and paste:
   - DB host/name/user/pass
   - secret_key_b64 (base64 of 32 random bytes)
   Generate with:
     php -r "echo base64_encode(random_bytes(32)).PHP_EOL;"
4) Keep app/config/config.php secret-free.
5) Optional: enable debug temporarily by setting 'debug' => true in config.local.php
   or environment variable WNX_DEBUG=1 (if your host supports it).

Verify:
- /health.php returns OK
- /test_apis.php returns PASS
