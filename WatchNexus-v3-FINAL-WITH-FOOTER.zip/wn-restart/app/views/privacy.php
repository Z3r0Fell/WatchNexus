<div class="card">
  <div class="hd">
    <h1>Privacy Policy</h1>
  </div>
  <div class="bd">
    <p class="small muted">Last updated: January 9, 2026</p>
    
    <h2>Introduction</h2>
    <p>
      WatchNexus ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our TV show tracking service.
    </p>
    
    <h2>Information We Collect</h2>
    
    <h3>Account Information</h3>
    <p>When you register for WatchNexus, we collect:</p>
    <ul>
      <li><strong>Email address:</strong> Used for account identification and communication</li>
      <li><strong>Display name:</strong> Used for personalization within the service</li>
      <li><strong>Password:</strong> Stored as a one-way hash using Argon2id (not reversible)</li>
    </ul>
    
    <h3>Usage Information</h3>
    <p>We automatically collect:</p>
    <ul>
      <li><strong>Tracked shows:</strong> TV shows you choose to follow</li>
      <li><strong>Integration configurations:</strong> Your connections to third-party services (Trakt, Seedr, Jackett, Prowlarr)</li>
      <li><strong>User preferences:</strong> Theme settings, UI modes, and display options</li>
      <li><strong>Session data:</strong> Login timestamps and authentication tokens</li>
    </ul>
    
    <h3>Third-Party Service Credentials</h3>
    <p>
      When you configure integrations, we store your API keys and credentials encrypted at rest using libsodium (XChaCha20-Poly1305). We never share these credentials with anyone except the services you explicitly authorize.
    </p>
    
    <h2>How We Use Your Information</h2>
    <p>We use your information to:</p>
    <ul>
      <li>Provide and maintain the WatchNexus service</li>
      <li>Personalize your experience (tracked shows, themes, preferences)</li>
      <li>Connect to third-party services on your behalf (when you authorize)</li>
      <li>Communicate important service updates or security notifications</li>
      <li>Improve our service through aggregated, anonymized usage analytics</li>
    </ul>
    
    <h2>Data Storage and Security</h2>
    
    <h3>Encryption</h3>
    <p>We implement industry-standard security measures:</p>
    <ul>
      <li><strong>Passwords:</strong> Hashed with Argon2id (irreversible one-way encryption)</li>
      <li><strong>API Keys & Secrets:</strong> Encrypted with libsodium XChaCha20-Poly1305</li>
      <li><strong>Database:</strong> Stored on secure servers with access controls</li>
      <li><strong>Transmission:</strong> HTTPS encryption for all data in transit (when properly configured)</li>
    </ul>
    
    <h3>Data Retention</h3>
    <p>
      We retain your account data as long as your account is active. You can request account deletion by contacting <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a>. Upon deletion, we will remove your personal data within 30 days, except where retention is required by law.
    </p>
    
    <h2>Third-Party Services</h2>
    <p>
      WatchNexus integrates with third-party services to provide functionality. When you configure these integrations, you are subject to their respective privacy policies:
    </p>
    <ul>
      <li><strong>TVMaze:</strong> <a href="https://www.tvmaze.com/api" target="_blank" rel="noopener">TVMaze API</a> (TV schedule data)</li>
      <li><strong>Trakt:</strong> <a href="https://trakt.tv/privacy" target="_blank" rel="noopener">Trakt Privacy Policy</a> (show tracking & sync)</li>
      <li><strong>Seedr:</strong> <a href="https://www.seedr.cc/privacy" target="_blank" rel="noopener">Seedr Privacy Policy</a> (cloud storage)</li>
      <li><strong>Jackett/Prowlarr:</strong> Self-hosted services (your own server)</li>
    </ul>
    <p>
      We access these services <strong>only when you explicitly configure and authorize the connection</strong>. We do not share your data with these services beyond what is necessary to provide the requested functionality.
    </p>
    
    <h2>Cookies and Tracking</h2>
    <p>
      We use minimal cookies for essential functionality:
    </p>
    <ul>
      <li><strong>Session Cookie:</strong> Keeps you logged in (required for authentication)</li>
      <li><strong>Preferences Cookie:</strong> Stores theme and UI settings (optional, stored locally)</li>
    </ul>
    <p>
      We <strong>do not use</strong> tracking cookies, advertising cookies, or third-party analytics services.
    </p>
    
    <h2>Your Rights</h2>
    <p>You have the right to:</p>
    <ul>
      <li><strong>Access:</strong> Request a copy of your personal data</li>
      <li><strong>Correction:</strong> Update or correct inaccurate information</li>
      <li><strong>Deletion:</strong> Request deletion of your account and associated data</li>
      <li><strong>Portability:</strong> Export your tracked shows and preferences</li>
      <li><strong>Opt-Out:</strong> Disconnect integrations at any time</li>
    </ul>
    <p>
      To exercise these rights, contact us at <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a>.
    </p>
    
    <h2>Children's Privacy</h2>
    <p>
      WatchNexus is not intended for users under 13 years of age. We do not knowingly collect personal information from children. If we discover that a child under 13 has provided personal information, we will delete it immediately.
    </p>
    
    <h2>International Users</h2>
    <p>
      WatchNexus is hosted in Canada. By using our service, you consent to the transfer and processing of your data in Canada. We comply with applicable Canadian privacy laws (PIPEDA).
    </p>
    
    <h2>Changes to This Policy</h2>
    <p>
      We may update this Privacy Policy periodically. Material changes will be communicated via email or prominent notice on the service. Continued use after changes constitutes acceptance of the updated policy.
    </p>
    
    <h2>Contact Us</h2>
    <p>
      If you have questions or concerns about this Privacy Policy, please contact us:
    </p>
    <p>
      <strong>Email:</strong> <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a><br>
      <strong>Service:</strong> WatchNexus<br>
      <strong>Location:</strong> Canada
    </p>
  </div>
</div>

<style>
.bd h2 {
  font-size: 1.3rem;
  margin-top: 32px;
  margin-bottom: 12px;
  color: var(--primary);
}

.bd h3 {
  font-size: 1.1rem;
  margin-top: 20px;
  margin-bottom: 10px;
  color: var(--text);
}

.bd p {
  line-height: 1.6;
  margin-bottom: 16px;
}

.bd ul {
  margin-bottom: 16px;
  padding-left: 24px;
  line-height: 1.6;
}

.bd li {
  margin-bottom: 8px;
}

.bd a {
  color: var(--primary);
  text-decoration: underline;
}

.bd a:hover {
  color: var(--accent);
}
</style>
