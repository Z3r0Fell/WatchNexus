<?php
declare(strict_types=1);
require_role_html('mod');
?>
<div class="card">
  <div class="hd"><h2>Mod Tools</h2><div class="spacer"></div><span class="small">RBAC-gated</span></div>
  <div class="bd">
    <p class="m0">This is where importers and catalog maintenance tools live.</p>
    <div class="mt16 grid2">
      <div class="card">
        <div class="hd"><h2>TVMaze Importer</h2></div>
        <div class="bd">
          <p class="small">Import TV show schedules from TVMaze. This will populate your calendar with real airing dates.</p>
          
          <div style="margin-top:14px;">
            <label class="small muted" style="display:block;">Start Date</label>
            <input type="date" id="tvmaze-start" value="<?= date('Y-m-d') ?>" style="width:100%;padding:8px;margin-top:4px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;">
          </div>
          
          <div style="margin-top:14px;">
            <label class="small muted" style="display:block;">End Date</label>
            <input type="date" id="tvmaze-end" value="<?= date('Y-m-d', strtotime('+30 days')) ?>" style="width:100%;padding:8px;margin-top:4px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;">
          </div>
          
          <div style="margin-top:14px;">
            <label class="small muted" style="display:block;">Country</label>
            <select id="tvmaze-country" style="width:100%;padding:8px;margin-top:4px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;">
              <option value="US">United States</option>
              <option value="GB">United Kingdom</option>
              <option value="CA">Canada</option>
              <option value="AU">Australia</option>
            </select>
          </div>
          
          <div style="margin-top:16px;">
            <button class="btn primary" id="run-tvmaze-import" type="button">Start Import</button>
            <div id="tvmaze-status" style="margin-top:12px;"></div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="hd"><h2>Sonarr Import</h2></div>
        <div class="bd">
          <p class="small">Upload your Sonarr backup to automatically track all monitored shows.</p>
          
          <div style="margin-top:16px;padding:14px;border:1px solid rgba(255,165,0,0.3);border-radius:8px;background:rgba(255,165,0,0.05);">
            <p class="small" style="margin:0 0 8px;"><strong>How to export from Sonarr:</strong></p>
            <ol class="small" style="margin:0;padding-left:20px;line-height:1.6;">
              <li>Go to Sonarr → System → Backup</li>
              <li>Click "Backup Now"</li>
              <li>Download the ZIP file (e.g., sonarr_backup_2026.01.08.zip)</li>
              <li>Upload it here</li>
            </ol>
          </div>
          
          <div style="margin-top:16px;">
            <label class="small muted" style="display:block;margin-bottom:8px;">Sonarr Backup ZIP</label>
            <input type="file" id="sonarr-file" accept=".zip" style="width:100%;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;">
          </div>
          
          <div style="margin-top:16px;">
            <button class="btn primary" id="run-sonarr-import" type="button">Import from Sonarr</button>
            <div id="sonarr-status" style="margin-top:12px;"></div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="hd"><h2>Other Importers</h2></div>
        <div class="bd">
          <p class="small m0">Additional import sources (coming soon):</p>
          <ul class="small" style="margin:12px 0 0; padding-left:18px; line-height:1.5">
            <li>AniList anime import</li>
            <li>Trakt sync (user-scoped)</li>
          </ul>
          <div class="mt16 row wrap">
            <button class="btn" type="button" disabled>Run Import (coming soon)</button>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="hd"><h2>TheTVDB v4 Enrichment</h2></div>
        <div class="bd">
          <p class="small">Step 1: backfill <b>TVDB IDs</b> from TVMaze externals. Step 2: enrich shows with <b>overviews</b>, <b>premiere dates</b>, and <b>poster art</b> from TheTVDB.</p>

          <div style="margin-top:12px;">
            <label class="small muted" style="display:block;">Batch size</label>
            <input type="number" id="tvdb-limit" value="25" min="1" max="100" style="width:100%;padding:8px;margin-top:4px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;">
          </div>

          <div class="mt16 row wrap" style="gap:10px;">
            <button class="btn" type="button" id="tvdb-backfill-btn">Backfill TVDB IDs</button>
            <button class="btn" type="button" id="tvdb-enrich-btn">Enrich from TVDB</button>
            <button class="btn secondary" type="button" id="tvdb-enrich-overwrite-btn" title="Overwrite existing description/premiered/poster_url">Enrich (overwrite)</button>
          </div>

          <pre id="tvdb-out" style="margin-top:12px;max-height:220px;overflow:auto;padding:10px;border-radius:10px;background:rgba(0,0,0,0.25);border:1px solid rgba(255,255,255,0.12);white-space:pre-wrap;">Ready.</pre>
        </div>
      </div>

    </div>
  </div>
</div>

<script>
console.log('Mod Tools JavaScript loaded');

// TVMaze Import Handler (chunked to avoid timeouts on shared hosting)
document.getElementById('run-tvmaze-import')?.addEventListener('click', async function() {
  console.log('TVMaze import button clicked');

  const btn = this;
  const status = document.getElementById('tvmaze-status');
  let start = document.getElementById('tvmaze-start').value;
  const end = document.getElementById('tvmaze-end').value;
  const country = document.getElementById('tvmaze-country').value;

  // default chunk size (days per request)
  const chunkDays = 7;

  console.log('Import params:', {start, end, country, chunkDays});

  if (!start || !end) {
    status.innerHTML = '<p class="error">Please select start and end dates.</p>';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Importing...';
  status.innerHTML = `<p class="small muted">Starting TVMaze import in ${chunkDays}-day chunks... (this prevents IONOS timeouts)</p>`;

  const totals = { imported: 0, skipped: 0, shows_created: 0, events_created: 0, errors: [] };

  async function runChunk(chunkStart) {
    const url = `/api/import_tvmaze.php?start=${chunkStart}&end=${end}&country=${encodeURIComponent(country)}&chunk_days=${chunkDays}`;
    console.log('Fetching:', url);

    const resp = await fetch(url);

    if (resp.status === 409) {
      let d = null;
      try { d = await resp.json(); } catch (_) {}
      throw new Error((d && d.error) ? d.error : 'Import already running');
    }

    const text = await resp.text();
    let data;
    try { data = JSON.parse(text); } catch (e) {
      throw new Error('Invalid JSON response: ' + text.substring(0, 200));
    }

    if (!resp.ok || !data.ok) {
      throw new Error(data && data.error ? data.error : (`HTTP ${resp.status}`));
    }

    // accumulate totals
    totals.imported += (data.imported || 0);
    totals.skipped += (data.skipped || 0);
    totals.shows_created += (data.shows_created || 0);
    totals.events_created += (data.events_created || 0);
    if (Array.isArray(data.errors) && data.errors.length) totals.errors.push(...data.errors);

    // live status
    const sub = data.done
      ? 'Finalizing...'
      : `Chunk complete (${data.chunk_range}). Continuing...`;

    status.innerHTML = `
      <div class="card" style="margin-top:12px;border:1px solid rgba(0,150,255,0.22);background:rgba(0,150,255,0.05);">
        <div class="bd">
          <p class="small" style="margin:0 0 6px;"><strong>TVMaze Import</strong> — ${sub}</p>
          <p class="small muted" style="margin:0;">Overall range: ${data.date_range || 'N/A'}</p>
          <p class="small muted" style="margin:6px 0 0;">Created so far: <strong>${totals.events_created}</strong> events, <strong>${totals.shows_created}</strong> shows (skipped: ${totals.skipped})</p>
        </div>
      </div>
    `;

    if (!data.done && data.next_start) {
      await new Promise(r => setTimeout(r, 250));
      return runChunk(data.next_start);
    }

    return data;
  }

  try {
    const final = await runChunk(start);

    let html = `
      <div class="card" style="margin-top:12px;background:rgba(0,255,0,0.1);border:1px solid rgba(0,255,0,0.3);">
        <div class="bd">
          <p class="small"><strong>Import Complete!</strong></p>
          <ul class="small" style="margin:8px 0 0;padding-left:18px;">
            <li><strong>${totals.events_created || 0}</strong> events created</li>
            <li><strong>${totals.shows_created || 0}</strong> new shows added</li>
            <li><strong>${totals.skipped || 0}</strong> duplicates skipped</li>
            <li>Date range: ${final.date_range || 'N/A'}</li>
          </ul>
    `;

    if (totals.errors.length > 0) {
      html += `
        <details style="margin-top:8px;">
          <summary class="small">Errors (${totals.errors.length})</summary>
          <ul class="small" style="margin:4px 0 0;padding-left:18px;">
            ${totals.errors.map(e => `<li>${e}</li>`).join('')}
          </ul>
        </details>
      `;
    }

    html += `
          <p class="small muted" style="margin-top:12px;">
            Go to <a href="?page=calendar">Calendar</a> to see the imported events!
          </p>
        </div>
      </div>
    `;

    status.innerHTML = html;
  } catch (err) {
    console.error('TVMaze import error:', err);
    status.innerHTML = `<p class="error"><strong>Import failed:</strong> ${err.message}<br><small>Check browser console (F12) for details</small></p>`;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Start Import';
  }
});

// Sonarr Import Handler
// Sonarr Import Handler
document.getElementById('run-sonarr-import')?.addEventListener('click', async function() {
  console.log('Sonarr import button clicked');
  
  const btn = this;
  const status = document.getElementById('sonarr-status');
  const fileInput = document.getElementById('sonarr-file');
  const file = fileInput.files[0];
  
  console.log('File selected:', file);
  
  if (!file) {
    status.innerHTML = '<p class="error">Please select a Sonarr backup ZIP file first.</p>';
    return;
  }
  
  if (!file.name.endsWith('.zip')) {
    status.innerHTML = '<p class="error">File must be a ZIP archive.</p>';
    return;
  }
  
  btn.disabled = true;
  btn.textContent = 'Uploading...';
  status.innerHTML = '<p class="small muted">Uploading backup file...</p>';
  
  const formData = new FormData();
  formData.append('sonarr_backup', file);
  
  console.log('Uploading file:', file.name, file.size, 'bytes');
  
  try {
    const resp = await fetch('/api/import_sonarr.php', {
      method: 'POST',
      body: formData
    });
    
    console.log('Response status:', resp.status);
    
    if (!resp.ok) {
      const errorText = await resp.text();
      console.error('HTTP error:', resp.status, errorText);
      status.innerHTML = `<p class="error"><strong>HTTP ${resp.status}:</strong> ${errorText.substring(0, 200)}</p>`;
      btn.disabled = false;
      btn.textContent = 'Import from Sonarr';
      return;
    }
    
    const text = await resp.text();
    console.log('Response text:', text.substring(0, 500));
    
    let data;
    try {
      data = JSON.parse(text);
    } catch (parseErr) {
      console.error('JSON parse error:', parseErr);
      status.innerHTML = `<p class="error"><strong>Invalid JSON response:</strong> ${text.substring(0, 200)}</p>`;
      btn.disabled = false;
      btn.textContent = 'Import from Sonarr';
      return;
    }
    
    console.log('Parsed data:', data);
    
    if (!data.ok) {
      status.innerHTML = `<p class="error"><strong>Import failed:</strong> ${data.error || 'Unknown error'}</p>`;
      btn.disabled = false;
      btn.textContent = 'Import from Sonarr';
      return;
    }
    
    let html = `
      <div class="card" style="margin-top:12px;background:rgba(0,255,0,0.1);border:1px solid rgba(0,255,0,0.3);">
        <div class="bd">
          <p class="small"><strong>Sonarr Import Complete!</strong></p>
          <ul class="small" style="margin:8px 0 0;padding-left:18px;">
            <li><strong>${data.tracked || 0}</strong> shows auto-tracked</li>
            <li><strong>${data.matched || 0}</strong> shows matched in database</li>
            <li><strong>${data.total_monitored || 0}</strong> monitored shows in Sonarr</li>
          </ul>
    `;
    
    if (data.unmatched && data.unmatched.length > 0) {
      html += `
        <details style="margin-top:12px;">
          <summary class="small">Unmatched Shows (${data.unmatched.length})</summary>
          <ul class="small" style="margin:4px 0 0;padding-left:18px;">
            ${data.unmatched.map(s => `<li>${s}</li>`).join('')}
          </ul>
          <p class="small muted" style="margin-top:8px;">These shows aren't in our database yet. Import TV schedule from TVMaze first.</p>
        </details>
      `;
    }
    
    html += `
          <p class="small muted" style="margin-top:12px;">
            Go to <a href="?page=myshows">My Shows</a> to see your tracked shows!
          </p>
        </div>
      </div>
    `;
    
    status.innerHTML = html;
    btn.disabled = false;
    btn.textContent = 'Import from Sonarr';
    fileInput.value = '';
    
  } catch (err) {
    console.error('Sonarr import error:', err);
    status.innerHTML = `<p class="error"><strong>Request failed:</strong> ${err.message}<br><small>Check browser console (F12) for details</small></p>`;
    btn.disabled = false;
    btn.textContent = 'Import from Sonarr';
  }
});

console.log('Mod Tools JavaScript complete');

// --- TVDB enrichment ---
(function wireTvdbTools() {
  const out = document.getElementById('tvdb-out');
  const limitEl = document.getElementById('tvdb-limit');
  const btnBackfill = document.getElementById('tvdb-backfill-btn');
  const btnEnrich = document.getElementById('tvdb-enrich-btn');
  const btnOverwrite = document.getElementById('tvdb-enrich-overwrite-btn');
  if (!out || !limitEl || !btnBackfill || !btnEnrich || !btnOverwrite) return;

  const log = (msg) => { out.textContent = msg; };

  const getLimit = () => {
    let n = parseInt(limitEl.value || '25', 10);
    if (!Number.isFinite(n) || n < 1) n = 25;
    if (n > 100) n = 100;
    return n;
  };

  async function call(url) {
    const resp = await fetch(url);
    const txt = await resp.text();
    let data = null;
    try { data = JSON.parse(txt); } catch (_) {}
    if (!resp.ok || !data || !data.ok) {
      throw new Error((data && data.error) ? data.error : `HTTP ${resp.status}: ${txt.substring(0, 120)}`);
    }
    return data;
  }

  btnBackfill.addEventListener('click', async () => {
    const limit = getLimit();
    btnBackfill.disabled = true;
    log('Backfilling TVDB IDs from TVMaze...');
    try {
      const data = await call(`/api/tvdb_backfill_ids.php?limit=${limit}`);
      log(`Backfill complete. Checked: ${data.checked}, Updated: ${data.updated}, Skipped: ${data.skipped}` + (data.errors && data.errors.length ? `\nErrors:\n- ${data.errors.join('\n- ')}` : ''));
    } catch (e) {
      log(e && e.message ? e.message : 'Backfill failed');
    } finally {
      btnBackfill.disabled = false;
    }
  });

  btnEnrich.addEventListener('click', async () => {
    const limit = getLimit();
    btnEnrich.disabled = true;
    log('Enriching from TheTVDB (missing fields only)...');
    try {
      const data = await call(`/api/tvdb_enrich.php?limit=${limit}`);
      log(`Enrich complete. Checked: ${data.checked}, Updated: ${data.updated}, Skipped: ${data.skipped}` + (data.errors && data.errors.length ? `\nErrors:\n- ${data.errors.join('\n- ')}` : ''));
    } catch (e) {
      log(e && e.message ? e.message : 'Enrich failed');
    } finally {
      btnEnrich.disabled = false;
    }
  });

  btnOverwrite.addEventListener('click', async () => {
    const limit = getLimit();
    btnOverwrite.disabled = true;
    log('Enriching from TheTVDB (OVERWRITE enabled)...');
    try {
      const data = await call(`/api/tvdb_enrich.php?limit=${limit}&overwrite=1`);
      log(`Enrich (overwrite) complete. Checked: ${data.checked}, Updated: ${data.updated}, Skipped: ${data.skipped}` + (data.errors && data.errors.length ? `\nErrors:\n- ${data.errors.join('\n- ')}` : ''));
    } catch (e) {
      log(e && e.message ? e.message : 'Enrich failed');
    } finally {
      btnOverwrite.disabled = false;
    }
  });
})();

</script>
