<div class="card">
  <div class="hd">
    <h2>Browse Shows</h2>
    <div class="spacer"></div>
    <span class="small muted" id="show-count">Loading...</span>
  </div>
  <div class="bd">
    
    <!-- Search & Filters -->
    <div style="display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap;align-items:center;">
      <input 
        type="text" 
        id="search-input" 
        placeholder="Search shows..." 
        style="flex:1;min-width:250px;padding:10px 16px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;font-size:0.95rem;"
      >
      
      <select id="status-filter" style="padding:10px 16px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;cursor:pointer;">
        <option value="">All Status</option>
        <option value="running">Running</option>
        <option value="ended">Ended</option>
        <option value="development">In Development</option>
      </select>
      <select id="tracked-filter" style="padding:10px 16px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;cursor:pointer;">
        <option value="">All</option>
        <option value="tracked">✅ Tracked only</option>
      </select>
      
      <select id="sort-by" style="padding:10px 16px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;cursor:pointer;">
        <option value="title_asc">Title A-Z</option>
        <option value="title_desc">Title Z-A</option>
        <option value="premiered_desc">Newest First</option>
        <option value="premiered_asc">Oldest First</option>
      </select>
      
      <select id="view-mode" style="padding:10px 16px;border-radius:8px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;cursor:pointer;">
        <option value="grid">🔲 Grid</option>
        <option value="list">📋 List</option>
      </select>
      
      <button id="clear-filters" class="btn small">Clear Filters</button>
    </div>
    
    <!-- Results Container -->
    <div id="browse-results">
      <p class="small muted">Loading shows...</p>
    </div>
    
    <!-- Pagination -->
    <div id="pagination" style="margin-top:24px;display:flex;justify-content:center;align-items:center;gap:12px;"></div>
    
  </div>
</div>

<style>
.show-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 16px;
}

.show-card {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  overflow: hidden;
  transition: transform 0.2s, box-shadow 0.2s;
  cursor: pointer;
}

.show-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.3);
  border-color: rgba(255,255,255,0.2);
}

.show-poster {
  width: 100%;
  aspect-ratio: 2/3;
  object-fit: cover;
  background: rgba(255,255,255,0.05);
}

.show-info {
  padding: 12px;
}

.show-title {
  font-weight: 600;
  font-size: 0.9rem;
  margin-bottom: 6px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.show-meta {
  font-size: 0.75rem;
  opacity: 0.7;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.show-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.show-row {
  display: flex;
  gap: 16px;
  padding: 16px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  transition: background 0.2s;
  cursor: pointer;
}

.show-row:hover {
  background: rgba(255,255,255,0.06);
}

.show-row-poster {
  width: 80px;
  height: 120px;
  object-fit: cover;
  border-radius: 6px;
  background: rgba(255,255,255,0.05);
}

.show-row-info {
  flex: 1;
}

.show-row-title {
  font-weight: 600;
  font-size: 1.1rem;
  margin-bottom: 8px;
}

.show-row-description {
  font-size: 0.85rem;
  opacity: 0.8;
  margin-bottom: 10px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.show-row-meta {
  font-size: 0.8rem;
  opacity: 0.7;
}

.status-badge {
  padding: 3px 8px;
  border-radius: 4px;
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
}

.status-running { background: rgba(0,255,0,0.2); color: #0f0; }
.status-ended { background: rgba(255,0,0,0.2); color: #f44; }
.status-development { background: rgba(255,165,0,0.2); color: #fa0; }
.status-unknown { background: rgba(160,160,160,0.18); color: rgba(255,255,255,0.8); }

.track-btn {
  padding: 6px 12px;
  font-size: 0.8rem;
  white-space: nowrap;
}

.tracked-badge {
  padding: 6px 12px;
  font-size: 0.8rem;
  background: rgba(0,255,0,0.2);
  color: #0f0;
  border-radius: 6px;
}

.pagination-btn {
  padding: 8px 16px;
  border: 1px solid rgba(255,255,255,0.1);
  background: rgba(255,255,255,0.03);
  color: inherit;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.2s;
}

.pagination-btn:hover:not(:disabled) {
  background: rgba(255,255,255,0.08);
}

.pagination-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.pagination-info {
  font-size: 0.85rem;
  opacity: 0.8;
}
</style>

<script>
(async function() {
  console.log('Browse page loaded');

  const perPage = 24;
  let currentPage = 1;
  let currentShows = [];
  let totalPages = 1;

  const searchInput = document.getElementById('search-input');
  const statusFilter = document.getElementById('status-filter');
  const trackedFilter = document.getElementById('tracked-filter');
  const sortBy = document.getElementById('sort-by');
  const viewMode = document.getElementById('view-mode');
  const resultsContainer = document.getElementById('browse-results');
  const pagination = document.getElementById('pagination');
  const showCount = document.getElementById('show-count');
  const clearFiltersBtn = document.getElementById('clear-filters');

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
  }

  function posterMarkup(show) {
    if (show.poster_url) {
      return `<img src="${escapeHtml(show.poster_url)}" alt="${escapeHtml(show.title)}">`;
    }
    // Pack-colored placeholder (no external asset dependency)
    return `<div class="poster-placeholder"><div class="ph-mark">WNX</div></div>`;
  }

  function statusClass(s) {
    const v = String(s || '').toLowerCase();
    if (v === 'running') return 'status-running';
    if (v === 'ended') return 'status-ended';
    if (v === 'development') return 'status-development';
    return 'status-unknown';
  }

  function renderResults() {
    const isGrid = viewMode.value === 'grid';
    if (!currentShows.length) {
      resultsContainer.innerHTML = '<p class="small muted">No shows found.</p>';
      return;
    }

    if (isGrid) {
      let html = '<div class="show-grid">';
      for (const show of currentShows) {
        const tracked = (Number(show.is_tracked) === 1);
        html += `
          <div class="show-card">
            <div class="poster">
              ${posterMarkup(show)}
            </div>
            <div class="show-card-body">
              <div class="show-title">${escapeHtml(show.title)}</div>
              <div class="show-meta">
                <span class="status-badge ${statusClass(show.status)}">${escapeHtml(show.status || 'unknown')}</span>
                ${show.premiered ? `<span class="small muted">${escapeHtml(show.premiered)}</span>` : ''}
              </div>
              <div class="show-actions">
                ${tracked
                  ? `<span class="tracked-badge">✓ Tracked</span>`
                  : `<button class="btn small track-btn" data-id="${show.id}" data-action="add">Track</button>`
                }
              </div>
            </div>
          </div>`;
      }
      html += '</div>';
      resultsContainer.innerHTML = html;
    } else {
      let html = '<div class="show-list">';
      for (const show of currentShows) {
        const tracked = (Number(show.is_tracked) === 1);
        const desc = show.description ? String(show.description).slice(0, 140) : '';
        html += `
          <div class="show-row">
            <div class="show-row-poster">
              ${posterMarkup(show)}
            </div>
            <div class="show-row-body">
              <div class="show-row-title">${escapeHtml(show.title)}</div>
              <div class="show-row-meta">
                <span class="status-badge ${statusClass(show.status)}">${escapeHtml(show.status || 'unknown')}</span>
                ${show.premiered ? ` • <span>${escapeHtml(show.premiered)}</span>` : ''}
                ${show.show_type ? ` • <span>${escapeHtml(show.show_type)}</span>` : ''}
              </div>
              ${desc ? `<div class="small muted" style="margin-top:6px;line-height:1.3;">${escapeHtml(desc)}${show.description && String(show.description).length > 140 ? '…' : ''}</div>` : ''}
            </div>
            <div class="show-row-actions">
              ${tracked
                ? `<button class="btn small track-btn" data-id="${show.id}" data-action="remove">Untrack</button>`
                : `<button class="btn small track-btn" data-id="${show.id}" data-action="add">Track</button>`
              }
            </div>
          </div>`;
      }
      html += '</div>';
      resultsContainer.innerHTML = html;
    }
  }

  function renderPagination(page, pages) {
    pagination.innerHTML = '';
    if (pages <= 1) return;

    const mkBtn = (label, targetPage, disabled=false) => {
      const b = document.createElement('button');
      b.className = 'btn small';
      b.textContent = label;
      b.disabled = disabled;
      b.addEventListener('click', () => loadPage(targetPage));
      return b;
    };

    pagination.appendChild(mkBtn('← Prev', page - 1, page <= 1));

    // windowed page numbers
    const start = Math.max(1, page - 2);
    const end = Math.min(pages, page + 2);
    for (let p = start; p <= end; p++) {
      const b = mkBtn(String(p), p, false);
      if (p === page) {
        b.style.opacity = '0.9';
        b.style.borderColor = 'rgba(255,255,255,0.35)';
      }
      pagination.appendChild(b);
    }

    pagination.appendChild(mkBtn('Next →', page + 1, page >= pages));
  }

  async function loadPage(page = 1) {
    currentPage = page;

    const params = new URLSearchParams();
    const q = searchInput.value.trim();
    if (q) params.set('q', q);
    if (statusFilter.value) params.set('status', statusFilter.value);
    if (trackedFilter && trackedFilter.value === 'tracked') params.set('tracked', '1');
    params.set('sort', sortBy.value || 'title_asc');
    params.set('page', String(currentPage));
    params.set('per_page', String(perPage));

    resultsContainer.innerHTML = '<p class="small muted">Loading shows...</p>';

    try {
      const resp = await fetch('/api/shows_browse.php?' + params.toString());
      const data = await resp.json();

      if (!data.ok) {
        resultsContainer.innerHTML = '<p class="error">Failed to load shows: ' + escapeHtml(data.error || 'Unknown error') + '</p>';
        return;
      }

      currentShows = data.shows || [];
      totalPages = Number(data.pages || 1);

      showCount.textContent = `${data.total ?? currentShows.length} shows`;

      renderResults();
      renderPagination(Number(data.page || currentPage), totalPages);

    } catch (err) {
      console.error('Browse load error:', err);
      resultsContainer.innerHTML = '<p class="error">Failed to load shows (network error)</p>';
    }
  }

  // Debounce search
  let t = null;
  function scheduleReload() {
    if (t) clearTimeout(t);
    t = setTimeout(() => loadPage(1), 220);
  }

  // Listeners
  searchInput.addEventListener('input', scheduleReload);
  statusFilter.addEventListener('change', () => loadPage(1));
  if (trackedFilter) trackedFilter.addEventListener('change', () => loadPage(1));
  sortBy.addEventListener('change', () => loadPage(1));
  viewMode.addEventListener('change', renderResults);

  clearFiltersBtn.addEventListener('click', function() {
    searchInput.value = '';
    statusFilter.value = '';
    if (trackedFilter) trackedFilter.value = '';
    sortBy.value = 'title_asc';
    loadPage(1);
  });

  // Track/untrack
  resultsContainer.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('.track-btn');
    if (!btn) return;

    const showId = Number(btn.dataset.id || 0);
    const action = btn.dataset.action || 'add';
    if (!showId) return;

    btn.disabled = true;

    try {
      const resp = await fetch('/api/myshows.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ action: action === 'remove' ? 'remove' : 'add', show_id: showId })
      });

      const data = await resp.json();
      if (!data.ok) {
        alert(data.error || 'Failed to update tracking');
        btn.disabled = false;
        return;
      }

      // Update local state
      for (const s of currentShows) {
        if (Number(s.id) === showId) {
          s.is_tracked = (action === 'remove') ? 0 : 1;
          break;
        }
      }
      renderResults();

      // If we're in "tracked only" view and untracked something, refresh page
      if (trackedFilter && trackedFilter.value === 'tracked' && action === 'remove') {
        loadPage(1);
      }

    } catch (err) {
      console.error('Track toggle failed:', err);
      alert('Network error while updating tracking');
      btn.disabled = false;
    }
  });

  // Boot
  loadPage(1);

})();
</script>
