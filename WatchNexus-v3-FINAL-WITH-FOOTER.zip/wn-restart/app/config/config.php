<?php
declare(strict_types=1);

/**
 * WatchNexus configuration loader.
 *
 * IMPORTANT:
 * - Do NOT commit secrets to this file.
 * - Put secrets in app/config/config.local.php (see config.local.example.php),
 *   or provide environment variables (if your host supports them).
 */

$WNX_CONFIG = [
  'debug' => false,

  // DB defaults (override in config.local.php or env vars)
  'db' => [
    'host' => '',
    'name' => '',
    'user' => '',
    'pass' => '',
    'charset' => 'utf8mb4',
  ],

  // Base64-encoded 32-byte key for libsodium secretbox.
  // Override in config.local.php or env var WATCHNEXUS_SECRET_KEY_B64 / WNX_SECRET_KEY_B64.
  'secret_key_b64' => '',
];

// Load local overrides if present (not shipped / not committed)
$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
  /** @noinspection PhpIncludeInspection */
  require $local;
  // Preferred: define $WNX_CONFIG_LOCAL as an array of overrides
  if (isset($WNX_CONFIG_LOCAL) && is_array($WNX_CONFIG_LOCAL)) {
    $WNX_CONFIG = array_replace_recursive($WNX_CONFIG, $WNX_CONFIG_LOCAL);
  }
}

// Environment variables (optional; many shared hosts limit getenv)
$envDebug = getenv('WNX_DEBUG');
if ($envDebug !== false && $envDebug !== '') {
  $WNX_CONFIG['debug'] = filter_var($envDebug, FILTER_VALIDATE_BOOL);
}

// DB env overrides (support both WATCHNEXUS_* and WNX_*)
$WNX_CONFIG['db']['host'] = (string) (getenv('WATCHNEXUS_DB_HOST') ?: getenv('WNX_DB_HOST') ?: $WNX_CONFIG['db']['host']);
$WNX_CONFIG['db']['name'] = (string) (getenv('WATCHNEXUS_DB_NAME') ?: getenv('WNX_DB_NAME') ?: $WNX_CONFIG['db']['name']);
$WNX_CONFIG['db']['user'] = (string) (getenv('WATCHNEXUS_DB_USER') ?: getenv('WNX_DB_USER') ?: $WNX_CONFIG['db']['user']);
$WNX_CONFIG['db']['pass'] = (string) (getenv('WATCHNEXUS_DB_PASS') ?: getenv('WNX_DB_PASS') ?: $WNX_CONFIG['db']['pass']);
$WNX_CONFIG['db']['charset'] = (string) (getenv('WATCHNEXUS_DB_CHARSET') ?: getenv('WNX_DB_CHARSET') ?: $WNX_CONFIG['db']['charset'] ?: 'utf8mb4');

// Secret key env overrides (support both WATCHNEXUS_* and WNX_*)
$WNX_CONFIG['secret_key_b64'] = (string) (getenv('WATCHNEXUS_SECRET_KEY_B64') ?: getenv('WNX_SECRET_KEY_B64') ?: $WNX_CONFIG['secret_key_b64']);

// Export key + debug as constants for convenience
if (!defined('WNX_DEBUG')) {
  define('WNX_DEBUG', (bool)($WNX_CONFIG['debug'] ?? false));
}
if (!defined('WNX_SECRET_KEY_B64')) {
  define('WNX_SECRET_KEY_B64', (string)($WNX_CONFIG['secret_key_b64'] ?? ''));
}

// Minimal config sanity checks (fail fast with a friendly message)
function wnx_config_require(string $key, string $label): void {
  global $WNX_CONFIG;
  $v = $WNX_CONFIG['db'][$key] ?? '';
  if ($v === '') {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "WatchNexus configuration missing: DB {$label}.\n";
    echo "Create app/config/config.local.php (copy from config.local.example.php) and set your DB credentials.\n";
    exit;
  }
}

wnx_config_require('host', 'host');
wnx_config_require('name', 'name');
wnx_config_require('user', 'user');
// password may be empty for some setups; do not require it
