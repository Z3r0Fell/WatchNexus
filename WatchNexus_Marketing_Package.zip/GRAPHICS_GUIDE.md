# WatchNexus Social Media Graphics Guide

**Goal:** Create professional graphics quickly using free tools

---

## 🎨 FREE DESIGN TOOLS

### **Option 1: Canva (Recommended)**
- Website: canva.com
- Free tier: Plenty for your needs
- Templates: 1000s of social media templates
- Easy: Drag and drop

### **Option 2: Figma**
- Website: figma.com
- Free tier: Unlimited files
- More advanced: But steeper learning curve

### **Option 3: Photopea**
- Website: photopea.com
- Free: 100% free, no signup
- Photoshop-like: If you know Photoshop

**We'll use Canva for this guide.**

---

## 📐 IMAGE SIZES YOU NEED

### **Facebook:**
- Feed Post: 1200 x 630px
- Story: 1080 x 1920px
- Cover Photo: 820 x 312px
- Profile Picture: 180 x 180px

### **Twitter/X:**
- Feed Post: 1200 x 675px
- Header: 1500 x 500px

### **Instagram (if you expand):**
- Feed: 1080 x 1080px
- Story: 1080 x 1920px

### **General:**
- Logo: 512 x 512px (transparent PNG)
- Favicon: 32 x 32px

---

## 🎨 BRAND COLORS

**From your themes:**

### **Neon (Primary):**
- Green: `#00ff88`
- Background: `#0a0a0a`
- Text: `#ffffff`

### **Alternatives:**
- Accent: `#00ccff` (blue)
- Warning: `#ffaa00` (orange)
- Error: `#ff6464` (red)

**Use these consistently across all graphics!**

---

## 🚀 CANVA QUICK START

### **1. Create Account**
1. Go to canva.com
2. Sign up free
3. Skip pro trial (free is enough)

### **2. Start a Design**
1. Click "Create a design"
2. Choose "Facebook Post" (1200 x 630)
3. Start editing!

### **3. Design Your First Graphic**

**Template 1: Feature Showcase**

1. Background:
   - Color: `#0a0a0a` (black)
   
2. Add Text:
   - Headline: "Never Miss Another Episode"
   - Font: Bold, large (60-80pt)
   - Color: `#00ff88` (neon green)
   
3. Add Sub-text:
   - "Track 50,000+ TV shows FREE"
   - Font: Regular (24-30pt)
   - Color: `#ffffff` (white)
   
4. Add Screenshot:
   - Upload your calendar screenshot
   - Place on right side
   - Add subtle shadow
   
5. Add Logo:
   - Top left corner
   - Small (80-100px)
   
6. Add CTA:
   - "watchnexus.ca"
   - Bottom center
   - Font: Bold (20pt)
   - Color: `#ffffff`

**Download:** PNG, High quality

---

## 📋 GRAPHIC TEMPLATES TO CREATE

### **1. Hero Banner (Facebook Cover)**
**Size:** 820 x 312px

**Elements:**
- Dark background (`#0a0a0a`)
- Big bold text: "WatchNexus"
- Tagline: "Your Personal TV Tracker"
- Screenshot of calendar in background (faded)
- CTA: "Get Started Free"

---

### **2. Feature Grid**
**Size:** 1200 x 630px

**Layout:**
```
┌─────────────────────────────┐
│  Never Miss Another Episode │
├─────────────────────────────┤
│  📅   📺   🔍   🎨   🆓    │
│ Track Shows Browse  Free    │
│ Calendar  Discover  Themes  │
└─────────────────────────────┘
```

**Elements:**
- 5 icons (emojis work!)
- Short label under each
- Dark background
- Neon green accent color

---

### **3. Quote Card**
**Size:** 1080 x 1080px (square works everywhere)

**Layout:**
```
┌─────────────────────┐
│    "Finally! A TV   │
│  tracker that works"│
│                     │
│    ⭐⭐⭐⭐⭐        │
│                     │
│  - WatchNexus User  │
└─────────────────────┘
```

**Elements:**
- Large quote text (centered)
- 5 stars
- Attribution at bottom
- Gradient background (dark → less dark)

---

### **4. Comparison Post**
**Size:** 1200 x 630px

**Layout:**
```
┌──────────────┬──────────────┐
│ Other Apps   │ WatchNexus   │
├──────────────┼──────────────┤
│ ❌ $5-10/mo  │ ✅ FREE      │
│ ❌ Ads       │ ✅ No Ads    │
│ ❌ Limited   │ ✅ Unlimited │
└──────────────┴──────────────┘
```

**Elements:**
- Split screen (two columns)
- Red X vs Green check
- Bold comparison text
- Clear winner visual

---

### **5. Stat Card**
**Size:** 1080 x 1080px

**Layout:**
```
┌─────────────────────┐
│                     │
│       50,000+       │
│      TV SHOWS       │
│                     │
│     Track them all  │
│        FREE         │
│                     │
└─────────────────────┘
```

**Elements:**
- Huge number (main focus)
- Label under number
- Supporting text below
- Minimal design
- High contrast

---

### **6. Screenshot Showcase**
**Size:** 1200 x 630px

**Layout:**
```
┌─────────────────────────┐
│  Check out the Calendar │
│                         │
│  [Screenshot of app]    │
│                         │
│  watchnexus.ca          │
└─────────────────────────┘
```

**Elements:**
- Headline at top
- Large screenshot (center)
- Website URL at bottom
- Device mockup (optional)

---

## 📸 SCREENSHOT TIPS

### **How to Take Good Screenshots:**

1. **Clean up UI:**
   - Use a fresh account (no clutter)
   - Add 5-10 shows (looks active)
   - Use the best theme (probably Neon)

2. **What to capture:**
   - Calendar view (most impressive)
   - My Shows grid (shows organization)
   - Browse page (shows database size)
   - Theme selector (shows customization)

3. **Use browser tools:**
   - Zoom to 100%
   - Full screen (F11)
   - Hide bookmarks bar
   - Screenshot: Windows Key + Shift + S (Windows) or Cmd + Shift + 4 (Mac)

4. **Edit screenshots:**
   - Crop to interesting part
   - Add subtle shadow (looks professional)
   - Compress (use tinypng.com)

---

## 🎥 VIDEO CONTENT

### **Screen Recording Tools:**

**Free Options:**
- **OBS Studio** (obsproject.com) - Professional, free
- **ShareX** (Windows) - Easy, free
- **QuickTime** (Mac) - Built-in

### **What to Record:**

1. **30-Second Tour:**
   - Login → Browse → Track show → Calendar → Done

2. **Feature Showcase:**
   - Show each feature (10 sec each)
   - Add text overlays
   - Background music (use YouTube Audio Library)

3. **How-To Videos:**
   - "How to track a show"
   - "How to use the calendar"
   - "How to change themes"

### **Video Specs:**
- Format: MP4
- Resolution: 1920 x 1080 (1080p)
- Frame rate: 30fps
- Length: 15-60 seconds (short!)

---

## 🖼️ STOCK IMAGES (If Needed)

**Free Stock Photo Sites:**
- unsplash.com (best quality)
- pexels.com (great variety)
- pixabay.com (good selection)

**Search Terms:**
- "TV remote"
- "watching TV"
- "movie night"
- "streaming"
- "binge watching"

**Use sparingly!** Screenshots of your app are better.

---

## 🎨 CANVA TEMPLATES YOU CAN COPY

### **Quick Template:**

1. Go to Canva
2. Search: "Tech product announcement"
3. Pick any dark theme
4. Replace:
   - Their logo → WatchNexus
   - Their colors → `#00ff88` and `#0a0a0a`
   - Their text → Your copy
   - Their screenshot → Your screenshot

**Done in 5 minutes!**

---

## 📋 GRAPHIC CREATION CHECKLIST

**For Each Graphic:**
- [ ] Correct size (1200x630 for Facebook)
- [ ] Brand colors used (`#00ff88`, `#0a0a0a`)
- [ ] Logo visible (but not too large)
- [ ] Text readable (good contrast)
- [ ] No spelling errors
- [ ] High quality export (PNG)
- [ ] File size <500KB (compress if needed)
- [ ] Watermark removed (Canva free may add small watermark - it's okay)

---

## 💡 DESIGN TIPS

### **Do:**
- ✅ Keep it simple
- ✅ Use high contrast
- ✅ Make text large
- ✅ Show screenshots
- ✅ Use consistent colors
- ✅ Add your website URL
- ✅ Leave white space

### **Don't:**
- ❌ Use 10 different fonts
- ❌ Cram too much text
- ❌ Use low-res images
- ❌ Forget your branding
- ❌ Make it too busy
- ❌ Use ugly stock photos
- ❌ Forget CTA (call to action)

---

## 🚀 QUICK START

**Create These 5 Graphics Today (30 min total):**

1. **Facebook Cover** (5 min)
   - Template: "Tech company cover"
   - Text: "WatchNexus - Track TV Shows Free"

2. **Feature Post** (5 min)
   - Template: "App features"
   - List 5 features with icons

3. **Screenshot Post** (5 min)
   - Upload your calendar screenshot
   - Add headline + URL

4. **Quote Card** (5 min)
   - Template: "Testimonial"
   - Add fake 5-star review

5. **Stat Card** (5 min)
   - Big number: "50,000+"
   - Text: "TV Shows Available FREE"

**Upload to Facebook. You're marketing!**

---

## 📊 ANALYTICS

**Track Which Graphics Work:**
- Engagement (likes, comments, shares)
- Clicks (to your website)
- Reach (people who saw it)

**Double down on what works!**

If screenshot posts get more engagement → Make more screenshot posts.

---

## 🎯 SUMMARY

**Tools:**
- Canva.com (free)
- Your screenshots
- Brand colors: `#00ff88` + `#0a0a0a`

**Sizes:**
- Facebook: 1200 x 630px
- Square: 1080 x 1080px

**Create:**
- 5-10 graphics
- Save as templates
- Reuse with different text

**Post:**
- Facebook, Twitter, Reddit
- 3x per week
- Track what works

---

**Start with Canva, use templates, keep it simple!** 🎨

You don't need to be a designer - just consistent with your brand!
