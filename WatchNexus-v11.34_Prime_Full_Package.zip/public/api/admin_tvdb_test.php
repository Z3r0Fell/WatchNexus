<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'POST required']);
  exit;
}

if (!has_role('admin')) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'Admin only']);
  exit;
}

try {
  $token = tvdb_login_and_store();

  // lightweight verification call (series endpoint requires ID; skip)
  echo json_encode([
    'ok' => true,
    'message' => 'TVDB auth OK',
    'token_prefix' => substr($token, 0, 8) . '…',
    'token_expires_utc' => tvdb_get_token_expires_utc(),
  ], JSON_PRETTY_PRINT);
} catch (Throwable $e) {
  $debug = (getenv('WNX_DEBUG') === '1');
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => $debug ? $e->getMessage() : 'TVDB auth failed']);
}
