<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

$u = current_user();
if (!$u) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Login required']);
  exit;
}

// Mod tools live behind the 'mod' role (admins also qualify).
if (!has_role('mod') && !has_role('admin')) {
  http_response_code(403);
  echo json_encode(['ok'=>false,'error'=>'Mod only']);
  exit;
}

/**
 * Strict allowlist for link templates.
 * This is intentionally conservative: WatchNexus will not ship a link manager that facilitates piracy.
 * You can expand this list by editing this file.
 */
const WNX_ALLOWED_DOMAINS = [
  'wikipedia.org',
  'imdb.com',
  'tvmaze.com',
  'thetvdb.com',
  'rottentomatoes.com',
  'youtube.com',
  'youtu.be',
  'google.com',
  'justwatch.com',
  'metacritic.com',
  'letterboxd.com',
  'netflix.com',
  'disneyplus.com',
  'primevideo.com',
  'crave.ca',
  'cbc.ca',
  'tubitv.com',
  'plutotv.com',
  'plex.tv',
];

function table_exists(PDO $pdo, string $table): bool {
  try {
    $st = $pdo->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1');
    $st->execute([$table]);
    return (bool)$st->fetchColumn();
  } catch (Throwable $e) {
    try {
      $pdo->query('SELECT 1 FROM ' . $table . ' LIMIT 1');
      return true;
    } catch (Throwable $_) {
      return false;
    }
  }
}

function ensure_tables(PDO $pdo): void {
  $hasCats = table_exists($pdo, 'resource_link_categories');
  $hasLinks = table_exists($pdo, 'resource_links');
  if (!$hasCats || !$hasLinks) {
    http_response_code(409);
    echo json_encode([
      'ok' => false,
      'error' => 'Resource links tables not found. Run the migration SQL (RESOURCE_LINKS_MIGRATION.sql).',
      'needs_migration' => true,
    ], JSON_UNESCAPED_SLASHES);
    exit;
  }
}

function json_body(): array {
  $raw = file_get_contents('php://input');
  if (!$raw) return [];
  $d = json_decode($raw, true);
  return is_array($d) ? $d : [];
}

function is_domain_allowed(string $host): bool {
  $host = strtolower(trim($host));
  if ($host === '') return false;
  foreach (WNX_ALLOWED_DOMAINS as $d) {
    $d = strtolower($d);
    if ($host === $d) return true;
    if (str_ends_with($host, '.' . $d)) return true;
  }
  return false;
}

function validate_template(string $template): ?string {
  $tpl = trim($template);
  if ($tpl === '') return 'Template URL is required.';
  // Block magnet: links and obvious torrent keywords.
  if (stripos($tpl, 'magnet:') !== false) return 'magnet: links are not allowed.';
  if (preg_match('/\b(torrent|piratebay|1337x|rarbg|yts|eztv)\b/i', $tpl)) {
    return 'This link template looks like a piracy/torrent source, which is not allowed.';
  }

  // Allow internal/relative links (e.g. "/?page=downloads&q={QUERY}")
  if (str_starts_with($tpl, '/')) {
    if (str_starts_with($tpl, '//')) return 'Protocol-relative URLs are not allowed.';
    return null;
  }
  if (str_starts_with($tpl, '?')) {
    return null;
  }

  // Replace placeholders with harmless text so parse_url works.
  $probe = preg_replace('/\{[A-Z0-9_]+\}/', 'test', $tpl) ?? $tpl;
  $u = parse_url($probe);
  if (!is_array($u)) return 'Invalid URL.';
  $scheme = strtolower((string)($u['scheme'] ?? ''));
  if (!in_array($scheme, ['http','https'], true)) return 'Only http/https URLs are allowed.';
  $host = (string)($u['host'] ?? '');
  if ($host === '') return 'URL host is required.';
  if (!is_domain_allowed($host)) {
    return 'Domain not allowed by this instance. Allowed: ' . implode(', ', WNX_ALLOWED_DOMAINS);
  }
  return null;
}

function seed_defaults(PDO $pdo): void {
  // If categories already exist, do nothing.
  $existing = (int)$pdo->query('SELECT COUNT(*) FROM resource_link_categories')->fetchColumn();
  if ($existing > 0) return;

  $pdo->beginTransaction();
  try {
    $insCat = $pdo->prepare('INSERT INTO resource_link_categories (name, icon, enabled, sort_order) VALUES (?,?,?,?)');
    $insLink = $pdo->prepare('INSERT INTO resource_links (category_id, label, icon, template, enabled, is_public, sort_order) VALUES (?,?,?,?,?,?,?)');

    $cats = [
      ['Info','ℹ️',1,10],
      ['Reviews','⭐',1,20],
      ['Media','▶️',1,30],
      ['Where to Watch','🍿',1,40],
      ['Search','🔎',1,50],
    ];
    $catIds = [];
    foreach ($cats as $c) {
      $insCat->execute([$c[0], $c[1], $c[2], $c[3]]);
      $catIds[$c[0]] = (int)$pdo->lastInsertId();
    }

    $links = [
      ['Info','Wikipedia','🌐','https://en.wikipedia.org/wiki/{WIKI_TITLE}',1,1,10],
      ['Info','IMDb (search)','🎬','https://www.imdb.com/find?q={QUERY}&s=tt&ttype=tv',1,1,20],
      ['Info','TVMaze (search)','📺','https://www.tvmaze.com/search?q={QUERY}',1,1,30],
      ['Info','TheTVDB (search)','🗂️','https://thetvdb.com/search?query={QUERY}',1,1,40],
      ['Reviews','Rotten Tomatoes','🍅','https://www.rottentomatoes.com/search?search={QUERY}',1,1,10],
      ['Media','YouTube (trailers)','▶️','https://www.youtube.com/results?search_query={QUERY}%20trailer',1,1,10],
      ['Where to Watch','JustWatch (CA)','🍿','https://www.justwatch.com/ca/search?q={QUERY}',1,1,10],
      ['Search','Google','🔎','https://www.google.com/search?q={QUERY}',1,1,10],
    ];
    foreach ($links as $l) {
      $cid = $catIds[$l[0]] ?? null;
      if (!$cid) continue;
      $insLink->execute([$cid, $l[1], $l[2], $l[3], $l[4], $l[5], $l[6]]);
    }

    $pdo->commit();
  } catch (Throwable $e) {
    $pdo->rollBack();
    throw $e;
  }
}

try {
  $pdo = db();
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'DB unavailable']);
  exit;
}

$action = (string)($_GET['action'] ?? 'list');

if ($action === 'health') {
  $has = table_exists($pdo, 'resource_link_categories') && table_exists($pdo, 'resource_links');
  echo json_encode(['ok'=>true,'has_tables'=>$has], JSON_UNESCAPED_SLASHES);
  exit;
}

ensure_tables($pdo);

try {
  if ($action === 'seed_defaults') {
    seed_defaults($pdo);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_SLASHES);
    exit;
  }

  if ($action === 'list') {
    $cats = $pdo->query('SELECT id, name, icon, enabled, sort_order FROM resource_link_categories ORDER BY sort_order ASC, name ASC')->fetchAll(PDO::FETCH_ASSOC);
    $links = $pdo->query('SELECT id, category_id, label, icon, template, enabled, is_public, sort_order FROM resource_links ORDER BY category_id ASC, sort_order ASC, label ASC')->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['ok'=>true,'categories'=>$cats,'links'=>$links], JSON_UNESCAPED_SLASHES);
    exit;
  }

  $body = json_body();

  if ($action === 'save_category') {
    $id = (int)($body['id'] ?? 0);
    $name = trim((string)($body['name'] ?? ''));
    $icon = trim((string)($body['icon'] ?? ''));
    $enabled = (int)($body['enabled'] ?? 1) ? 1 : 0;
    $sort = (int)($body['sort_order'] ?? 0);
    if ($name === '') {
      http_response_code(422);
      echo json_encode(['ok'=>false,'error'=>'Category name is required']);
      exit;
    }
    if ($id > 0) {
      $st = $pdo->prepare('UPDATE resource_link_categories SET name=?, icon=?, enabled=?, sort_order=? WHERE id=?');
      $st->execute([$name, $icon, $enabled, $sort, $id]);
      echo json_encode(['ok'=>true,'id'=>$id], JSON_UNESCAPED_SLASHES);
      exit;
    }
    $st = $pdo->prepare('INSERT INTO resource_link_categories (name, icon, enabled, sort_order) VALUES (?,?,?,?)');
    $st->execute([$name, $icon, $enabled, $sort]);
    echo json_encode(['ok'=>true,'id'=>(int)$pdo->lastInsertId()], JSON_UNESCAPED_SLASHES);
    exit;
  }

  if ($action === 'delete_category') {
    $id = (int)($body['id'] ?? 0);
    if ($id <= 0) {
      http_response_code(422);
      echo json_encode(['ok'=>false,'error'=>'Category id required']);
      exit;
    }
    $st = $pdo->prepare('DELETE FROM resource_link_categories WHERE id=?');
    $st->execute([$id]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_SLASHES);
    exit;
  }

  if ($action === 'save_link') {
    $id = (int)($body['id'] ?? 0);
    $categoryId = (int)($body['category_id'] ?? 0);
    $label = trim((string)($body['label'] ?? ''));
    $icon = trim((string)($body['icon'] ?? ''));
    $template = trim((string)($body['template'] ?? ''));
    $enabled = (int)($body['enabled'] ?? 1) ? 1 : 0;
    $isPublic = (int)($body['is_public'] ?? 1) ? 1 : 0;
    $sort = (int)($body['sort_order'] ?? 0);

    if ($categoryId <= 0) {
      http_response_code(422);
      echo json_encode(['ok'=>false,'error'=>'Category is required']);
      exit;
    }
    if ($label === '') {
      http_response_code(422);
      echo json_encode(['ok'=>false,'error'=>'Label is required']);
      exit;
    }
    $err = validate_template($template);
    if ($err) {
      http_response_code(422);
      echo json_encode(['ok'=>false,'error'=>$err]);
      exit;
    }

    if ($id > 0) {
      $st = $pdo->prepare('UPDATE resource_links SET category_id=?, label=?, icon=?, template=?, enabled=?, is_public=?, sort_order=? WHERE id=?');
      $st->execute([$categoryId, $label, $icon, $template, $enabled, $isPublic, $sort, $id]);
      echo json_encode(['ok'=>true,'id'=>$id], JSON_UNESCAPED_SLASHES);
      exit;
    }
    $st = $pdo->prepare('INSERT INTO resource_links (category_id, label, icon, template, enabled, is_public, sort_order) VALUES (?,?,?,?,?,?,?)');
    $st->execute([$categoryId, $label, $icon, $template, $enabled, $isPublic, $sort]);
    echo json_encode(['ok'=>true,'id'=>(int)$pdo->lastInsertId()], JSON_UNESCAPED_SLASHES);
    exit;
  }

  if ($action === 'delete_link') {
    $id = (int)($body['id'] ?? 0);
    if ($id <= 0) {
      http_response_code(422);
      echo json_encode(['ok'=>false,'error'=>'Link id required']);
      exit;
    }
    $st = $pdo->prepare('DELETE FROM resource_links WHERE id=?');
    $st->execute([$id]);
    echo json_encode(['ok'=>true], JSON_UNESCAPED_SLASHES);
    exit;
  }

  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'Unknown action'], JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'Server error: ' . $e->getMessage()], JSON_UNESCAPED_SLASHES);
}
