<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';

ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

$u = current_user();
if (!$u) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Login required']);
  exit;
}

$uid = (int)($u['id'] ?? 0);
if ($uid <= 0) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'Invalid session user']);
  exit;
}

$pdo = db();

try {
  // Ensure user_settings row exists (schema uses theme_id/theme_mode/fx_scanlines)
  $pdo->prepare("INSERT IGNORE INTO user_settings (user_id) VALUES (?)")->execute([$uid]);

  $st = $pdo->prepare("SELECT theme_id, theme_mode, fx_scanlines FROM user_settings WHERE user_id = ? LIMIT 1");
  $st->execute([$uid]);
  $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];

  // User module toggles (overrides)
  $userMods = [];
  try {
    $st = $pdo->prepare("SELECT module_id, enabled FROM user_module_overrides WHERE user_id = ?");
    $st->execute([$uid]);
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
      $mid = (string)($r['module_id'] ?? '');
      if ($mid === '') continue;
      $userMods[$mid] = ((int)($r['enabled'] ?? 0) === 1);
    }
  } catch (Throwable $e) {
    // table may not exist yet; ignore
  }

  // Global forced policy (what the UI expects: on/off/none)
  $forced = [];
  try {
    $q = $pdo->query("SELECT module_id, force_enabled, disabled_globally FROM module_policy");
    while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
      $mid = (string)($r['module_id'] ?? '');
      if ($mid === '') continue;

      $isOff = ((int)($r['disabled_globally'] ?? 0) === 1);
      $isOn  = ((int)($r['force_enabled'] ?? 0) === 1);

      $forced[$mid] = $isOff ? 'off' : ($isOn ? 'on' : 'none');
    }
  } catch (Throwable $e) {
    // module_policy may not exist yet; ignore
  }

  echo json_encode([
    'ok' => true,
    'user_id' => $uid,
    'settings' => [
      'theme_id' => (string)($row['theme_id'] ?? 'midnight_signal'),
      'theme_mode' => (string)($row['theme_mode'] ?? 'system'),
      'fx_scanlines' => ((int)($row['fx_scanlines'] ?? 0) === 1),
      'modules' => $userMods,
    ],
    'modules' => [
      'forced' => $forced
    ]
  ], JSON_PRETTY_PRINT);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode([
    'ok'=>false,
    'where'=>'settings_get.php',
    'error'=>'Internal server error',
  ], JSON_PRETTY_PRINT);
}
