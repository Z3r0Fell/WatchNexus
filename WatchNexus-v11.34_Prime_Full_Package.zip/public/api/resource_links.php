<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

// Resource Links Engine
// - Public-safe discovery/metadata links.
// - DB-backed when tables exist; falls back to safe defaults.

/**
 * @return array<int, array<string,mixed>>
 */
function safe_default_links(): array {
  return [
    ['category'=>'Info','label'=>'Wikipedia','icon'=>'🌐','template'=>'https://en.wikipedia.org/wiki/{WIKI_TITLE}','enabled'=>1,'sort_order'=>10,'is_public'=>1],
    ['category'=>'Info','label'=>'IMDb (search)','icon'=>'🎬','template'=>'https://www.imdb.com/find?q={QUERY}&s=tt&ttype=tv','enabled'=>1,'sort_order'=>20,'is_public'=>1],
    ['category'=>'Info','label'=>'TVMaze (search)','icon'=>'📺','template'=>'https://www.tvmaze.com/search?q={QUERY}','enabled'=>1,'sort_order'=>30,'is_public'=>1],
    ['category'=>'Info','label'=>'TheTVDB (search)','icon'=>'🗂️','template'=>'https://thetvdb.com/search?query={QUERY}','enabled'=>1,'sort_order'=>40,'is_public'=>1],
    ['category'=>'Reviews','label'=>'Rotten Tomatoes','icon'=>'🍅','template'=>'https://www.rottentomatoes.com/search?search={QUERY}','enabled'=>1,'sort_order'=>10,'is_public'=>1],
    ['category'=>'Media','label'=>'YouTube (trailers)','icon'=>'▶️','template'=>'https://www.youtube.com/results?search_query={QUERY}%20trailer','enabled'=>1,'sort_order'=>10,'is_public'=>1],
    ['category'=>'Search','label'=>'Google','icon'=>'🔎','template'=>'https://www.google.com/search?q={QUERY}','enabled'=>1,'sort_order'=>10,'is_public'=>1],
    ['category'=>'Where to Watch','label'=>'JustWatch (CA)','icon'=>'🍿','template'=>'https://www.justwatch.com/ca/search?q={QUERY}','enabled'=>1,'sort_order'=>10,'is_public'=>1],
  ];
}

function norm_title(string $t): string {
  $t = trim(preg_replace('/\s+/u', ' ', $t) ?? $t);
  return $t;
}

/** @param array<string,string> $ids */
function apply_template(string $tpl, string $title, array $ids): string {
  $query = rawurlencode($title);
  $wiki = rawurlencode(str_replace(' ', '_', $title));

  $map = [
    '{QUERY}' => $query,
    '{WIKI_TITLE}' => $wiki,
    '{TVMAZE_ID}' => rawurlencode($ids['TVMAZE_ID'] ?? ''),
    '{THETVDB_ID}' => rawurlencode($ids['THETVDB_ID'] ?? ''),
    '{IMDB_ID}' => rawurlencode($ids['IMDB_ID'] ?? ''),
    '{TRAKT_ID}' => rawurlencode($ids['TRAKT_ID'] ?? ''),
    '{TMDB_ID}' => rawurlencode($ids['TMDB_ID'] ?? ''),
  ];

  return strtr($tpl, $map);
}

/**
 * @return array<string,string>
 */
function fetch_ids(PDO $pdo, int $showId): array {
  $out = [];
  $st = $pdo->prepare('SELECT provider, external_id FROM show_external_ids WHERE show_id = ?');
  $st->execute([$showId]);
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $prov = (string)($r['provider'] ?? '');
    $eid = (string)($r['external_id'] ?? '');
    if ($prov === 'tvmaze') $out['TVMAZE_ID'] = $eid;
    if ($prov === 'thetvdb') $out['THETVDB_ID'] = $eid;
    if ($prov === 'imdb') $out['IMDB_ID'] = $eid;
    if ($prov === 'trakt') $out['TRAKT_ID'] = $eid;
    if ($prov === 'tmdb') $out['TMDB_ID'] = $eid;
  }
  return $out;
}

function table_exists(PDO $pdo, string $table): bool {
  try {
    $st = $pdo->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1');
    $st->execute([$table]);
    return (bool)$st->fetchColumn();
  } catch (Throwable $e) {
    // Some shared hosts restrict information_schema; fallback to probing.
    try {
      $pdo->query('SELECT 1 FROM ' . $table . ' LIMIT 1');
      return true;
    } catch (Throwable $_) {
      return false;
    }
  }
}

try {
  $pdo = db();
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'DB unavailable'], JSON_UNESCAPED_SLASHES);
  exit;
}

$u = current_user();
$publicView = !$u;

$showId = (int)($_GET['show_id'] ?? 0);
$title = '';
$ids = [];

if ($showId > 0) {
  $st = $pdo->prepare('SELECT title FROM shows WHERE id = ?');
  $st->execute([$showId]);
  $title = (string)($st->fetchColumn() ?: '');
  if ($title !== '') {
    $ids = fetch_ids($pdo, $showId);
  }
}

if ($title === '') {
  $title = (string)($_GET['title'] ?? $_GET['q'] ?? '');
}

$title = norm_title($title);
if ($title === '') $title = 'Unknown';

$hasCats = table_exists($pdo, 'resource_link_categories');
$hasLinks = table_exists($pdo, 'resource_links');

// If DB tables exist and have data, use them; else fall back.
if ($hasCats && $hasLinks) {
  try {
    $cats = [];
    $st = $pdo->query("SELECT id, name, icon, sort_order FROM resource_link_categories WHERE enabled = 1 ORDER BY sort_order ASC, name ASC");
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
      $cid = (int)$r['id'];
      $cats[$cid] = [
        'id' => $cid,
        'name' => (string)$r['name'],
        'icon' => (string)($r['icon'] ?? ''),
        'sort_order' => (int)($r['sort_order'] ?? 0),
        'links' => [],
      ];
    }

    $sql = "SELECT id, category_id, label, icon, template, sort_order, is_public
            FROM resource_links
            WHERE enabled = 1" . ($publicView ? " AND is_public = 1" : "") . "
            ORDER BY category_id ASC, sort_order ASC, label ASC";
    $st2 = $pdo->query($sql);
    $count = 0;
    while ($r = $st2->fetch(PDO::FETCH_ASSOC)) {
      $cid = (int)$r['category_id'];
      if (!isset($cats[$cid])) continue;
      $href = apply_template((string)$r['template'], $title, $ids);
      $cats[$cid]['links'][] = [
        'id' => (int)$r['id'],
        'label' => (string)$r['label'],
        'icon' => (string)($r['icon'] ?? ''),
        'href' => $href,
        'sort_order' => (int)($r['sort_order'] ?? 0),
      ];
      $count++;
    }

    // If tables exist but empty, fall back to defaults.
    if ($count > 0) {
      $outCats = array_values($cats);
      // Drop empty categories
      $outCats = array_values(array_filter($outCats, fn($c) => !empty($c['links'])));
      echo json_encode([
        'ok' => true,
        'title' => $title,
        'show_id' => $showId,
        'categories' => $outCats,
      ], JSON_UNESCAPED_SLASHES);
      exit;
    }
  } catch (Throwable $e) {
    // Fall back below.
  }
}

// Fallback safe defaults (no DB required)
$defaults = safe_default_links();
// filter public
if ($publicView) {
  $defaults = array_values(array_filter($defaults, fn($x) => (int)($x['is_public'] ?? 1) === 1));
}
// group
$group = [];
foreach ($defaults as $l) {
  $cat = (string)($l['category'] ?? 'Links');
  $group[$cat] ??= [];
  $group[$cat][] = [
    'id' => (string)($l['label'] ?? ''),
    'label' => (string)$l['label'],
    'icon' => (string)($l['icon'] ?? ''),
    'href' => apply_template((string)$l['template'], $title, $ids),
    'sort_order' => (int)($l['sort_order'] ?? 0),
  ];
}
// sort within group
foreach ($group as $cat => &$items) {
  usort($items, fn($a,$b) => ((int)$a['sort_order'] <=> (int)$b['sort_order']) ?: strcmp($a['label'],$b['label']));
}
unset($items);

$catsOut = [];
foreach ($group as $cat => $items) {
  $catsOut[] = ['name'=>$cat,'icon'=>'','links'=>$items];
}

echo json_encode([
  'ok' => true,
  'title' => $title,
  'show_id' => $showId,
  'categories' => $catsOut,
  'note' => ($hasCats && $hasLinks) ? 'DB tables empty; using safe defaults' : 'DB tables missing; using safe defaults',
], JSON_UNESCAPED_SLASHES);
