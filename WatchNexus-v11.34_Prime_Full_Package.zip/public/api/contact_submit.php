<?php
declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';

ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  http_response_code(405);
  echo json_encode(['ok' => false, 'error' => 'POST required']);
  exit;
}

$raw = file_get_contents('php://input') ?: '';
$data = json_decode($raw, true);
if (!is_array($data)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
  exit;
}

$name = trim((string)($data['name'] ?? ''));
$email = trim((string)($data['email'] ?? ''));
$topic = trim((string)($data['topic'] ?? ''));
$msg = trim((string)($data['message'] ?? ''));

$allowedTopics = ['Feedback', 'Website Issue', 'Suggestion', 'Praise'];

// Basic validation
if ($name === '' || $email === '' || $topic === '' || $msg === '') {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Missing required fields']);
  exit;
}

if (strlen($name) > 80 || strlen($email) > 120 || strlen($msg) > 4000) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Input too long']);
  exit;
}

if (!in_array($topic, $allowedTopics, true)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid topic']);
  exit;
}

if (str_contains($email, "\r") || str_contains($email, "\n")) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid email']);
  exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Invalid email']);
  exit;
}

// Simple rate limit (per IP, per ~20s)
$ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
$ipKey = 'wnx_contact_last_' . md5($ip ?: 'unknown');
$now = time();
$last = (int)($_SESSION[$ipKey] ?? 0);
if ($last > 0 && ($now - $last) < 20) {
  http_response_code(429);
  echo json_encode(['ok' => false, 'error' => 'Slow down a bit (rate limit).']);
  exit;
}
$_SESSION[$ipKey] = $now;

// Load mail config from config.local.php overrides if provided
global $WNX_CONFIG;
$mail = (isset($WNX_CONFIG['mail']) && is_array($WNX_CONFIG['mail'])) ? $WNX_CONFIG['mail'] : [];

$host = (string)($mail['smtp_host'] ?? getenv('WATCHNEXUS_SMTP_HOST') ?: getenv('WNX_SMTP_HOST') ?: 'smtp.ionos.com');
$port = (int)($mail['smtp_port'] ?? (getenv('WATCHNEXUS_SMTP_PORT') ?: getenv('WNX_SMTP_PORT') ?: 465));
$secure = strtolower((string)($mail['smtp_secure'] ?? getenv('WATCHNEXUS_SMTP_SECURE') ?: getenv('WNX_SMTP_SECURE') ?: 'ssl')); // 'ssl' or 'tls'
$user = (string)($mail['smtp_user'] ?? getenv('WATCHNEXUS_SMTP_USER') ?: getenv('WNX_SMTP_USER') ?: '');
$pass = (string)($mail['smtp_pass'] ?? getenv('WATCHNEXUS_SMTP_PASS') ?: getenv('WNX_SMTP_PASS') ?: '');

$fromEmail = (string)($mail['from_email'] ?? $user);
$fromName = (string)($mail['from_name'] ?? 'WatchNexus Webform');
$toEmail = (string)($mail['to_email'] ?? 'wmadmin@watchnexus.ca');
$toName = (string)($mail['to_name'] ?? 'WatchNexus Admin');
$verifyPeer = (bool)($mail['verify_peer'] ?? true);

if ($user === '' || $pass === '' || $fromEmail === '') {
  http_response_code(500);
  echo json_encode([
    'ok' => false,
    'error' => 'SMTP not configured. Add $WNX_CONFIG_LOCAL["mail"]["smtp_user"] and ["smtp_pass"] in app/config/config.local.php.'
  ]);
  exit;
}

// Build email
$subject = "[WatchNexus] {$topic} — {$name}";
$ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
$ts = gmdate('Y-m-d H:i:s') . ' UTC';

$body = "New WatchNexus contact form submission\n\n" .
  "Topic: {$topic}\n" .
  "Name: {$name}\n" .
  "Email: {$email}\n" .
  "Time: {$ts}\n" .
  "IP: {$ip}\n" .
  "User-Agent: {$ua}\n" .
  "\nMessage:\n" .
  $msg .
  "\n";

try {
  smtp_send_mail([
    'host' => $host,
    'port' => $port,
    'secure' => $secure,
    'user' => $user,
    'pass' => $pass,
    'verify_peer' => $verifyPeer,
  ], [
    'from_email' => $fromEmail,
    'from_name' => $fromName,
    'to_email' => $toEmail,
    'to_name' => $toName,
    'reply_to' => $email,
    'subject' => $subject,
    'body' => $body,
  ]);

  echo json_encode(['ok' => true]);
  exit;

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'Send failed: ' . $e->getMessage()]);
  exit;
}

/**
 * Minimal SMTP sender (AUTH LOGIN) supporting SSL (465) or STARTTLS (587).
 *
 * @param array{host:string,port:int,secure:string,user:string,pass:string,verify_peer:bool} $smtp
 * @param array{from_email:string,from_name:string,to_email:string,to_name:string,reply_to:string,subject:string,body:string} $msg
 */
function smtp_send_mail(array $smtp, array $msg): void {
  $host = $smtp['host'];
  $port = (int)$smtp['port'];
  $secure = strtolower($smtp['secure'] ?? 'ssl');

  $ctx = stream_context_create([
    'ssl' => [
      'verify_peer' => $smtp['verify_peer'],
      'verify_peer_name' => $smtp['verify_peer'],
      'allow_self_signed' => !$smtp['verify_peer'],
    ],
  ]);

  $target = ($secure === 'ssl') ? "ssl://{$host}:{$port}" : "{$host}:{$port}";
  $fp = @stream_socket_client($target, $errno, $errstr, 12, STREAM_CLIENT_CONNECT, $ctx);
  if (!$fp) {
    throw new RuntimeException("SMTP connect failed: {$errstr} ({$errno})");
  }
  stream_set_timeout($fp, 12);

  $greet = smtp_read($fp);
  if (substr($greet, 0, 3) !== '220') {
    throw new RuntimeException('SMTP greeting failed: ' . trim($greet));
  }

  $hostname = gethostname() ?: 'watchnexus.local';
  smtp_cmd($fp, "EHLO {$hostname}", 250);

  if ($secure === 'tls') {
    smtp_cmd($fp, 'STARTTLS', 220);
    $cryptoOk = stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
    if ($cryptoOk !== true) {
      throw new RuntimeException('STARTTLS failed.');
    }
    // EHLO again after TLS
    smtp_cmd($fp, "EHLO {$hostname}", 250);
  }

  smtp_cmd($fp, 'AUTH LOGIN', 334);
  smtp_cmd($fp, base64_encode($smtp['user']), 334);
  smtp_cmd($fp, base64_encode($smtp['pass']), 235);

  $from = $msg['from_email'];
  $to = $msg['to_email'];

  smtp_cmd($fp, "MAIL FROM:<{$from}>", 250);
  smtp_cmd($fp, "RCPT TO:<{$to}>", 250);
  smtp_cmd($fp, 'DATA', 354);

  $headers = [];
  $headers[] = 'From: ' . smtp_format_addr($msg['from_name'], $from);
  $headers[] = 'To: ' . smtp_format_addr($msg['to_name'], $to);
  $headers[] = 'Reply-To: ' . smtp_format_addr($msg['reply_to'], $msg['reply_to']);
  $headers[] = 'Subject: ' . smtp_encode_subject($msg['subject']);
  $headers[] = 'MIME-Version: 1.0';
  $headers[] = 'Content-Type: text/plain; charset=UTF-8';
  $headers[] = 'Content-Transfer-Encoding: 8bit';

  $payload = implode("\r\n", $headers) . "\r\n\r\n";
  $payload .= str_replace("\n", "\r\n", $msg['body']) . "\r\n";

  // Escape lines beginning with a dot per RFC
  $payload = preg_replace('/\r\n\./', "\r\n..", $payload);

  fwrite($fp, $payload);
  fwrite($fp, "\r\n.\r\n");

  $resp = smtp_read($fp);
  if (substr($resp, 0, 3) !== '250') {
    throw new RuntimeException('SMTP DATA not accepted: ' . trim($resp));
  }

  smtp_cmd($fp, 'QUIT', 221);
  fclose($fp);
}

function smtp_cmd($fp, string $cmd, int $expectCode): void {
  fwrite($fp, $cmd . "\r\n");
  $resp = smtp_read($fp);
  $code = (int)substr($resp, 0, 3);
  if ($code !== $expectCode) {
    throw new RuntimeException("SMTP error for '{$cmd}': " . trim($resp));
  }
}

function smtp_read($fp): string {
  $data = '';
  while (!feof($fp)) {
    $line = fgets($fp, 515);
    if ($line === false) break;
    $data .= $line;
    // Multi-line replies have a dash after the status code (e.g., 250-)
    if (strlen($line) >= 4 && $line[3] !== '-') {
      break;
    }
  }
  return $data;
}

function smtp_format_addr(string $name, string $email): string {
  $email = trim($email);
  $name = trim($name);
  if ($name === '' || $name === $email) return $email;
  // Basic safe quoting
  $name = str_replace(['"', "\r", "\n"], ['', '', ''], $name);
  return '"' . $name . '" <' . $email . '>';
}

function smtp_encode_subject(string $subject): string {
  $subject = trim(str_replace(["\r", "\n"], [' ', ' '], $subject));
  // Encode as RFC2047 if needed
  if (preg_match('/[\x80-\xFF]/', $subject)) {
    return '=?UTF-8?B?' . base64_encode($subject) . '?=';
  }
  return $subject;
}
