<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';

$page = $_GET['page'] ?? 'calendar';
$title = 'WatchNexus • ' . ucfirst((string)$page);

$partial = (isset($_GET['partial']) && $_GET['partial'] === '1');

if ($page === 'logout') {
  // Keep classic logout as a fallback (SPA uses /api/auth.php).
  logout_user();
  if ($partial) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<div class="banner"><div class="badge">Logged out</div><div><p>See you next episode.</p></div></div>';
    exit;
  }
  header('Location: ?page=calendar');
  exit;
}

$viewMap = [
  'calendar' => __DIR__ . '/../app/views/calendar.php',
  'browse' => __DIR__ . '/../app/views/browse.php',
  'myshows' => __DIR__ . '/../app/views/myshows.php',
  'contact' => __DIR__ . '/../app/views/contact.php',
  'settings' => __DIR__ . '/../app/views/settings.php',
  'login' => __DIR__ . '/../app/views/login.php',
  'register' => __DIR__ . '/../app/views/register.php',
  'mod' => __DIR__ . '/../app/views/mod.php',
  'admin' => __DIR__ . '/../app/views/admin.php',
  'privacy' => __DIR__ . '/../app/views/privacy.php',
  'terms' => __DIR__ . '/../app/views/terms.php',
  'acknowledgements' => __DIR__ . '/../app/views/acknowledgements.php',
];

// Module gating (hard enforcement)
$pageToModule = [
  'calendar' => 'calendar',
  'browse' => 'browse',
  'myshows' => 'myshows',
  'settings' => 'settings',
  'mod' => 'mod',
  'admin' => 'admin',
];

if (isset($pageToModule[$page])) {
  $mid = $pageToModule[$page];
  if (!wnx_module_enabled($mid)) {
    http_response_code(current_user() ? 403 : 401);
    $isAuthed = (bool)current_user();
    $reason = $isAuthed
      ? 'This feature is currently disabled for your account or by system policy.'
      : 'Please sign in to access this feature.';

    $extra = '';
    if ($isAuthed && function_exists('is_admin') && is_admin()) {
      $extra = '<p class="small muted" style="margin-top:6px;">Admin tip: check <strong>Admin → Module Policy</strong> (or module_policy/global_module_policy in the DB) for <code>' . htmlspecialchars($mid, ENT_QUOTES, 'UTF-8') . '</code>.</p>';
    }

    $content = '<div class="banner"><div class="badge">Blocked</div><div><p>' . $reason . '</p>' . $extra . '</div></div>';
    if ($partial) {
      header('Content-Type: text/html; charset=utf-8');
      echo $content;
      exit;
    }
    require __DIR__ . '/../app/views/layout.php';
    exit;
  }
}

ob_start();
if (isset($viewMap[$page])) {
  require $viewMap[$page];
} else {
  http_response_code(404);
  echo '<div class="card"><div class="hd"><h2>404</h2></div><div class="bd"><p>Page not found.</p></div></div>';
}
$content = ob_get_clean();

if ($partial) {
  header('Content-Type: text/html; charset=utf-8');
  header('X-WNX-Title: ' . $title);
  echo $content;
  exit;
}

require __DIR__ . '/../app/views/layout.php';
