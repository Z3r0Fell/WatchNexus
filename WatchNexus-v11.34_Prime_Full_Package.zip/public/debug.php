<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>PHP Debug Test</h1>";
echo "PHP Version: " . PHP_VERSION . "<br>";
echo "Current directory: " . __DIR__ . "<br>";

// Test bootstrap
echo "<br><strong>Testing bootstrap...</strong><br>";
try {
    require_once __DIR__ . '/../app/bootstrap.php';
    echo "✓ Bootstrap loaded<br>";
} catch (Throwable $e) {
    echo "✗ Bootstrap failed: " . $e->getMessage() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    exit;
}

// Test database
echo "<br><strong>Testing database...</strong><br>";
try {
    $pdo = db();
    echo "✓ Database connected<br>";
} catch (Throwable $e) {
    echo "✗ Database failed: " . $e->getMessage() . "<br>";
    exit;
}

echo "<br><h2>✓ All basic tests passed!</h2>";
?>
