/* WatchNexus - contact.js
 * Public contact form submitter.
 *
 * - Works on full reload
 * - Works with hot-swap navigation via the `wnx:page` event
 */

(() => {
  const TOPICS = ['Feedback', 'Website Issue', 'Suggestion', 'Praise'];

  function byId(id) { return document.getElementById(id); }

  function getPage() {
    const app = byId('appContent');
    return app ? (app.getAttribute('data-page') || '') : '';
  }

  function renderStatus(el, type, html) {
    if (!el) return;
    if (!html) { el.innerHTML = ''; return; }
    const klass = type === 'success' ? 'success' : (type === 'warn' ? 'warn' : '');
    el.innerHTML = `<div class="banner ${klass}"><div class="badge">${type === 'success' ? '✓' : '!'}</div><div>${html}</div></div>`;
  }

  async function submit(form) {
    const status = byId('contactStatus');

    const name = (byId('contact_name')?.value || '').trim();
    const email = (byId('contact_email')?.value || '').trim();
    const topic = (byId('contact_topic')?.value || '').trim();
    const msg = (byId('contact_message')?.value || '').trim();

    // Honeypot: if filled, pretend success (quietly)
    const hp = (byId('contact_company')?.value || '').trim();
    if (hp) {
      renderStatus(status, 'success', '<p class="small" style="margin:0;">Message sent. Thanks!</p>');
      form.reset();
      return;
    }

    if (!name || !email || !topic || !msg) {
      renderStatus(status, 'warn', '<p class="small" style="margin:0;">Please fill in all fields.</p>');
      return;
    }

    if (!TOPICS.includes(topic)) {
      renderStatus(status, 'warn', '<p class="small" style="margin:0;">Invalid topic selection.</p>');
      return;
    }

    const btn = byId('contactSubmit');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Sending…';
    }

    renderStatus(status, 'warn', '<p class="small muted" style="margin:0;">Sending…</p>');

    try {
      const res = await fetch('/api/contact_submit.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-WNX-AJAX': '1'
        },
        body: JSON.stringify({ name, email, topic, message: msg })
      });

      let data = null;
      try { data = await res.json(); } catch { data = null; }

      if (!res.ok || !data || data.ok !== true) {
        const err = (data && data.error) ? data.error : ('Request failed (' + res.status + ')');
        renderStatus(status, 'warn', `<p class="small" style="margin:0;"><strong>Couldn’t send:</strong> ${escapeHtml(err)}</p>`);
      } else {
        renderStatus(status, 'success', '<p class="small" style="margin:0;"><strong>Sent.</strong> Thanks — we read everything.</p>');
        form.reset();
      }
    } catch (e) {
      renderStatus(status, 'warn', '<p class="small" style="margin:0;"><strong>Couldn’t send:</strong> Network error.</p>');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Send message';
      }
    }
  }

  function escapeHtml(str) {
    return String(str)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function init() {
    if (getPage() !== 'contact') return;

    const form = byId('contactForm');
    if (!form || form.dataset.wired === '1') return;
    form.dataset.wired = '1';

    form.addEventListener('submit', (ev) => {
      ev.preventDefault();
      submit(form);
    });
  }

  // Full load
  document.addEventListener('DOMContentLoaded', init);
  // Hot-swap navigation
  window.addEventListener('wnx:page', init);
})();
