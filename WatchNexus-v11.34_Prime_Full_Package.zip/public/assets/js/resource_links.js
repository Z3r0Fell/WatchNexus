/*
  WatchNexus - Global Resource Links Engine (Start Menu)
  - Adds a "Links ▾" dropdown to any element with .wnx-links-btn
  - Populates from /api/resource_links.php (DB-backed; safe fallback)
  - Public-safe defaults; mods can manage links in Mod Tools.
*/

(function(){
  'use strict';

  // Derive app base path from where this script is served.
  // Example: https://site.com/subdir/assets/js/resource_links.js -> base=/subdir
  const APP_BASE = (() => {
    try {
      const s = document.currentScript;
      if (s && s.src) {
        const u = new URL(s.src, window.location.href);
        const p = u.pathname || '';
        const idx = p.indexOf('/assets/');
        if (idx >= 0) return p.slice(0, idx);
      }
    } catch (_) {}
    return '';
  })();

  const API_CANDIDATE_PREFIXES = (() => {
    const set = new Set();
    // Most common deployment shapes
    set.add(APP_BASE + '/api');
    set.add('/api');
    set.add('api');
    set.add('./api');
    // Deduplicate + drop empties
    return Array.from(set).filter(Boolean);
  })();

  const STATE = {
    cssInjected: false,
    cache: new Map(),   // key -> payload
    inFlight: new Map() // key -> Promise
  };

  function fallbackCategories(title){
    const q = encodeURIComponent(String(title || ''));
    const wiki = encodeURIComponent(String(title || '').trim().replace(/\s+/g,'_'));
    return [
      {
        name: 'Info',
        icon: '🧭',
        links: [
          { label: 'Wikipedia', icon: '🌐', href: `https://en.wikipedia.org/wiki/${wiki}` },
          { label: 'IMDb (search)', icon: '🎬', href: `https://www.imdb.com/find?q=${q}&s=tt&ttype=tv` },
          { label: 'TVMaze (search)', icon: '📺', href: `https://www.tvmaze.com/search?q=${q}` },
          { label: 'TheTVDB (search)', icon: '🗂️', href: `https://thetvdb.com/search?query=${q}` },
        ]
      },
      {
        name: 'Reviews',
        icon: '⭐',
        links: [
          { label: 'Rotten Tomatoes', icon: '🍅', href: `https://www.rottentomatoes.com/search?search=${q}` },
        ]
      },
      {
        name: 'Media',
        icon: '▶️',
        links: [
          { label: 'YouTube (trailers)', icon: '▶️', href: `https://www.youtube.com/results?search_query=${q}%20trailer` },
        ]
      },
      {
        name: 'Search',
        icon: '🔎',
        links: [
          { label: 'Google', icon: '🔎', href: `https://www.google.com/search?q=${q}` },
        ]
      },
      {
        name: 'Where to Watch',
        icon: '🍿',
        links: [
          { label: 'JustWatch (CA)', icon: '🍿', href: `https://www.justwatch.com/ca/search?q=${q}` },
        ]
      },
    ];
  }

  function injectCSS() {
    if (STATE.cssInjected) return;
    STATE.cssInjected = true;

    const css = `
.wnx-links-wrap{display:inline-block;position:relative;}
.wnx-links-menu{
  position:absolute;
  right:0;
  top:100%;
  margin-top:6px;
  width:min(520px, 92vw);
  max-height:420px;
  background:rgba(20,20,24,0.98);
  border:1px solid var(--wnx-menu-border, rgba(255,255,255,0.14));
  border-radius:12px;
  box-shadow:0 10px 28px rgba(0,0,0,0.45);
  z-index:999999;
  overflow:hidden;
  color:rgba(245,245,250,0.96) !important;
}
.wnx-links-menu a,.wnx-links-menu button{color:inherit !important;}
.wnx-sm{display:flex; width:100%; height:100%;}
.wnx-sm-left{
  width:190px;
  border-right:1px solid rgba(255,255,255,0.10);
  background:rgba(0,0,0,0.10);
  overflow:auto;
}
.wnx-sm-right{flex:1;overflow:auto;}
.wnx-sm-title{
  padding:10px 12px;
  font-size:0.85rem;
  font-weight:700;
  border-bottom:1px solid rgba(255,255,255,0.10);
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}
.wnx-sm-cat{
  width:100%;
  text-align:left;
  display:flex;
  gap:10px;
  align-items:center;
  padding:10px 12px;
  background:transparent;
  border:0;
  cursor:pointer;
  border-bottom:1px solid rgba(255,255,255,0.06);
}
.wnx-sm-cat:hover{background:rgba(255,255,255,0.08);}
.wnx-sm-cat.active{background:rgba(0,150,255,0.18);}
.wnx-sm-cat .ico{width:18px;text-align:center;opacity:0.95;}
.wnx-sm-cat .lbl{font-size:0.92rem;}

.wnx-sm-items{padding:6px 0;}
.wnx-sm-item{
  display:flex;
  gap:10px;
  align-items:center;
  padding:10px 12px;
  text-decoration:none;
  border-bottom:1px solid rgba(255,255,255,0.06);
}
.wnx-sm-item:last-child{border-bottom:none;}
.wnx-sm-item:hover{background:rgba(255,255,255,0.08);}
.wnx-sm-item .ico{width:18px;text-align:center;opacity:0.95;}
.wnx-sm-item .lbl{font-size:0.92rem;}
.wnx-sm-empty{padding:12px; opacity:0.80;}

@media (max-width: 520px){
  .wnx-links-menu{width:92vw;}
  .wnx-sm-left{width:150px;}
}
    `;

    const style = document.createElement('style');
    style.setAttribute('data-wnx', 'resource-links-startmenu');
    style.textContent = css;
    document.head.appendChild(style);
  }

  function esc(s){
    return String(s ?? '').replace(/[&<>"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  }

  function getShowId(btn){
    const v = Number(btn.dataset.showId || 0);
    return Number.isFinite(v) ? v : 0;
  }

  function getTitle(btn){
    const direct = (btn.dataset.title || '').trim();
    if (direct) return direct;

    const card = btn.closest('.show-card,.show-row,.myshow-card,.event');
    if (card) {
      const sel = ['.show-title','.show-row-title','.myshow-title','.title'];
      for (const s of sel) {
        const t = card.querySelector(s)?.textContent?.trim();
        if (t) return t;
      }
    }

    return 'Unknown';
  }

  function keyFor(showId, title){
    return showId > 0 ? `id:${showId}` : `t:${title.toLowerCase()}`;
  }

  async function fetchPayload(showId, title){
    const key = keyFor(showId, title);
    if (STATE.cache.has(key)) return STATE.cache.get(key);
    if (STATE.inFlight.has(key)) return STATE.inFlight.get(key);

    const qs = showId > 0
      ? `show_id=${encodeURIComponent(String(showId))}`
      : `title=${encodeURIComponent(title)}`;

    const urls = [];
    for (const pre of API_CANDIDATE_PREFIXES) {
      urls.push(`${pre}/resource_links.php?${qs}`);
    }

    async function tryOne(url){
      const r = await fetch(url, { credentials: 'same-origin' });
      const text = await r.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (_) {
        throw new Error(`Non-JSON response from ${url} (HTTP ${r.status})`);
      }
      if (!r.ok || !data?.ok || !Array.isArray(data.categories)) {
        throw new Error(data?.error || `Bad response from ${url} (HTTP ${r.status})`);
      }
      return { categories: data.categories };
    }

    const p = (async () => {
      try {
        for (const url of urls) {
          try {
            const payload = await tryOne(url);
            STATE.cache.set(key, payload);
            return payload;
          } catch (e) {
            // keep trying next candidate
          }
        }

        // All candidates failed: fall back client-side so menus still populate.
        const payload = { categories: fallbackCategories(title) };
        STATE.cache.set(key, payload);
        console.warn('Resource links API unreachable; using client fallback list.');
        return payload;
      } finally {
        STATE.inFlight.delete(key);
      }
    })();

    STATE.inFlight.set(key, p);
    return p;
  }

  
const PORTAL = { menu: null, anchor: null };

function getPortalMenu(){
  if (PORTAL.menu) return PORTAL.menu;
  const m = document.createElement('div');
  m.className = 'wnx-links-menu';
  m.hidden = true;
  m.setAttribute('data-wnx-portal', '1');
  document.body.appendChild(m);
  PORTAL.menu = m;
  return m;
}

function closeAllMenus(){
  if (PORTAL.menu) PORTAL.menu.hidden = true;
  PORTAL.anchor = null;
}

function positionPortal(btn, menu){
  const r = btn.getBoundingClientRect();
  const margin = 8;

  // Make visible (but hidden) so we can measure accurately
  menu.style.visibility = 'hidden';
  menu.hidden = false;

  const w = menu.offsetWidth || 520;
  const h = menu.offsetHeight || 240;

  let left = r.right - w;
  if (left < margin) left = margin;
  if (left + w > window.innerWidth - margin) left = Math.max(margin, window.innerWidth - margin - w);

  let top = r.bottom + 6;
  // Flip above if it would run off the bottom
  if (top + h > window.innerHeight - margin) {
    top = Math.max(margin, r.top - 6 - h);
  }

  menu.style.position = 'fixed';
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.right = 'auto';
  menu.style.zIndex = '999999';
  menu.style.visibility = 'visible';
}

function buildItemsHtml(cat){
    const links = Array.isArray(cat?.links) ? cat.links : [];
    if (!links.length) {
      return `<div class="wnx-sm-empty">No links in this category.</div>`;
    }

    return links.map(l => {
      const href = esc(l.href || '#');
      const ico = esc(l.icon || '🔗');
      const lbl = esc(l.label || 'Link');
      return `<a class="wnx-sm-item" href="${href}" target="_blank" rel="noopener noreferrer">`+
             `<span class="ico">${ico}</span>`+
             `<span class="lbl">${lbl}</span>`+
             `</a>`;
    }).join('');
  }

  function renderStartMenu(menu, payload, title){
    const cats = Array.isArray(payload?.categories) ? payload.categories : [];

    if (!cats.length) {
      menu.innerHTML = `<div class="wnx-sm"><div class="wnx-sm-right" style="width:100%">`+
                       `<div class="wnx-sm-title">${esc(title)}</div>`+
                       `<div class="wnx-sm-empty">No links configured.</div>`+
                       `</div></div>`;
      menu.dataset.built = '1';
      menu.dataset.title = title;
      menu._wnxCats = [];
      return;
    }

    const left = cats.map((c, idx) => {
      const ico = esc(c.icon || '🧭');
      const name = esc(c.name || 'Links');
      const active = idx === 0 ? 'active' : '';
      return `<button type="button" class="wnx-sm-cat ${active}" data-idx="${idx}">`+
             `<span class="ico">${ico}</span>`+
             `<span class="lbl">${name}</span>`+
             `</button>`;
    }).join('');

    const firstItems = buildItemsHtml(cats[0]);

    menu.innerHTML = `
      <div class="wnx-sm">
        <div class="wnx-sm-left">${left}</div>
        <div class="wnx-sm-right">
          <div class="wnx-sm-title">${esc(title)}</div>
          <div class="wnx-sm-items">${firstItems}</div>
        </div>
      </div>
    `;

    menu.dataset.built = '1';
    menu.dataset.title = title;
    menu._wnxCats = cats;
  }

  function setActiveCategory(menu, idx){
    const cats = menu._wnxCats || [];
    const itemsWrap = menu.querySelector('.wnx-sm-items');
    if (!itemsWrap) return;
    const cat = cats[idx];
    if (!cat) return;

    menu.querySelectorAll('.wnx-sm-cat').forEach(b => b.classList.remove('active'));
    const btn = menu.querySelector(`.wnx-sm-cat[data-idx="${idx}"]`);
    if (btn) btn.classList.add('active');

    itemsWrap.innerHTML = buildItemsHtml(cat);
  }

  
async function toggle(btn){
  injectCSS();

  const menu = getPortalMenu();

  // If clicking same button while menu open, close it
  const isOpen = !menu.hidden;
  if (isOpen && PORTAL.anchor === btn) {
    closeAllMenus();
    return;
  }

  closeAllMenus();

  const showId = getShowId(btn);
  const title = getTitle(btn);

  if (menu.dataset.built !== '1' || menu.dataset.title !== title || (showId > 0 && Number(menu.dataset.showId||0) !== showId)) {
    menu.dataset.showId = String(showId || 0);
    const payload = await fetchPayload(showId, title);
    renderStartMenu(menu, payload, title);
  }

  // Position after render, so width/height is correct and not clipped by parents
  positionPortal(btn, menu);
  menu.hidden = false;
  PORTAL.anchor = btn;
}

document.addEventListener('click', (e) => {
    const btn = e.target.closest('.wnx-links-btn');
    if (btn) {
      e.preventDefault();
      e.stopPropagation();
      toggle(btn);
      return;
    }

    // Category selection
    const catBtn = e.target.closest('.wnx-sm-cat');
    if (catBtn) {
      e.preventDefault();
      e.stopPropagation();
      const menu = catBtn.closest('.wnx-links-menu');
      if (!menu) return;
      const idx = Number(catBtn.dataset.idx || 0);
      setActiveCategory(menu, idx);
      return;
    }

    // Clicking inside menu shouldn't bubble into card click handlers
    if (e.target.closest('.wnx-links-menu')) {
      e.stopPropagation();
      return;
    }

    // Click outside closes
    if (!e.target.closest('.wnx-links-menu') && !e.target.closest('.wnx-links-btn')) {
      closeAllMenus();
    }
  }, true);

// Close on scroll/resize/escape to avoid weird stacking contexts in modals
window.addEventListener('scroll', () => closeAllMenus(), true);
window.addEventListener('resize', () => closeAllMenus(), true);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeAllMenus();
}, true);


})();