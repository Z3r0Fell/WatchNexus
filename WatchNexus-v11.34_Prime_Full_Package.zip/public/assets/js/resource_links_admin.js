/*
  WatchNexus - Resource Links Admin (Start Menu manager)
  - Lives inside Mod Tools.
  - CRUD for categories + links.
  - Server validates domains (allowlist) to avoid piracy linkouts.
*/

(function(){
  'use strict';

  const root = document.getElementById('wnx-rlx-admin');
  if (!root) return;

  const statusEl = root.querySelector('#rlx-status');
  const catsTbody = root.querySelector('#rlx-cats tbody');
  const linksTbody = root.querySelector('#rlx-links tbody');
  const reloadBtn = root.querySelector('#rlx-reload');
  const seedBtn = root.querySelector('#rlx-seed');
  const addCatBtn = root.querySelector('#rlx-add-cat');
  const addLinkBtn = root.querySelector('#rlx-add-link');

  const state = { categories: [], links: [], hasTables: null };

  function esc(s){
    return String(s ?? '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[c]));
  }

  function setStatus(msg, isErr=false){
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.style.opacity = '1';
    statusEl.style.color = isErr ? 'var(--danger, #ff6464)' : 'inherit';
  }

  async function apiGet(action){
    const r = await fetch(`/api/resource_links_admin.php?action=${encodeURIComponent(action)}`, { credentials:'same-origin' });
    const t = await r.text();
    let d = null;
    try { d = JSON.parse(t); } catch (_) { throw new Error('Bad JSON: ' + t.slice(0, 200)); }
    if (!r.ok || !d?.ok) {
      const err = d?.error || (`HTTP ${r.status}`);
      const e = new Error(err);
      e._payload = d;
      throw e;
    }
    return d;
  }

  async function apiPost(action, body){
    const r = await fetch(`/api/resource_links_admin.php?action=${encodeURIComponent(action)}`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      credentials:'same-origin',
      body: JSON.stringify(body || {})
    });
    const t = await r.text();
    let d = null;
    try { d = JSON.parse(t); } catch (_) { throw new Error('Bad JSON: ' + t.slice(0, 200)); }
    if (!r.ok || !d?.ok) {
      const err = d?.error || (`HTTP ${r.status}`);
      const e = new Error(err);
      e._payload = d;
      throw e;
    }
    return d;
  }

  function catOptions(selectedId){
    return state.categories.map(c => {
      const id = Number(c.id);
      const sel = id === Number(selectedId) ? 'selected' : '';
      const disabled = Number(c.enabled) ? '' : 'disabled';
      return `<option value="${id}" ${sel} ${disabled}>${esc(c.name)}</option>`;
    }).join('');
  }

  function renderCategories(){
    if (!catsTbody) return;
    catsTbody.innerHTML = '';
    for (const c of state.categories) {
      const tr = document.createElement('tr');
      tr.dataset.id = String(c.id ?? 0);
      tr.innerHTML = `
        <td><input type="checkbox" class="rlx-cat-enabled" ${Number(c.enabled) ? 'checked' : ''}></td>
        <td><input type="number" class="input rlx-cat-sort" value="${esc(c.sort_order ?? 0)}" style="width:80px"></td>
        <td><input type="text" class="input rlx-cat-icon" value="${esc(c.icon ?? '')}" placeholder="🧩" style="width:80px"></td>
        <td><input type="text" class="input rlx-cat-name" value="${esc(c.name ?? '')}" placeholder="Category name"></td>
        <td style="white-space:nowrap;">
          <button class="btn small rlx-save-cat" type="button">Save</button>
          <button class="btn small rlx-del-cat" type="button">Delete</button>
        </td>
      `;
      catsTbody.appendChild(tr);
    }
  }

  function renderLinks(){
    if (!linksTbody) return;
    linksTbody.innerHTML = '';
    for (const l of state.links) {
      const tr = document.createElement('tr');
      tr.dataset.id = String(l.id ?? 0);
      tr.innerHTML = `
        <td><input type="checkbox" class="rlx-link-enabled" ${Number(l.enabled) ? 'checked' : ''}></td>
        <td><input type="checkbox" class="rlx-link-public" ${Number(l.is_public) ? 'checked' : ''}></td>
        <td><input type="number" class="input rlx-link-sort" value="${esc(l.sort_order ?? 0)}" style="width:80px"></td>
        <td>
          <select class="input rlx-link-cat">
            ${catOptions(l.category_id)}
          </select>
        </td>
        <td><input type="text" class="input rlx-link-icon" value="${esc(l.icon ?? '')}" placeholder="🔗" style="width:80px"></td>
        <td><input type="text" class="input rlx-link-label" value="${esc(l.label ?? '')}" placeholder="Label"></td>
        <td><input type="text" class="input rlx-link-template" value="${esc(l.template ?? '')}" placeholder="https://...{QUERY}"></td>
        <td style="white-space:nowrap;">
          <button class="btn small rlx-save-link" type="button">Save</button>
          <button class="btn small rlx-del-link" type="button">Delete</button>
        </td>
      `;
      linksTbody.appendChild(tr);
    }
  }

  function render(){
    renderCategories();
    renderLinks();
  }

  function addCategoryRow(){
    state.categories.push({ id: 0, name: '', icon: '', enabled: 1, sort_order: 0 });
    renderCategories();
  }

  function addLinkRow(){
    const firstCat = state.categories[0]?.id || 0;
    state.links.push({ id: 0, category_id: firstCat, label: '', icon: '', template: '', enabled: 1, is_public: 1, sort_order: 0 });
    renderLinks();
  }

  async function load(){
    setStatus('Loading…');
    try {
      const health = await apiGet('health');
      state.hasTables = !!health.has_tables;
      if (!state.hasTables) {
        setStatus('DB tables missing. Run RESOURCE_LINKS_MIGRATION.sql in phpMyAdmin, then reload.', true);
        return;
      }

      const d = await apiGet('list');
      state.categories = d.categories || [];
      state.links = d.links || [];
      render();
      setStatus(`Loaded ${state.categories.length} categories / ${state.links.length} links.`);
    } catch (e) {
      console.error(e);
      setStatus(e.message || 'Load failed', true);
    }
  }

  async function seed(){
    setStatus('Seeding defaults…');
    try {
      await apiPost('seed_defaults', {});
      await load();
      setStatus('Defaults seeded.');
    } catch (e) {
      console.error(e);
      setStatus(e.message || 'Seed failed', true);
    }
  }

  catsTbody?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const tr = btn.closest('tr');
    if (!tr) return;

    const id = Number(tr.dataset.id || 0);
    if (btn.classList.contains('rlx-save-cat')) {
      const payload = {
        id,
        enabled: tr.querySelector('.rlx-cat-enabled')?.checked ? 1 : 0,
        sort_order: Number(tr.querySelector('.rlx-cat-sort')?.value || 0),
        icon: tr.querySelector('.rlx-cat-icon')?.value || '',
        name: tr.querySelector('.rlx-cat-name')?.value || ''
      };
      setStatus('Saving category…');
      try {
        const d = await apiPost('save_category', payload);
        if (id === 0) tr.dataset.id = String(d.id);
        await load();
        setStatus('Category saved.');
      } catch (err) {
        console.error(err);
        setStatus(err.message || 'Save failed', true);
      }
    }

    if (btn.classList.contains('rlx-del-cat')) {
      if (!confirm('Delete this category? (All links in it will be deleted)')) return;
      setStatus('Deleting category…');
      try {
        await apiPost('delete_category', { id });
        await load();
        setStatus('Category deleted.');
      } catch (err) {
        console.error(err);
        setStatus(err.message || 'Delete failed', true);
      }
    }
  });

  linksTbody?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const tr = btn.closest('tr');
    if (!tr) return;
    const id = Number(tr.dataset.id || 0);

    if (btn.classList.contains('rlx-save-link')) {
      const payload = {
        id,
        enabled: tr.querySelector('.rlx-link-enabled')?.checked ? 1 : 0,
        is_public: tr.querySelector('.rlx-link-public')?.checked ? 1 : 0,
        sort_order: Number(tr.querySelector('.rlx-link-sort')?.value || 0),
        category_id: Number(tr.querySelector('.rlx-link-cat')?.value || 0),
        icon: tr.querySelector('.rlx-link-icon')?.value || '',
        label: tr.querySelector('.rlx-link-label')?.value || '',
        template: tr.querySelector('.rlx-link-template')?.value || ''
      };
      setStatus('Saving link…');
      try {
        const d = await apiPost('save_link', payload);
        if (id === 0) tr.dataset.id = String(d.id);
        await load();
        setStatus('Link saved.');
      } catch (err) {
        console.error(err);
        setStatus(err.message || 'Save failed', true);
      }
    }

    if (btn.classList.contains('rlx-del-link')) {
      if (!confirm('Delete this link?')) return;
      setStatus('Deleting link…');
      try {
        await apiPost('delete_link', { id });
        await load();
        setStatus('Link deleted.');
      } catch (err) {
        console.error(err);
        setStatus(err.message || 'Delete failed', true);
      }
    }
  });

  reloadBtn?.addEventListener('click', load);
  seedBtn?.addEventListener('click', seed);
  addCatBtn?.addEventListener('click', addCategoryRow);
  addLinkBtn?.addEventListener('click', addLinkRow);

  load();
})();
