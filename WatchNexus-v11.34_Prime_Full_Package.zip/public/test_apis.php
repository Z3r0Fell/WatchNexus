<?php
declare(strict_types=1);

// Require bootstrap FIRST - before any output
require_once __DIR__ . '/../app/bootstrap.php';

// Now we can output HTML
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WatchNexus - API Test</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #0a0a0a; 
      color: #fff; 
      padding: 20px;
      line-height: 1.6;
    }
    .container { max-width: 1000px; margin: 0 auto; }
    h1 { margin-bottom: 10px; color: #00ff88; }
    .subtitle { color: #888; margin-bottom: 30px; }
    button { 
      padding: 12px 24px; 
      background: #00ff88; 
      color: #0a0a0a; 
      border: none; 
      border-radius: 6px; 
      font-weight: 600;
      cursor: pointer;
      margin-right: 10px;
      margin-bottom: 10px;
    }
    button:hover { background: #00dd77; }
    #results { margin-top: 20px; }
    .test-item {
      background: #1a1a1a;
      border: 1px solid #333;
      border-radius: 8px;
      padding: 16px;
      margin-bottom: 12px;
    }
    .test-item.pass { border-left: 4px solid #0f0; background: rgba(0,255,0,0.05); }
    .test-item.fail { border-left: 4px solid #f00; background: rgba(255,0,0,0.05); }
    .test-item.running { border-left: 4px solid #fa0; background: rgba(255,165,0,0.05); }
    .test-name { font-weight: 600; margin-bottom: 8px; }
    .test-url { font-size: 0.85rem; color: #888; margin-bottom: 8px; font-family: monospace; }
    .test-status { font-size: 0.9rem; margin-bottom: 8px; }
    .test-response { 
      background: #000; 
      padding: 12px; 
      border-radius: 4px; 
      font-family: monospace; 
      font-size: 0.85rem;
      max-height: 300px;
      overflow-y: auto;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
    .pass .test-name::before { content: "✓ "; color: #0f0; }
    .fail .test-name::before { content: "✗ "; color: #f00; }
    .running .test-name::before { content: "⟳ "; color: #fa0; }
  </style>
</head>
<body>
  <div class="container">
    <h1>WatchNexus API Test</h1>
    <p class="subtitle">Test all API endpoints to verify functionality</p>
    
    <div>
      <button onclick="testAll()">Test All APIs</button>
      <button onclick="location.reload()">Refresh Page</button>
    </div>
    
    <div id="results"></div>
  </div>

  <script>
  const tests = [
    { name: 'Health Check', url: '/health.php' },
    { name: 'Database Ping', url: '/dbping.php' },
    { name: 'System Health', url: '/api/system_health.php' },
    { name: 'Events API', url: '/api/events.php?start=2026-01-01&end=2026-01-31' },
    { name: 'Shows Browse', url: '/api/shows_browse.php' },
    { name: 'User State', url: '/api/state.php' },
  ];

  async function testAPI(test) {
    const resultDiv = document.createElement('div');
    resultDiv.className = 'test-item running';
    resultDiv.innerHTML = `
      <div class="test-name">${test.name}</div>
      <div class="test-url">${test.url}</div>
      <div class="test-status">Testing...</div>
    `;
    document.getElementById('results').appendChild(resultDiv);

    try {
      const startTime = Date.now();
      const resp = await fetch(test.url);
      const elapsed = Date.now() - startTime;
      
      let body = await resp.text();
      let json = null;
      
      try {
        json = JSON.parse(body);
      } catch (e) {
        // Not JSON, that's okay
      }

      const isSuccess = resp.ok && (json ? json.ok !== false : true);
      
      resultDiv.className = `test-item ${isSuccess ? 'pass' : 'fail'}`;
      resultDiv.innerHTML = `
        <div class="test-name">${test.name}</div>
        <div class="test-url">${test.url}</div>
        <div class="test-status">
          HTTP ${resp.status} • ${elapsed}ms
          ${json && json.ok === false ? '• Error: ' + (json.error || 'Unknown') : ''}
        </div>
        <details>
          <summary style="cursor: pointer; color: #888; font-size: 0.9rem;">View Response</summary>
          <div class="test-response">${json ? JSON.stringify(json, null, 2) : body.substring(0, 500)}</div>
        </details>
      `;
    } catch (err) {
      resultDiv.className = 'test-item fail';
      resultDiv.innerHTML = `
        <div class="test-name">${test.name}</div>
        <div class="test-url">${test.url}</div>
        <div class="test-status">Error: ${err.message}</div>
      `;
    }
  }

  async function testAll() {
    document.getElementById('results').innerHTML = '<p style="color: #888;">Running tests...</p>';
    
    for (const test of tests) {
      await testAPI(test);
      await new Promise(r => setTimeout(r, 100)); // Small delay between tests
    }
  }

  // Auto-run on load
  setTimeout(testAll, 500);
  </script>
</body>
</html>
