# WatchNexus Prime Release — Release Notes

This package bundles the stable base + all post-11.31 hotfixes into a single fresh-install "Prime" drop.

## Major highlights
- Calendar render fix + Links engine support (including modal-safe dropdown rendering).
- Global Links Engine (Start-menu style) with DB-backed management in Mod Tools.
- Contact page (public) with SMTP sender support.
- Seedr settings cleanup (no base URL) and stable integration wiring.
- Trakt moved out of user Settings and gated as Admin-only.
- TheTVDB v4 enrichment pipeline hardened (Backfill Step 1 fixed; config UI available).
- Mod Tools usability improvements: stacked Global Links Manager layout + independent section collapse.

## Included migrations
- `MASTER_SCHEMA.sql` (base schema)
- `migrations/RESOURCE_LINKS_MIGRATION.sql` (Global Links Engine)

## Known limitations
- Admin/Mod pages require login; public screenshots in this package are from user-provided captures.

