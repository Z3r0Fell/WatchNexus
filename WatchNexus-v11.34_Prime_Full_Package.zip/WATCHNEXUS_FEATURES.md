# WatchNexus — Feature List (Prime Release)

## Core experience
- **Calendar-first TV schedule** with Grid + List views and day modal.
- **Browse catalog** of shows with search/filtering and rich show cards.
- **My Shows** library for tracked shows (logged-in users).
- **Show tracking**: add/remove shows, keep your own watchlist state.

## Imports & data sources
- **TVMaze import** (date-ranged pulls) to populate schedules.
- **Sonarr integration**: import library from Sonarr (ID normalization handled).
- **TheTVDB v4 enrichment (optional)**: backfill and enrich metadata when a TVDB key is configured.

## Global Links Engine (site-wide)
- **“Links ▾” button on TV cards** across Browse / My Shows / Calendar.
- Start-menu style dropdown:
  - **Categories** (Info / Reviews / Media / Where to Watch / Search)
  - **Links** inside categories using token templates (e.g., `{QUERY}`, `{WIKI_TITLE}`, `{TVMAZE_ID}`, `{THETVDB_ID}`, `{IMDB_ID}`)
- **Public-safe visibility**: links can be flagged Public to show for logged-out users.
- **Mod Tools manager**: mods/admins can add/edit categories + links without redeploying.

## Integrations
- **Seedr integration** (REST v1):
  - Settings do **not** require a base URL (fixed to `seedr.cc`).
  - Credential save + test support.
- **Trakt** is **admin-only** (kept out of user Settings).

## Roles & governance
- **Admin Dashboard** for system-level configuration.
- **Mod Tools** for operational maintenance (including Global Links Manager).
- **Module Policy** remains in Admin (removed from Settings).

## Public pages
- **Contact Form** (no login required): sends messages via SMTP using a dedicated sender mailbox.

## UX & stability
- “Partial” page loads supported (`&partial=1`) for faster navigation.
- Defensive client-side behavior for dynamic UIs (calendar refreshes, modal overlays).
- Session hardening: session ID regeneration on login.

## Attribution
- TheTVDB attribution banner is included in the footer (image-based).

---

## Quick start (fresh install)
1. Import `MASTER_SCHEMA.sql` into MySQL.
2. Configure `app/config/config.local.php` (DB creds, mail sender, integrations).
3. Run `migrations/RESOURCE_LINKS_MIGRATION.sql` (for the Links Engine manager).
4. Log in as Admin → Mod Tools → Global Links Manager → **Seed Defaults**.

