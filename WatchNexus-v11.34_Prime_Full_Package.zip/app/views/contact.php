<?php
declare(strict_types=1);

// Public page (no login required)
?>

<div class="card">
  <div class="hd">
    <h2>Contact</h2>
    <div class="spacer"></div>
    <span class="small">Send feedback, report an issue, or drop a compliment like a grenade.</span>
  </div>

  <div class="bd">
    <div id="contactStatus" class="mt12"></div>

    <form id="contactForm" class="mt12" autocomplete="on">
      <div class="formgrid">
        <div>
          <div class="label">Your name</div>
          <input class="input" type="text" id="contact_name" name="name" maxlength="80" placeholder="e.g., Auz" required>
        </div>

        <div>
          <div class="label">Your email</div>
          <input class="input" type="email" id="contact_email" name="email" maxlength="120" placeholder="you@example.com" required>
        </div>

        <div>
          <div class="label">Topic</div>
          <select class="input" id="contact_topic" name="topic" required>
            <option value="" disabled selected>Select one…</option>
            <option>Feedback</option>
            <option>Website Issue</option>
            <option>Suggestion</option>
            <option>Praise</option>
          </select>
        </div>

        <div style="grid-column:1 / -1;">
          <div class="label">Message</div>
          <textarea class="input" id="contact_message" name="message" rows="6" maxlength="4000" placeholder="What happened? What were you trying to do? Screenshots help." required></textarea>
        </div>

        <!-- Honeypot (bots love filling everything) -->
        <div style="display:none;">
          <label class="label" for="contact_company">Company</label>
          <input class="input" type="text" id="contact_company" name="company" tabindex="-1" autocomplete="off">
        </div>
      </div>

      <div class="mt16 row" style="gap:10px;">
        <button class="btn primary" id="contactSubmit" type="submit">Send message</button>
        <a class="btn" href="/?page=calendar" data-nav>Back to calendar</a>
        <span class="small muted" style="margin-left:auto;">This form emails <strong>wmadmin@watchnexus.ca</strong>.</span>
      </div>

      <div class="small muted mt12">
        Please don’t include passwords, API keys, or anything you wouldn’t want living forever in an email thread.
      </div>
    </form>
  </div>
</div>
