<div class="card">
  <div class="hd">
    <h1>Acknowledgements</h1>
  </div>
  <div class="bd">
    <p>
      WatchNexus would not be possible without the incredible work of the following services and projects. We are grateful for their APIs, documentation, and communities.
    </p>
    
    <div class="small muted" style="margin-bottom: 32px; padding: 12px; background: rgba(255,255,255,0.03); border-radius: 6px;">
      <strong>Note:</strong> The services listed below are independent third parties. WatchNexus is not affiliated with, endorsed by, or sponsored by any of these organizations. Links are provided for informational purposes only.
    </div>
    
    <h2>Data Providers</h2>
    
    <div class="service-card">
      <div class="service-header">
        <h3>TVMaze</h3>
        <a href="https://www.tvmaze.com" target="_blank" rel="noopener" class="service-link">tvmaze.com →</a>
      </div>
      <p>
        TVMaze provides the comprehensive TV schedule data that powers WatchNexus. Their free, public API delivers show information, airing times, and episode details for thousands of shows worldwide.
      </p>
      <p><strong>What we use:</strong> Schedule API, show metadata, episode information</p>
      <p><strong>API Documentation:</strong> <a href="https://www.tvmaze.com/api" target="_blank" rel="noopener">https://www.tvmaze.com/api</a></p>
    </div>
    
    <div class="service-card">
      <div class="service-header">
        <h3>TheTVDB</h3>
        <a href="https://thetvdb.com" target="_blank" rel="noopener" class="service-link">thetvdb.com →</a>
      </div>
      <p>
        TheTVDB is a community-driven database of TV show metadata, including detailed descriptions, artwork, cast information, and episode data. Their API enhances WatchNexus with richer show information.
      </p>
      <p><strong>What we use:</strong> Enhanced metadata, artwork, episode details</p>
      <p><strong>API Documentation:</strong> <a href="https://thetvdb.com/api-information" target="_blank" rel="noopener">https://thetvdb.com/api-information</a></p>
    </div>
    
    <h2>Integration Partners</h2>
    
    <div class="service-card">
      <div class="service-header">
        <h3>Trakt</h3>
        <a href="https://trakt.tv" target="_blank" rel="noopener" class="service-link">trakt.tv →</a>
      </div>
      <p>
        Trakt is a platform that tracks TV shows and movies you watch. WatchNexus integrates with Trakt via OAuth to sync your watched history and tracked shows across devices.
      </p>
      <p><strong>What we use:</strong> OAuth authentication, sync API, user watch history</p>
      <p><strong>API Documentation:</strong> <a href="https://trakt.docs.apiary.io/" target="_blank" rel="noopener">https://trakt.docs.apiary.io/</a></p>
    </div>
    
    <div class="service-card">
      <div class="service-header">
        <h3>Seedr</h3>
        <a href="https://www.seedr.cc" target="_blank" rel="noopener" class="service-link">seedr.cc →</a>
      </div>
      <p>
        Seedr is a cloud-based torrent client that allows users to download torrents to the cloud and stream them instantly. WatchNexus can send magnet links to your Seedr account for convenient downloading.
      </p>
      <p><strong>What we use:</strong> Transfer API (magnet links, direct URLs)</p>
      <p><strong>Note:</strong> Seedr integration requires a Seedr account (paid or free tier)</p>
    </div>
    
    <div class="service-card">
      <div class="service-header">
        <h3>Jackett</h3>
        <a href="https://github.com/Jackett/Jackett" target="_blank" rel="noopener" class="service-link">github.com/Jackett →</a>
      </div>
      <p>
        Jackett is a proxy server that translates queries from apps into tracker-site-specific HTTP queries. It supports over 500+ torrent trackers and newznab indexers. <strong>Jackett is self-hosted</strong>—you run it on your own server.
      </p>
      <p><strong>What we use:</strong> Search API, indexer aggregation</p>
      <p><strong>License:</strong> Open source (GPL-2.0)</p>
    </div>
    
    <div class="service-card">
      <div class="service-header">
        <h3>Prowlarr</h3>
        <a href="https://github.com/Prowlarr/Prowlarr" target="_blank" rel="noopener" class="service-link">github.com/Prowlarr →</a>
      </div>
      <p>
        Prowlarr is an indexer manager and proxy that integrates with various applications. It's the spiritual successor to Jackett, built by the Sonarr/Radarr team. <strong>Prowlarr is self-hosted</strong>—you run it on your own server.
      </p>
      <p><strong>What we use:</strong> Search API, indexer management</p>
      <p><strong>License:</strong> Open source (GPL-3.0)</p>
    </div>
    
    <div class="service-card">
      <div class="service-header">
        <h3>Sonarr</h3>
        <a href="https://sonarr.tv" target="_blank" rel="noopener" class="service-link">sonarr.tv →</a>
      </div>
      <p>
        Sonarr is a PVR (Personal Video Recorder) for Usenet and BitTorrent users. WatchNexus can import your Sonarr library to automatically track shows you're monitoring.
      </p>
      <p><strong>What we use:</strong> Backup file parsing, show library import</p>
      <p><strong>License:</strong> Open source (GPL-3.0)</p>
    </div>
    
    <h2>Technology Stack</h2>
    
    <div class="tech-grid">
      <div class="tech-item">
        <h4>PHP 8.0+</h4>
        <p>Backend language powering WatchNexus</p>
      </div>
      
      <div class="tech-item">
        <h4>MySQL / MariaDB</h4>
        <p>Database engine for storing shows and user data</p>
      </div>
      
      <div class="tech-item">
        <h4>libsodium</h4>
        <p>Modern cryptography library for secure credential storage</p>
      </div>
      
      <div class="tech-item">
        <h4>cURL</h4>
        <p>HTTP client for API integrations</p>
      </div>
    </div>
    
    <h2>Legal Notice</h2>
    
    <p>
      <strong>WatchNexus is not affiliated with, endorsed by, sponsored by, or officially connected to any of the services listed above.</strong>
    </p>
    
    <p>
      All product names, logos, brands, and trademarks are property of their respective owners. Use of these names and logos does not imply affiliation or endorsement.
    </p>
    
    <p>
      WatchNexus is an independent project that integrates with public APIs and community tools. We respect the intellectual property and terms of service of all third-party providers.
    </p>
    
    <h2>Open Source Contributions</h2>
    
    <p>
      We believe in giving back to the community. If you're interested in contributing to WatchNexus or have suggestions for improvement, please contact us at <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a>.
    </p>
    
    <div style="margin-top: 40px; padding: 20px; background: rgba(0,255,0,0.05); border-left: 4px solid var(--primary); border-radius: 6px; text-align: center;">
      <p style="margin: 0; font-size: 1.1rem;">
        <strong>Thank you to all the developers, maintainers, and communities behind these amazing projects.</strong>
      </p>
      <p style="margin: 12px 0 0; color: var(--text-muted);">
        Without your hard work, WatchNexus wouldn't exist.
      </p>
    </div>
  </div>
</div>

<style>
.bd h2 {
  font-size: 1.3rem;
  margin-top: 32px;
  margin-bottom: 20px;
  color: var(--primary);
}

.bd h3 {
  font-size: 1.1rem;
  margin: 0;
  color: var(--text);
}

.bd h4 {
  font-size: 0.95rem;
  margin: 0 0 6px 0;
  color: var(--primary);
}

.bd p {
  line-height: 1.6;
  margin-bottom: 12px;
}

.bd a {
  color: var(--primary);
  text-decoration: underline;
}

.bd a:hover {
  color: var(--accent);
}

.service-card {
  margin-bottom: 24px;
  padding: 20px;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 10px;
  transition: background 0.2s, border-color 0.2s;
}

.service-card:hover {
  background: rgba(255, 255, 255, 0.05);
  border-color: rgba(255, 255, 255, 0.15);
}

.service-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.service-link {
  font-size: 0.9rem;
  text-decoration: none !important;
  color: var(--primary);
  white-space: nowrap;
}

.service-link:hover {
  color: var(--accent);
}

.tech-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin: 20px 0;
}

.tech-item {
  padding: 16px;
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 8px;
}

.tech-item p {
  font-size: 0.85rem;
  color: var(--text-muted);
  margin: 0;
}

@media (max-width: 768px) {
  .service-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }
  
  .tech-grid {
    grid-template-columns: 1fr;
  }
}
</style>
