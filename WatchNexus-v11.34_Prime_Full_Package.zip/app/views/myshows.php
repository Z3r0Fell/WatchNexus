<?php
declare(strict_types=1);

$u = current_user();
if (!$u) {
  echo '<div class="banner warn"><div class="badge">Login required</div><div><p>Please login to track shows.</p></div></div>';
  return;
}
?>

<div class="card">
  <div class="hd">
    <h2>My Shows</h2>
    <div class="spacer"></div>
    <div style="display:flex;gap:12px;align-items:center;">
      <span class="small muted" id="show-count">Loading...</span>
      <select id="per-page" style="padding:8px 12px;border-radius:6px;border:1px solid rgba(255,255,255,0.14);background:rgba(255,255,255,0.06);color:inherit;cursor:pointer;">
        <option value="25">25 per page</option>
        <option value="50">50 per page</option>
        <option value="100">100 per page</option>
        <option value="9999">Show All</option>
      </select>
    </div>
  </div>
  
  <div class="bd">
    <div id="myshows-container">
      <p class="small muted">Loading your tracked shows...</p>
    </div>
    
    <div id="pagination" style="margin-top:24px;display:flex;justify-content:center;align-items:center;gap:12px;"></div>
  </div>
</div>

<style>
.myshows-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 16px;
  margin-top: 16px;
}

.myshow-card {
  background: rgba(255,255,255,0.02);
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 8px;
  overflow: hidden;
  transition: transform 0.2s, box-shadow 0.2s;
  cursor: pointer;
}

.myshow-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  border-color: rgba(255,255,255,0.2);
}

.myshow-poster {
  width: 100%;
  aspect-ratio: 2/3;
  object-fit: cover;
  background: rgba(255,255,255,0.05);
}

.myshow-info {
  padding: 10px;
}

.myshow-title {
  font-weight: 600;
  font-size: 0.85rem;
  margin-bottom: 6px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  line-height: 1.3;
  min-height: 2.6em;
}

.myshow-status {
  font-size: 0.75rem;
  color: rgba(255,255,255,0.6);
  margin-bottom: 4px;
}

.myshow-status.monitored {
  color: #0f0;
}

.myshow-date {
  font-size: 0.7rem;
  color: rgba(255,255,255,0.5);
}

.myshow-untrack {
  width: 100%;
  padding: 6px;
  margin-top: 8px;
  background: rgba(255,0,0,0.1);
  border: 1px solid rgba(255,0,0,0.3);
  color: #f44;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.75rem;
  transition: background 0.2s;
}

.myshow-untrack:hover {
  background: rgba(255,0,0,0.2);
}

.pagination-btn {
  padding: 8px 16px;
  border: 1px solid rgba(255,255,255,0.1);
  background: rgba(255,255,255,0.03);
  color: inherit;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.2s;
}

.pagination-btn:hover:not(:disabled) {
  background: rgba(255,255,255,0.08);
}

.pagination-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.pagination-info {
  font-size: 0.85rem;
  opacity: 0.8;
}
</style>

<script>
(async function() {
  console.log('My Shows page loaded');
  
  let allShows = [];
  let currentPage = 1;
  let perPage = 25;
  
  const container = document.getElementById('myshows-container');
  const pagination = document.getElementById('pagination');
  const showCount = document.getElementById('show-count');
  const perPageSelect = document.getElementById('per-page');
  
  // Load tracked shows
  async function loadShows() {
    try {
      const resp = await fetch('/api/myshows.php');
      const data = await resp.json();
      
      if (!data.ok) {
        container.innerHTML = '<p class="error">Failed to load shows: ' + (data.error || 'Unknown error') + '</p>';
        return;
      }
      
      allShows = data.shows || [];
      showCount.textContent = allShows.length + ' shows tracked';
      
      if (allShows.length === 0) {
        container.innerHTML = '<p>You haven\'t tracked any shows yet. Go to <a href="?page=browse">Browse</a> or <a href="?page=calendar">Calendar</a> to start tracking!</p>';
        return;
      }
      
      renderShows();
      
    } catch (err) {
      console.error('Load shows error:', err);
      container.innerHTML = '<p class="error">Error loading shows: ' + err.message + '</p>';
    }
  }
  
  // Render shows for current page
  function renderShows() {
    if (allShows.length === 0) return;
    
    const start = (currentPage - 1) * perPage;
    const end = perPage === 9999 ? allShows.length : start + perPage;
    const pageShows = allShows.slice(start, end);
    
    let html = '<div class="myshows-grid">';
    
    pageShows.forEach(show => {
      const status = show.status || 'unknown';
      const premiered = show.premiered ? new Date(show.premiered).getFullYear() : '—';
      const addedDate = show.tracked_at ? new Date(show.tracked_at).toLocaleDateString() : 'Unknown';
      
      html += `
        <div class="myshow-card" data-show-id="${show.id}">
          <img src="${show.poster_url || '/assets/placeholder.png'}" class="myshow-poster" alt="${show.title}">
          <div class="myshow-info">
            <div class="myshow-title">${show.title}</div>
            <div class="myshow-status monitored">Monitored</div>
            <div class="myshow-status">Any</div>
            <div class="myshow-date">Added: ${addedDate}</div>
            <div class="wnx-links-wrap" style="position:relative;margin-top:8px;">
              <button class="btn small wnx-links-btn" type="button" data-show-id="${show.id}" data-title="${escapeHtml(show.title)}">Links ▾</button>
              <div class="wnx-links-menu" hidden></div>
            </div>
            <button class="myshow-untrack" data-show-id="${show.id}" data-show-title="${show.title}">Untrack</button>
          </div>
        </div>
      `;
    });
    
    html += '</div>';
    container.innerHTML = html;
    
    renderPagination();
  }
  
  // Render pagination controls
  function renderPagination() {
    if (perPage === 9999 || allShows.length <= perPage) {
      pagination.innerHTML = '';
      return;
    }
    
    const totalPages = Math.ceil(allShows.length / perPage);
    
    let html = '';
    html += `<button class="pagination-btn" onclick="myshowsChangePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>◀ Previous</button>`;
    html += `<span class="pagination-info">Page ${currentPage} of ${totalPages} (${allShows.length} shows)</span>`;
    html += `<button class="pagination-btn" onclick="myshowsChangePage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>Next ▶</button>`;
    
    pagination.innerHTML = html;
  }
  
  // Change page
  window.myshowsChangePage = function(page) {
    const totalPages = Math.ceil(allShows.length / perPage);
    if (page < 1 || page > totalPages) return;
    currentPage = page;
    renderShows();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  // Per page change
  perPageSelect.addEventListener('change', function() {
    perPage = parseInt(this.value);
    currentPage = 1;
    renderShows();
  });
  
  // Untrack handler
  document.addEventListener('click', async function(e) {
    const untrackBtn = e.target.closest('.myshow-untrack');
    if (!untrackBtn) return;
    
    e.stopPropagation();
    const showId = parseInt(untrackBtn.dataset.showId);
    const showTitle = untrackBtn.dataset.showTitle;
    
    if (!confirm(`Untrack "${showTitle}"?`)) return;
    
    untrackBtn.disabled = true;
    untrackBtn.textContent = 'Untracking...';
    
    try {
      const resp = await fetch('/api/myshows.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', show_id: showId })
      });
      
      const data = await resp.json();
      
      if (data.ok) {
        // Remove from local array
        allShows = allShows.filter(s => s.id !== showId);
        showCount.textContent = allShows.length + ' shows tracked';
        
        // Re-render
        if (allShows.length === 0) {
          container.innerHTML = '<p>You haven\'t tracked any shows yet. Go to <a href="?page=browse">Browse</a> or <a href="?page=calendar">Calendar</a> to start tracking!</p>';
          pagination.innerHTML = '';
        } else {
          // Adjust page if needed
          const totalPages = Math.ceil(allShows.length / perPage);
          if (currentPage > totalPages) currentPage = totalPages;
          renderShows();
        }
      } else {
        untrackBtn.disabled = false;
        untrackBtn.textContent = 'Untrack';
        alert('Failed to untrack: ' + (data.error || 'Unknown error'));
      }
    } catch (err) {
      console.error('Untrack error:', err);
      untrackBtn.disabled = false;
      untrackBtn.textContent = 'Untrack';
      alert('Error untracking show: ' + err.message);
    }
  });
  
  // Initialize
  loadShows();
  
})();
</script>
