<?php
declare(strict_types=1);

/**
 * layout.php
 * - Full-page shell for WatchNexus
 * - Must not output anything before DOCTYPE
 */

$title   = $title ?? 'WatchNexus';
$content = $content ?? '';
$page    = $page ?? ($_GET['page'] ?? 'calendar');
$u       = function_exists('current_user') ? current_user() : null;

?>
<!doctype html>
<html lang="en" data-theme="grid_noir" data-mode="dark">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></title>

  <link rel="stylesheet" href="/assets/css/base.css?v=4">
  <link rel="stylesheet" href="/assets/css/calendar.css?v=4">
  <link rel="stylesheet" href="/assets/css/themes.css?v=4">
  <link rel="stylesheet" href="/assets/css/modes.css?v=4">
  <link rel="stylesheet" href="/assets/css/packs.css?v=1">
</head>
<body>
  <header class="topbar">
    <div class="container">
      <div class="row wrap" style="gap:12px;">
        <div class="brand" style="padding:0;">
          <div class="mark" aria-hidden="true">
            <svg class="wnx-mark" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
              <circle cx="32" cy="32" r="25" fill="none" stroke="var(--logo-a, var(--primary))" stroke-width="4" opacity="0.9" />
              <circle cx="32" cy="32" r="18" fill="none" stroke="var(--logo-b, var(--accent))" stroke-width="2" opacity="0.55" stroke-dasharray="5 6" />
              <path d="M 12 36 A 22 22 0 0 0 52 28" fill="none" stroke="var(--logo-b, var(--accent2))" stroke-width="5" stroke-linecap="round" opacity="0.95" />
              <circle cx="32" cy="32" r="5" fill="var(--logo-c, var(--accent2))" opacity="0.95" />
            </svg>
          </div>
          <div>
            <div class="name wnx-word">WatchNexus</div>
            <div class="sub">Ultimate tracker • calendar-first • integrations-ready</div>
          </div>
        </div>

        <div class="spacer"></div>

        <button class="btn" type="button" id="themeBtn" hidden>Appearance</button>

        <span class="badge" id="userPill" hidden></span>

        <a class="btn" id="loginBtn" href="/?page=login">Login</a>
        <a class="btn" id="registerBtn" href="/?page=register">Register</a>
        <a class="btn" id="logoutBtn" href="/?page=logout" hidden>Logout</a>
      </div>

      <div id="publicBanner" class="banner mt12" <?= $u ? 'hidden' : '' ?>>
        <div class="badge">Public</div>
        <div>
          <p>Sign in to enable themes, tracking, downloads, and integrations.</p>
        </div>
      </div>

      <nav class="tabs" id="navTabs" style="margin-top:10px;"></nav>
    </div>
  </header>

  <!-- Universal Hero (Interface Pack Chrome) -->
  <section class="pack-hero-shell" aria-label="WatchNexus Hero">
    <div class="container">
      <div class="pack-hero" id="packHero">
        <div class="pack-hero-badge" id="packHeroName" title="Current interface pack">Classic</div>
        <div class="pack-hero-inner">
          <div class="pack-hero-mark" aria-hidden="true">
            <svg class="wnx-mark big" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
              <circle cx="32" cy="32" r="25" fill="none" stroke="var(--logo-a, var(--primary))" stroke-width="4" opacity="0.92" />
              <circle cx="32" cy="32" r="18" fill="none" stroke="var(--logo-b, var(--accent))" stroke-width="2" opacity="0.55" stroke-dasharray="5 6" />
              <path d="M 12 36 A 22 22 0 0 0 52 28" fill="none" stroke="var(--logo-b, var(--accent2))" stroke-width="6" stroke-linecap="round" opacity="0.98" />
              <circle cx="32" cy="32" r="5" fill="var(--logo-c, var(--accent2))" opacity="0.98" />
            </svg>
          </div>

          <div class="pack-hero-title wnx-word">WatchNexus</div>
          <div class="pack-hero-sub">Calendar-first tracking • Integrations-ready • Your shows, weaponized.</div>

          <div class="pack-hero-chips" aria-label="Highlights">
            <span class="chip">Calendar Grid</span>
            <span class="chip">Browse &amp; Track</span>
            <span class="chip">Trakt / TVMaze</span>
            <span class="chip">Seedbox-ready</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <main id="appContent" class="container" data-page="<?= htmlspecialchars((string)$page, ENT_QUOTES, 'UTF-8') ?>">
    <?= $content ?>
  </main>

  <!-- Footer -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <div class="footer-brand">WatchNexus</div>
          <p class="footer-tagline">Your ultimate TV tracking companion</p>
        </div>
        
        <div class="footer-section">
          <h4>Legal</h4>
          <ul class="footer-links">
            <li><a href="?page=privacy">Privacy Policy</a></li>
            <li><a href="?page=terms">Terms of Service</a></li>
            <li><a href="?page=acknowledgements">Acknowledgements</a></li>
          </ul>
        </div>
        
        <div class="footer-section">
          <h4>Contact</h4>
          <ul class="footer-links">
            <li><a href="/?page=contact" data-nav>Contact form</a></li>
            <li>
              <img
                src="/assets/img/tvdb_attribution.png"
                alt="Metadata provided by TheTVDB. Please consider adding missing information or subscribing."
                style="max-width:340px;width:100%;height:auto;display:block;margin-top:6px;opacity:0.95;"
              >
            </li>
            <li><a href="mailto:wmadmin@watchnexus.ca">wmadmin@watchnexus.ca</a></li>
          </ul>
        </div>
      </div>
      
      <div class="footer-bottom">
        <p>&copy; 2026 WatchNexus. All rights reserved.</p>
      </div>
    </div>
  </footer>

  <!-- Appearance Modal (Interface Packs + Advanced Overrides) -->
  <div id="themeModal" class="modal-backdrop" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="appearanceTitle">
      <div class="mh">
        <div class="h" id="appearanceTitle">Appearance</div>
        <div class="spacer"></div>
        <button id="themeClose" class="btn" type="button">✕</button>
      </div>

      <div class="mb">
        <div class="label">Interface Pack</div>
        <div class="pack-grid" id="packGrid" aria-label="Interface packs"></div>

        <div class="formgrid mt16">
          <div>
            <div class="label">Color scheme</div>
            <select id="modeSelect" class="input">
              <option value="system">System</option>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>
          <div>
            <div class="label">Effects</div>
            <label class="toggle">
              <input type="checkbox" id="fxScanlines">
              <span class="toggle-ui" aria-hidden="true"></span>
              <span class="small muted">Scanlines overlay</span>
            </label>
          </div>
        </div>

        <div class="mt16 pack-advanced">
          <div class="row" style="gap:10px;align-items:center;">
            <div class="label" style="margin:0;">Advanced</div>
            <label class="toggle" style="margin-top:0;">
              <input type="checkbox" id="advancedToggle">
              <span class="toggle-ui" aria-hidden="true"></span>
              <span class="small muted">Manual overrides (legacy theme + UI mode)</span>
            </label>
          </div>

          <div id="advancedSection" class="formgrid mt12" hidden>
            <div>
              <div class="label">Legacy theme</div>
              <select id="themeSelect" class="input"></select>
            </div>
            <div>
              <div class="label">Legacy UI mode</div>
              <select id="uiModeSelect" class="input">
                <option value="command">⚡ Command</option>
                <option value="overview">📊 Overview</option>
                <option value="signal">📡 Signal</option>
                <option value="nebula">🌌 Nebula</option>
              </select>
            </div>
          </div>
        </div>

        <div class="small muted mt12">
          Packs change the full interface: colors, chrome, logo harmonies, and hero styling — in one click.
        </div>
      </div>

      <div class="ft">
        <button id="applyTheme" class="btn primary" type="button">Apply</button>
        <button id="resetTheme" class="btn" type="button">Reset</button>
      </div>
    </div>
  </div>

  <script src="/assets/js/app.js?v=4"></script>
  <script src="/assets/js/appearance.js?v=5"></script>
  <script src="/assets/js/settings.js?v=4"></script>
  <script src="/assets/js/contact.js?v=1"></script>
  <script src="/assets/js/resource_links.js?v=1"></script>
</body>
</html>
