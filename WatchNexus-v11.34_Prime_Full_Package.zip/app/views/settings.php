<?php
declare(strict_types=1);

$u = current_user();
if (!$u) {
  echo '<div class="banner warn"><div class="badge">Login required</div><div><p>Please login to access Settings.</p></div></div>';
  return;
}
?>

<style>
.accordion {
  margin-top: 16px;
}
.accordion-item {
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  margin-bottom: 12px;
  overflow: hidden;
  background: rgba(255,255,255,0.02);
}
.accordion-header {
  background: rgba(255,255,255,0.05);
  padding: 16px 20px;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  user-select: none;
  transition: background 0.2s;
}
.accordion-header:hover {
  background: rgba(255,255,255,0.08);
}
.accordion-header h3 {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
}
.accordion-icon {
  transition: transform 0.2s;
  font-size: 1.2rem;
}
.accordion-item.open .accordion-icon {
  transform: rotate(180deg);
}
.accordion-content {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.3s ease-out;
}
.accordion-item.open .accordion-content {
  max-height: 5000px;
  transition: max-height 0.5s ease-in;
}
.accordion-body {
  padding: 20px;
}
</style>

<div class="card">
  <div class="hd">
    <h2>Settings</h2>
    <div class="spacer"></div>
    <span class="small">Configure your experience</span>
  </div>

  <div class="bd">
    <div id="settingsStatus" class="small muted">Loading…</div>

    <div class="accordion">
      <!-- Modules Section -->
      <div class="accordion-item open">
        <div class="accordion-header" onclick="this.parentElement.classList.toggle('open')">
          <div>
            <h3>Modules</h3>
            <p class="small muted" style="margin:4px 0 0;">Show or hide features</p>
          </div>
          <span class="accordion-icon">▼</span>
        </div>
        <div class="accordion-content">
          <div class="accordion-body" id="modulesBox">
            <p class="small muted">Loading modules…</p>
          </div>
        </div>
      </div>

      <!-- Integrations Section -->
      <div class="accordion-item">
        <div class="accordion-header" onclick="this.parentElement.classList.toggle('open')">
          <div>
            <h3>Integrations</h3>
            <p class="small muted" style="margin:4px 0 0;">Connect external services</p>
          </div>
          <span class="accordion-icon">▼</span>
        </div>
        <div class="accordion-content">
          <div class="accordion-body" id="integrationsBox">
            <p class="small muted">Loading integrations…</p>
          </div>
        </div>
      </div>
    </div>

    <div class="mt16 row">
      <button class="btn primary" id="saveSettings" type="button">Save All Changes</button>

      <button class="btn" id="reloadSettings" type="button">Reload</button>
      <span class="small muted" id="saveHint" style="margin-left:auto;"></span>
    </div>
  </div>
</div>

<script>
// --- TVDB (admin) ---
async function loadTvdbStatus() {
  const el = document.getElementById('tvdb-status');
  if (!el) return;

  try {
    const resp = await fetch('/api/admin_tvdb_status.php');
    const txt = await resp.text();
    let data = null;
    try { data = JSON.parse(txt); } catch (_) {}

    if (!resp.ok || !data || !data.ok) {
      el.textContent = (data && data.error) ? data.error : `TVDB status unavailable (HTTP ${resp.status})`;
      return;
    }

    if (!data.configured) {
      el.textContent = 'Not configured';
      return;
    }

    const tokenBit = data.has_token ? (data.token_valid ? 'Token OK' : 'Token stale') : 'No token yet';
    el.textContent = `Configured • ${tokenBit}`;
  } catch (e) {
    el.textContent = 'TVDB status error';
  }
}

async function saveTvdbConfig() {
  const apikey = (document.getElementById('tvdb-apikey') || {}).value || '';
  const pin = (document.getElementById('tvdb-pin') || {}).value || '';

  const resp = await fetch('/api/admin_tvdb_config.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ apikey, pin })
  });

  const txt = await resp.text();
  let data = null;
  try { data = JSON.parse(txt); } catch (_) {}

  if (!resp.ok || !data || !data.ok) {
    throw new Error((data && data.error) ? data.error : `HTTP ${resp.status}`);
  }
  return data;
}

async function testTvdbAuth() {
  const resp = await fetch('/api/admin_tvdb_test.php', { method: 'POST' });
  const txt = await resp.text();
  let data = null;
  try { data = JSON.parse(txt); } catch (_) {}

  if (!resp.ok || !data || !data.ok) {
    throw new Error((data && data.error) ? data.error : `HTTP ${resp.status}`);
  }
  return data;
}

(function wireTvdb() {
  const saveBtn = document.getElementById('tvdb-save-btn');
  const testBtn = document.getElementById('tvdb-test-btn');
  const statusEl = document.getElementById('tvdb-status');
  if (!saveBtn || !testBtn) return;

  saveBtn.addEventListener('click', async () => {
    try {
      saveBtn.disabled = true;
      if (statusEl) statusEl.textContent = 'Saving...';
      await saveTvdbConfig();
      if (statusEl) statusEl.textContent = 'Saved. Testing...';
      await testTvdbAuth();
      if (statusEl) statusEl.textContent = 'Configured • Token OK';
    } catch (e) {
      if (statusEl) statusEl.textContent = (e && e.message) ? e.message : 'Save failed';
    } finally {
      saveBtn.disabled = false;
    }
  });

  testBtn.addEventListener('click', async () => {
    try {
      testBtn.disabled = true;
      if (statusEl) statusEl.textContent = 'Testing...';
      await testTvdbAuth();
      if (statusEl) statusEl.textContent = 'Configured • Token OK';
    } catch (e) {
      if (statusEl) statusEl.textContent = (e && e.message) ? e.message : 'Auth failed';
    } finally {
      testBtn.disabled = false;
    }
  });
})();
loadTvdbStatus();
</script>
