<div class="card">
  <div class="hd">
    <h1>Terms of Service</h1>
  </div>
  <div class="bd">
    <p class="small muted">Last updated: January 9, 2026</p>
    
    <h2>Acceptance of Terms</h2>
    <p>
      By accessing or using WatchNexus, you agree to be bound by these Terms of Service. If you do not agree to these terms, do not use the service. We reserve the right to modify these terms at any time, and continued use after changes constitutes acceptance.
    </p>
    
    <h2>Description of Service</h2>
    <p>
      WatchNexus is a TV show tracking and calendar service that helps you:
    </p>
    <ul>
      <li>Track TV shows you're watching</li>
      <li>View airing schedules from public data sources</li>
      <li>Integrate with third-party services (Trakt, Seedr, Jackett, Prowlarr)</li>
      <li>Organize your viewing preferences</li>
    </ul>
    <p>
      <strong>WatchNexus is a tracking and organizational tool only.</strong> We do not host, store, or transmit any media files, torrents, or copyrighted content.
    </p>
    
    <h2>User Responsibilities</h2>
    
    <h3>Account Security</h3>
    <p>You are responsible for:</p>
    <ul>
      <li>Maintaining the confidentiality of your account credentials</li>
      <li>All activity that occurs under your account</li>
      <li>Immediately notifying us of any unauthorized access</li>
      <li>Using a strong, unique password</li>
      <li>Keeping your email address current and accessible</li>
    </ul>
    <p>
      <strong>We are not responsible for any loss or damage resulting from your failure to secure your account.</strong>
    </p>
    
    <h3>Legal Use Only</h3>
    <p>You agree to use WatchNexus only for lawful purposes. You will not:</p>
    <ul>
      <li>Use the service to facilitate copyright infringement</li>
      <li>Access or attempt to access unauthorized areas of the service</li>
      <li>Interfere with or disrupt the service or servers</li>
      <li>Attempt to reverse engineer or compromise security measures</li>
      <li>Use automated tools (bots, scrapers) without permission</li>
      <li>Share account credentials with others</li>
      <li>Violate any applicable laws or regulations</li>
    </ul>
    
    <h2>Third-Party Integrations</h2>
    
    <h3>Your Responsibility</h3>
    <p>
      WatchNexus allows integration with third-party services (Trakt, Seedr, Jackett, Prowlarr). <strong>You are solely responsible for:</strong>
    </p>
    <ul>
      <li><strong>What you search for:</strong> WatchNexus does not monitor or control your searches</li>
      <li><strong>What you download:</strong> WatchNexus does not host, store, or transmit any files</li>
      <li><strong>Copyright compliance:</strong> Ensure you have legal rights to any content you access</li>
      <li><strong>Terms of service:</strong> You must comply with each third-party service's terms</li>
    </ul>
    
    <h3>No File Hosting</h3>
    <p>
      <strong>WatchNexus does NOT:</strong>
    </p>
    <ul>
      <li>Host, store, or transmit any media files</li>
      <li>Provide, index, or link to torrent files or magnet links</li>
      <li>Facilitate file sharing or downloads directly</li>
      <li>Store any copyrighted content on our servers</li>
    </ul>
    <p>
      WatchNexus simply <strong>passes your search queries</strong> to third-party services <strong>you configure</strong>. All results come from those external services, not from WatchNexus.
    </p>
    
    <h3>Seedr Disclaimer</h3>
    <p>
      Seedr integration allows you to send magnet links or URLs to your Seedr account. WatchNexus:
    </p>
    <ul>
      <li>Does not control what you send to Seedr</li>
      <li>Does not monitor or log your Seedr activity</li>
      <li>Is not responsible for content in your Seedr account</li>
      <li>Simply acts as a bridge using your Seedr credentials</li>
    </ul>
    <p>
      <strong>You are responsible for ensuring you have legal rights to any content you transfer to Seedr.</strong>
    </p>
    
    <h2>Disclaimers and Limitations of Liability</h2>
    
    <h3>No Warranty</h3>
    <p>
      WatchNexus is provided "AS IS" without warranty of any kind, express or implied, including but not limited to:
    </p>
    <ul>
      <li>Accuracy or completeness of schedule data</li>
      <li>Availability or reliability of the service</li>
      <li>Security of third-party integrations</li>
      <li>Fitness for a particular purpose</li>
    </ul>
    
    <h3>Limitation of Liability</h3>
    <p>
      <strong>TO THE MAXIMUM EXTENT PERMITTED BY LAW:</strong>
    </p>
    <ul>
      <li><strong>WatchNexus and its operators are NOT LIABLE</strong> for any damages arising from:
        <ul>
          <li>Use or inability to use the service</li>
          <li>Unauthorized access to your account</li>
          <li>Actions you take using integrated services</li>
          <li>Copyright infringement or legal violations</li>
          <li>Loss of data or security breaches</li>
          <li>Third-party service failures or data loss</li>
        </ul>
      </li>
      <li><strong>You assume all risks</strong> associated with using WatchNexus and any integrated services</li>
      <li><strong>Maximum liability:</strong> If we are found liable, damages are limited to $10 CAD</li>
    </ul>
    
    <h3>Indemnification</h3>
    <p>
      You agree to indemnify and hold harmless WatchNexus, its operators, and affiliates from any claims, damages, or expenses arising from:
    </p>
    <ul>
      <li>Your use of the service</li>
      <li>Your violation of these terms</li>
      <li>Your violation of any laws or third-party rights</li>
      <li>Content you access, download, or transfer through integrated services</li>
    </ul>
    
    <h2>Data Sources and Attribution</h2>
    <p>
      WatchNexus aggregates TV schedule data from public sources:
    </p>
    <ul>
      <li><strong>TVMaze API:</strong> Primary schedule data provider</li>
      <li><strong>TheTVDB:</strong> Enhanced metadata (when available)</li>
      <li><strong>User contributions:</strong> Sonarr library imports</li>
    </ul>
    <p>
      We make reasonable efforts to ensure data accuracy, but <strong>we do not guarantee completeness or correctness</strong> of schedule information.
    </p>
    
    <h2>Copyright and DMCA</h2>
    <p>
      WatchNexus respects intellectual property rights. If you believe your copyrighted work has been infringed:
    </p>
    <ul>
      <li>WatchNexus does not host or store any media files</li>
      <li>We only display publicly available schedule data</li>
      <li>Contact the source (TVMaze, TheTVDB, etc.) if data is incorrect</li>
    </ul>
    <p>
      For legitimate copyright concerns, contact: <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a>
    </p>
    
    <h2>Account Termination</h2>
    <p>
      We reserve the right to suspend or terminate your account at any time for:
    </p>
    <ul>
      <li>Violation of these Terms of Service</li>
      <li>Abusive or illegal behavior</li>
      <li>Excessive resource usage or abuse of the service</li>
      <li>Failure to maintain a valid email address</li>
    </ul>
    <p>
      You may delete your account at any time by contacting <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a>.
    </p>
    
    <h2>Privacy</h2>
    <p>
      Your use of WatchNexus is also governed by our <a href="?page=privacy">Privacy Policy</a>. By using the service, you consent to our data practices as described in the Privacy Policy.
    </p>
    
    <h2>Governing Law</h2>
    <p>
      These Terms of Service are governed by the laws of Canada. Any disputes shall be resolved in the courts of Canada. If any provision is found unenforceable, the remaining provisions remain in effect.
    </p>
    
    <h2>Changes to Terms</h2>
    <p>
      We may update these Terms of Service at any time. Material changes will be communicated via email or prominent notice. Continued use after changes constitutes acceptance of the updated terms.
    </p>
    
    <h2>Contact</h2>
    <p>
      Questions about these Terms of Service? Contact us:
    </p>
    <p>
      <strong>Email:</strong> <a href="mailto:admin@watchnexus.ca">admin@watchnexus.ca</a><br>
      <strong>Service:</strong> WatchNexus<br>
      <strong>Location:</strong> Canada
    </p>
    
    <div style="margin-top: 40px; padding: 20px; background: rgba(255,165,0,0.1); border-left: 4px solid #fa0; border-radius: 6px;">
      <h3 style="margin-top: 0; color: #fa0;">⚠️ Important Reminder</h3>
      <p style="margin-bottom: 0;">
        <strong>You are responsible for ensuring you have legal rights to access any content.</strong> WatchNexus is a tracking tool only—we do not host, store, or distribute any media files. By using third-party integrations, you assume all responsibility for your actions and compliance with applicable laws.
      </p>
    </div>
  </div>
</div>

<style>
.bd h2 {
  font-size: 1.3rem;
  margin-top: 32px;
  margin-bottom: 12px;
  color: var(--primary);
}

.bd h3 {
  font-size: 1.1rem;
  margin-top: 20px;
  margin-bottom: 10px;
  color: var(--text);
}

.bd p {
  line-height: 1.6;
  margin-bottom: 16px;
}

.bd ul {
  margin-bottom: 16px;
  padding-left: 24px;
  line-height: 1.6;
}

.bd li {
  margin-bottom: 8px;
}

.bd a {
  color: var(--primary);
  text-decoration: underline;
}

.bd a:hover {
  color: var(--accent);
}
</style>
