<?php
declare(strict_types=1);

/**
 * Local (host-specific) configuration for WatchNexus.
 *
 * Copy this file to: app/config/config.local.php
 * Then edit values below.
 *
 * NEVER commit config.local.php to version control.
 */

$WNX_CONFIG_LOCAL = [
  'debug' => false, // set true temporarily to show detailed API errors

  'db' => [
    'host' => 'YOUR_DB_HOST',
    'name' => 'YOUR_DB_NAME',
    'user' => 'YOUR_DB_USER',
    'pass' => 'YOUR_DB_PASSWORD',
    'charset' => 'utf8mb4',
  ],

  // Base64-encoded 32-byte key for encryption-at-rest (libsodium secretbox).
  // Generate with: php -r "echo base64_encode(random_bytes(32)).PHP_EOL;"
  'secret_key_b64' => 'PASTE_32BYTE_BASE64_KEY_HERE',
];
