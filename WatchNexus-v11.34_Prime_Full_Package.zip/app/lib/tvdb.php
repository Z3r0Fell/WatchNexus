<?php
declare(strict_types=1);

/**
 * TheTVDB v4 helper (system-wide config).
 *
 * Stores:
 *  - tvdb_apikey (enc)
 *  - tvdb_pin    (enc, optional)
 *  - tvdb_token  (enc, bearer token)
 *  - tvdb_token_expires_utc (plain, ISO8601 UTC)
 */

function tvdb_base_url(): string {
  return 'https://api4.thetvdb.com/v4';
}

function tvdb_now_utc_iso(): string {
  return gmdate('c');
}

function tvdb_get_system_config(string $key): array {
  $pdo = db();
  $st = $pdo->prepare("SELECT config_value_plain, config_value_enc FROM system_config WHERE config_key = ? LIMIT 1");
  $st->execute([$key]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if (!$row) return ['plain' => null, 'enc' => null];
  return ['plain' => $row['config_value_plain'] ?? null, 'enc' => $row['config_value_enc'] ?? null];
}

function tvdb_set_system_config(string $key, ?string $plain, ?string $enc): void {
  $pdo = db();
  $st = $pdo->prepare("
    INSERT INTO system_config (config_key, config_value_plain, config_value_enc)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE
      config_value_plain = VALUES(config_value_plain),
      config_value_enc   = VALUES(config_value_enc)
  ");
  $st->execute([$key, $plain, $enc]);
}

function tvdb_get_apikey(): string {
  $row = tvdb_get_system_config('tvdb_apikey');
  $packed = (string)($row['enc'] ?? '');
  if ($packed === '') return '';
  return decrypt_secret($packed);
}

function tvdb_get_pin(): string {
  $row = tvdb_get_system_config('tvdb_pin');
  $packed = (string)($row['enc'] ?? '');
  if ($packed === '') return '';
  return decrypt_secret($packed);
}

function tvdb_get_token(): string {
  $row = tvdb_get_system_config('tvdb_token');
  $packed = (string)($row['enc'] ?? '');
  if ($packed === '') return '';
  return decrypt_secret($packed);
}

function tvdb_get_token_expires_utc(): string {
  $row = tvdb_get_system_config('tvdb_token_expires_utc');
  return (string)($row['plain'] ?? '');
}

function tvdb_set_token(string $token, string $expiresUtcIso): void {
  tvdb_set_system_config('tvdb_token', null, encrypt_secret($token));
  tvdb_set_system_config('tvdb_token_expires_utc', $expiresUtcIso, null);
}

function tvdb_token_is_valid(): bool {
  $token = tvdb_get_token();
  if ($token === '') return false;

  $exp = tvdb_get_token_expires_utc();
  if ($exp === '') return true; // no expiry stored, assume valid

  $expTs = strtotime($exp);
  if ($expTs === false) return true;

  // refresh if within 24h of expiry
  return (time() + 86400) < $expTs;
}

function tvdb_http(string $method, string $url, ?array $jsonBody = null, array $headers = []): array {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 12);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

  $method = strtoupper($method);
  if ($method !== 'GET') {
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  }

  $hdrs = $headers;
  if ($jsonBody !== null) {
    $payload = json_encode($jsonBody);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    $hdrs[] = 'Content-Type: application/json';
    $hdrs[] = 'Content-Length: ' . strlen($payload);
  }
  if ($hdrs) curl_setopt($ch, CURLOPT_HTTPHEADER, $hdrs);

  $body = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  return [$code, $body === false ? '' : (string)$body, (string)$err];
}

function tvdb_login_and_store(): string {
  $apikey = tvdb_get_apikey();
  if ($apikey === '') throw new RuntimeException('TVDB API key not configured.');

  $pin = tvdb_get_pin();
  $body = ['apikey' => $apikey];
  if ($pin !== '') $body['pin'] = $pin;

  [$code, $raw, $err] = tvdb_http('POST', tvdb_base_url() . '/login', $body);

  if ($code < 200 || $code >= 300) {
    $msg = 'Login failed';
    $d = json_decode($raw, true);
    if (is_array($d) && isset($d['message'])) $msg .= ': ' . (string)$d['message'];
    if ($err !== '') $msg .= ' (' . $err . ')';
    throw new RuntimeException($msg);
  }

  $data = json_decode($raw, true);
  $token = is_array($data) ? (string)($data['data']['token'] ?? '') : '';
  if ($token === '') throw new RuntimeException('TVDB login did not return a token.');

  // Docs say token is valid for ~1 month; store a conservative 28-day expiry.
  $expires = gmdate('c', time() + 28 * 86400);
  tvdb_set_token($token, $expires);

  return $token;
}

function tvdb_ensure_token(): string {
  if (tvdb_token_is_valid()) {
    $t = tvdb_get_token();
    if ($t !== '') return $t;
  }
  return tvdb_login_and_store();
}

function tvdb_get_json(string $path, array $query = []): array {
  $token = tvdb_ensure_token();
  $url = tvdb_base_url() . $path;
  if ($query) $url .= '?' . http_build_query($query);

  [$code, $raw, $err] = tvdb_http('GET', $url, null, [
    'Authorization: Bearer ' . $token,
    'Accept: application/json',
  ]);

  if ($code < 200 || $code >= 300) {
    $msg = 'TVDB request failed';
    $d = json_decode($raw, true);
    if (is_array($d) && isset($d['message'])) $msg .= ': ' . (string)$d['message'];
    if ($err !== '') $msg .= ' (' . $err . ')';
    throw new RuntimeException($msg);
  }

  $data = json_decode($raw, true);
  if (!is_array($data)) throw new RuntimeException('Invalid JSON from TVDB.');
  return $data;
}

function tvdb_get_series_base(int $tvdbId): array {
  return tvdb_get_json('/series/' . $tvdbId);
}
