<?php
declare(strict_types=1);

/**
 * Integration secrets encryption-at-rest (server-side only).
 *
 * Format:
 *   v1:{nonce_b64}:{cipher_b64}
 *
 * Uses libsodium secretbox with a 256-bit key (32 bytes).
 * Key comes from WNX_SECRET_KEY_B64 (loaded in app/config/config.php).
 *
 * NOTE:
 * - If no key is configured, encryption falls back to a reversible 'plain:' wrapper
 *   (useful for local/dev). Production should ALWAYS set a real key.
 */

function crypto_key_raw(): string {
  $b64 = WNX_SECRET_KEY_B64 ?: '';
  if ($b64 === '') return '';

  $key = base64_decode($b64, true);
  if ($key === false || strlen($key) !== SODIUM_CRYPTO_SECRETBOX_KEYBYTES) {
    throw new RuntimeException('WATCHNEXUS_SECRET_KEY_B64 must decode to 32 bytes.');
  }
  return $key;
}

/**
 * Encrypt a secret for storage (returns packed string).
 */
function encrypt_secret(string $plain): string {
  $key = crypto_key_raw();
  if ($key === '') {
    // Dev fallback (NOT secure)
    return 'plain:' . base64_encode($plain);
  }

  $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
  $cipher = sodium_crypto_secretbox($plain, $nonce, $key);
  return 'v1:' . base64_encode($nonce) . ':' . base64_encode($cipher);
}

/**
 * Decrypt a packed secret string.
 */
function decrypt_secret(string $packed): string {
  if ($packed === '') return '';

  if (str_starts_with($packed, 'plain:')) {
    $b64 = substr($packed, 6);
    $plain = base64_decode($b64, true);
    if ($plain === false) throw new RuntimeException('Invalid plain secret encoding.');
    return $plain;
  }

  if (!str_starts_with($packed, 'v1:')) {
    throw new RuntimeException('Unknown secret format.');
  }

  $parts = explode(':', $packed, 3);
  if (count($parts) !== 3) throw new RuntimeException('Malformed secret format.');

  [, $nonce_b64, $cipher_b64] = $parts;
  $nonce = base64_decode($nonce_b64, true);
  $cipher = base64_decode($cipher_b64, true);

  if ($nonce === false || $cipher === false) throw new RuntimeException('Malformed secret encoding.');

  $key = crypto_key_raw();
  if ($key === '') throw new RuntimeException('Missing encryption key.');

  $plain = sodium_crypto_secretbox_open($cipher, $nonce, $key);
  if ($plain === false) throw new RuntimeException('Decrypt failed (tampered or wrong key).');

  return $plain;
}
