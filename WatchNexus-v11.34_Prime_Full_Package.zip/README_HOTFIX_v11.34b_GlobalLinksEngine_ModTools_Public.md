# WatchNexus HOTFIX v11.34b – Global Links Engine (Mod + Public)

This hotfix upgrades the **Links ▾** dropdown on TV cards to a **DB-backed “Start Menu”** layout (categories on the left, links on the right), and adds a **Mod Tools manager** so mods/admins can maintain the menu without redeploying code.

## What this hotfix includes
- Public TV cards: **Links ▾** dropdown now reads from `resource_link_categories` and `resource_links`.
- Mod Tools: **Global Links Manager** UI (CRUD categories + links)
- Admin API: `/api/resource_links_admin.php` (mod/admin only)
- Public API: `/api/resource_links.php` (public)
- SQL migration: `migrations/RESOURCE_LINKS_MIGRATION.sql`

## Install (upload files)
Upload the included files to the same paths on the server.

## One-time DB migration
Run this SQL once in phpMyAdmin:
- `migrations/RESOURCE_LINKS_MIGRATION.sql`

If tables already exist, it will safely do nothing (IF NOT EXISTS).

## Seed default categories/links
1. Log in as a mod/admin
2. Go to **Mod Tools**
3. Open **Global Links Manager**
4. Click **Seed Defaults** (only seeds if your tables are empty)

## Notes
- Templates support tokens: `{QUERY}`, `{WIKI_TITLE}`, `{TVMAZE_ID}`, `{THETVDB_ID}`, `{IMDB_ID}`, `{TRAKT_ID}`, `{TMDB_ID}`.
- Admin validation blocks obvious torrent/piracy keywords and `magnet:` links.
- Admin validation allows:
  - **Internal/relative** links like `/?page=something&q={QUERY}`
  - **http/https** links on an allowlist (see `resource_links_admin.php`).

