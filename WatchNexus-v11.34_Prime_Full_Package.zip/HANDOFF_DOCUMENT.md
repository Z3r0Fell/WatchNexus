# WatchNexus v11.31 — Final Handoff Document

**Date:** January 9, 2026  
**Status:** ✅ Complete (Phases 1–12 implemented)  
**Current Production Build:** v11.31

---

## 📦 Downloads (add these files beside this doc)

> These links are written as **relative paths** so they work in a repo, shared folder, or release bundle. If you host releases on a website, replace `./` with your release URL.

- **v11.31 (Recommended / Current):** [WatchNexus-v11.31_Full_Package_SettingsFix.zip](./WatchNexus-v11.31_Full_Package_SettingsFix.zip)
- **v11.3 (Calendar fix milestone):** [WatchNexus-v11.3_Full_Package_CalendarFix.zip](./WatchNexus-v11.3_Full_Package_CalendarFix.zip)
- **v11.25 (Baseline completed package):** [WatchNexus-v11.25_Full_Package_Completed.zip](./WatchNexus-v11.25_Full_Package_Completed.zip)
- **Restart handoff (historical reference):** [WATCHNEXUS_RESTART_HANDOFF_PHASE11_2-FRESH.md](./WATCHNEXUS_RESTART_HANDOFF_PHASE11_2-FRESH.md)

---

## ✅ Current State

- **Working:** Calendar, Browse, My Shows, Mod Tools, Admin, Integrations, Imports (TVMaze + Sonarr), Download actions
- **UI:** Themes + Mode system (Command / Overview / Signal / Nebula)
- **RBAC:** user / mod / admin

---

## 🧯 Hotfix Notes (v11.31)

### Settings page HTTP 500 (IONOS / short_open_tag)
Some hosts (including certain IONOS PHP profiles) can enable `short_open_tag`, which makes a stray `<?` inside an HTML template behave like PHP and crash the page.

**Fix included in v11.31:** `app/views/settings.php` — removed the stray `<?` before the Reload button.

---

## 🗂️ Key Files

**Core:**
- `app/bootstrap.php` — initialization + config + error handling
- `app/lib/` — database, crypto, RBAC, modules
- `public/index.php` — router

**Pages:**
- `app/views/calendar.php` — grid/list calendar + downloads
- `app/views/browse.php` — browse/search
- `app/views/myshows.php` — user tracking
- `app/views/mod.php` — TVMaze + Sonarr import tools
- `app/views/admin.php` — dashboard
- `app/views/settings.php` — modules + integrations + Trakt/TVDB config

**APIs (selection):**
- `public/api/events.php`
- `public/api/import_tvmaze.php`
- `public/api/import_sonarr.php`
- `public/api/download_action.php`
- `public/api/system_health.php`
- `public/api/settings_get.php` / `public/api/settings_save.php`

---

## 🗄️ Database

**Preferred install:** import `MASTER_SCHEMA.sql` (single file, consistent).

Tables (core):
- `users`, `user_roles`
- `shows`, `show_external_ids`
- `events`, `user_tracked_shows`
- `user_integrations`
- `module_policy`
- `system_config`

---

## 🔧 Debugging (when you have no server error logs)

- `health.php` — quick “is PHP alive” check
- `debug.php` — configuration snapshot
- `mb.php` — fatal error catcher that prints *file:line* for 500s (use temporarily)

Example:
- `/mb.php?page=settings&partial=1`

---

## 🚀 Quick Start (Clean Install)

1) Upload files
2) Copy config:
   - `app/config/config.php.example` → `app/config/config.php`
3) Import DB:
   - `MASTER_SCHEMA.sql`
4) Register a user, then promote to admin (example):

```sql
INSERT INTO user_roles (user_id, role) VALUES (1, 'admin');
```

5) Use **Mod Tools → TVMaze Importer** (and Sonarr import if desired)

---

## 🏁 Status

- **Feature complete:** ✅
- **Operational:** ✅
- **Calendar:** ✅ (fixed in v11.3)
- **Settings page:** ✅ (fixed in v11.31)

