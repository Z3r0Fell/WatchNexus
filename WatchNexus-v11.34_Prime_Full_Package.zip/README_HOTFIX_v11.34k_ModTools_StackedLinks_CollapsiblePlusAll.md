# WatchNexus v11.34k HOTFIX — Mod Tools stacked layout + collapsible sections (+ collapse all)

## What this fixes
- Global Links Manager layout is now **stacked** (Categories above Links) for normal screens.
- Adds **independent collapse/expand toggles** to every card section (NOT an accordion).
- Adds **Collapse all / Expand all** buttons to the main Mod Tools header.
- Collapsed state is remembered in `localStorage` per browser.

## Files in this hotfix
- `app/views/mod.php`

## Install
Upload and overwrite the file above on your server, then hard refresh (Ctrl+F5).
