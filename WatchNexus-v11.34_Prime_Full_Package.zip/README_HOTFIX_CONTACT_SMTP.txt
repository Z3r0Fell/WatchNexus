WatchNexus HOTFIX — Contact Form (Public) + SMTP Sender

What this adds
- New public page: /?page=contact (no login required)
- New API endpoint: /api/contact_submit.php
- Footer link: "Contact form"
- Sends email using SMTP auth as: webform@watchnexus.ca
  and delivers to: wmadmin@watchnexus.ca

Files in this hotfix
- public/index.php
- app/views/layout.php
- app/views/contact.php
- public/assets/js/contact.js
- public/api/contact_submit.php

How to install
1) Back up the files listed above on your server.
2) Upload this hotfix zip to your site root and extract/overwrite.
3) Add SMTP credentials to app/config/config.local.php (see below).
4) Visit /?page=contact and send a test message.

Required config (app/config/config.local.php)
If you don't already have config.local.php, copy:
  app/config/config.local.example.php -> app/config/config.local.php

Then add this block to $WNX_CONFIG_LOCAL (top-level):

$WNX_CONFIG_LOCAL['mail'] = [
  'smtp_host'   => 'smtp.ionos.com',
  'smtp_port'   => 465,          // 465 for SSL, or 587 for STARTTLS
  'smtp_secure' => 'ssl',        // 'ssl' or 'tls'
  'smtp_user'   => 'webform@watchnexus.ca',
  'smtp_pass'   => 'PASTE_MAILBOX_PASSWORD_HERE',

  // Envelope / headers
  'from_email'  => 'webform@watchnexus.ca',
  'from_name'   => 'WatchNexus Webform',
  'to_email'    => 'wmadmin@watchnexus.ca',
  'to_name'     => 'WatchNexus Admin',

  // TLS verification (leave true if possible)
  'verify_peer' => true,
];

Troubleshooting
- If IONOS blocks port 465, switch to:
    'smtp_port' => 587,
    'smtp_secure' => 'tls'
- If TLS fails due to missing CA bundle on your host, temporarily set:
    'verify_peer' => false
  (not ideal, but gets it working.)

- The API returns JSON with a useful error string if sending fails.
