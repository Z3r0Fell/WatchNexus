WatchNexus Hotfix v11.34g - Links Menu Portal + Contrast

What this fixes:
- Links menu now renders in a single portal attached to <body>, so it cannot be clipped/hidden by calendar modals or overflow containers.
- Forces high-contrast menu colors (no theme-variable inheritance that can make text/icons invisible).
- Closes on scroll/resize/ESC for stability.

Files included:
- public/assets/js/resource_links.js

Install:
1) Overwrite the file on your server at:
   public/assets/js/resource_links.js
2) Hard refresh your browser (Ctrl+F5).

