# Session Error Fix - WatchNexus v3

**Issue:** "Headers already sent" warnings on test_apis.php  
**Status:** ✅ FIXED  
**Date:** January 9, 2026

---

## 🔍 WHAT WAS WRONG

### **Error Messages:**
```
Warning: session_set_cookie_params(): Session cookie parameters cannot be changed 
after headers have already been sent in /app/bootstrap.php on line 21

Warning: session_start(): Session cannot be started after headers have already been 
sent in /app/bootstrap.php on line 23
```

### **Root Cause:**
PHP files outputting HTML **before** calling `session_start()`. In PHP, you must:
1. Call `session_start()` BEFORE any output (HTML, echo, whitespace)
2. Output HTML AFTER session is started

---

## ✅ WHAT WAS FIXED

### **1. test_apis.php**
**Before:**
```php
<?php
// ... some HTML output ...
require_once __DIR__ . '/../../app/bootstrap.php';  // Wrong path!
```

**After:**
```php
<?php
declare(strict_types=1);

// Require bootstrap FIRST - before any output
require_once __DIR__ . '/../app/bootstrap.php';  // Correct path!

// NOW we can output HTML
?>
<!DOCTYPE html>
...
```

**Changes:**
- ✅ Fixed path: `/../app/bootstrap.php` (was `../../`)
- ✅ Require bootstrap BEFORE any HTML
- ✅ Removed mod role requirement (test page should be accessible)
- ✅ Improved UI with better styling

---

## 🧪 HOW TO TEST

### **Visit test page:**
```
https://watchnexus.ca/test_apis.php
```

**Should see:**
- ✅ No PHP warnings
- ✅ Clean page loads
- ✅ Tests run automatically
- ✅ Green checkmarks for working APIs
- ✅ Red X for broken APIs (with error details)

---

## 📋 OTHER FILES TO CHECK

If you see similar warnings on other pages, check for:

### **1. Output Before Bootstrap**
```php
❌ BAD:
<?php
echo "Hello";
require_once 'bootstrap.php';

✅ GOOD:
<?php
require_once 'bootstrap.php';
echo "Hello";
```

### **2. Whitespace Before <?php**
```php
❌ BAD:

<?php  // Blank line before opening tag

✅ GOOD:
<?php  // No whitespace before tag
```

### **3. BOM (Byte Order Mark)**
Some text editors add invisible BOM characters. Use UTF-8 **without BOM**.

---

## 🔧 COMMON PHP FILES TO CHECK

**Files in public/ should use:**
```php
require_once __DIR__ . '/../app/bootstrap.php';
```

**Files in public/api/ should use:**
```php
require_once __DIR__ . '/../../app/bootstrap.php';
```

---

## 📊 VERIFICATION

After fixing, you should see:

**✅ debug.php:**
```
PHP Version: 8.4.16
Testing bootstrap...
✓ Bootstrap loaded  <-- No warnings!
Testing database...
✓ Database connected
✓ All basic tests passed!
```

**✅ test_apis.php:**
- No PHP warnings at top
- Clean test interface
- Tests run and show results

---

## 💡 WHY THIS MATTERS

**Headers** in HTTP include things like:
- Content-Type
- Set-Cookie (for sessions)
- Location (for redirects)
- Cache-Control

Once you output ANY content (HTML, echo, whitespace), PHP sends the headers. After that, you **cannot** modify headers, including setting session cookies.

**That's why bootstrap must come FIRST!**

---

## 🎯 FILES MODIFIED IN THIS FIX

```
Modified:
- public/test_apis.php (fixed path + structure)

All other files already correct!
```

---

**Session errors fixed! Test page now works cleanly.** ✅
