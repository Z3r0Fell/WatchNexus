# Contact Form SMTP Setup (IONOS)

The Contact page (`/?page=contact`) sends mail via SMTP using a dedicated sender mailbox.

## 1) Create mailbox
- Create `webform@watchnexus.ca` in IONOS mail control panel.
- Set a password.

## 2) Add mail config
Create `app/config/config.local.php` (or edit your existing one) and include:

```php
$WNX_CONFIG_LOCAL['mail'] = [
  'smtp_host'   => 'smtp.ionos.com',
  'smtp_port'   => 465,          // 465 SSL (recommended) or 587 STARTTLS
  'smtp_secure' => 'ssl',        // 'ssl' or 'tls'
  'smtp_user'   => 'webform@watchnexus.ca',
  'smtp_pass'   => 'YOUR_MAILBOX_PASSWORD',

  'from_email'  => 'webform@watchnexus.ca',
  'from_name'   => 'WatchNexus Webform',
  'to_email'    => 'wmadmin@watchnexus.ca',
  'to_name'     => 'WatchNexus Admin',

  'verify_peer' => true,
];
```

## 3) If mail fails
- Try port **587** with `'smtp_secure' => 'tls'`.
- If TLS verification fails on shared hosting, set `'verify_peer' => false` as a temporary workaround.

