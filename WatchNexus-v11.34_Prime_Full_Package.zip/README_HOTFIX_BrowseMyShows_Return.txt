WatchNexus Hotfix — Restore Browse/My Shows visibility

Symptom
- The “Browse” and/or “My Shows” tabs/pages disappear from the top nav tabs, or you get a “Blocked” banner for those pages.

Most common cause
- module_policy (or legacy global_module_policy) has Browse/My Shows as default_off / disabled, so /api/state.php reports them disabled.

What this hotfix does
- Patches app/lib/modules.php to treat Browse + My Shows as default-on unless explicitly disabled globally.
  (This prevents accidental default_off policy states from hiding core navigation.)

Install
1) Upload this file, preserving folders:
   app/lib/modules.php
2) Hard refresh your browser (Ctrl+F5) and re-test.
3) Optional quick check:
   Visit /api/state.php and confirm:
   - modules.browse  = true
   - modules.myshows = true

If it’s still disabled after the hotfix (DB force-disable)
Run this SQL in phpMyAdmin:

INSERT INTO module_policy (module_id, force_enabled, enabled_by_default, disabled_globally)
VALUES
  ('browse', 0, 1, 0),
  ('myshows', 0, 1, 0)
ON DUPLICATE KEY UPDATE
  force_enabled = 0,
  enabled_by_default = 1,
  disabled_globally = 0;

(If you’re on the older schema, check global_module_policy and set mode='default_on' for those module_id values.)
