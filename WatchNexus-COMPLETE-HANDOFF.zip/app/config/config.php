<?php
declare(strict_types=1);

// Define secret key constant for crypto functions
define('WNX_SECRET_KEY_B64', 'YXV6Z296b29tY2E6REBya25meXJlMjAwMg==');

$WNX_CONFIG = [
  'db' => [
    'host' => 'db5019344619.hosting-data.io',
    'name' => 'dbs15146818',
    'user' => 'dbu2757511',
    'pass' => 'D@rkfyre2002',
    'charset' => 'utf8mb4',
  ],
  'secret_key_b64' => 'YXV6Z296b29tY2E6REBya25meXJlMjAwMg==',
];
